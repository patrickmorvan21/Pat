"use client";

import { useEffect, useState } from "react";
import Scene from "@/components/Scene";
import { HeroGeolier } from "@/components/HeroGeolier";
import Retour from "@/components/Retour";
import Intro, { ActeScreen } from "@/components/Intro";
import Registre from "@/components/Registre";
import { loadMemory, mutateMemory, shouldShowIntro } from "@/lib/player-memory";
import { pickJailerQuote } from "@/lib/jailer-quotes";
import { hasSavedRun, loadRun, resetRun, marquerOuverture } from "@/lib/state";
import { lieuNom } from "@/lib/scene-data";
import { APP_VERSION } from "@/lib/version";
import { applySettingsToDom, loadSettings } from "@/lib/settings";
import { initAnalytics, ouvrirRun, track } from "@/lib/analytics";
import { armAudio, playMusic } from "@/lib/audio";
import { OptionsTab } from "@/components/GameMenu";
import { BoutonNav } from "@/components/NavIcons";
import { assetUrl } from "@/lib/assets";
import Reliques from "@/components/Reliques";
import Codex from "@/components/Codex";
import Avis from "@/components/Avis";

/**
 * Écrans d'accueil (Figma 1963:370 « Première partie » / 1970:458 « Reprendre
 * partie », 15/07 soir) : héros = le Geôlier détouré sur fond ORANGE plein,
 * animé (respiration + cendres) selon le prototype validé
 * `accueil_geolier_v5.html` ; dessous, panneau CHARBON : PACTUM (Instrument
 * Serif), tagline, CTA à segments décalés, liens en pied.
 * OPTIONS n'est pas encore designé : lien présent mais inerte.
 */

export default function Home() {
  const [phase, setPhase] = useState<"boot" | "home" | "reprise" | "intro" | "retour" | "acte" | "game">(
    "boot",
  );
  const [saved, setSaved] = useState(false);
  // Le compte a-t-il un passé (reliques forgées ou héros tombés) ? Distinct
  // de `saved` : une run peut ne plus exister alors que le passé, lui, reste.
  const [aDuPasse, setADuPasse] = useState(false);
  const [citation, setCitation] = useState<string | null>(null);
  const [overlay, setOverlay] = useState<"reliques" | "registre" | "codex" | "options" | null>(null);
  const [aDuCodex, setADuCodex] = useState(false);
  // DONNER SON AVIS (11/09) — quatrième accès au questionnaire, et le
  // plus voyant : la démo se joue en ligne, le retour doit se trouver
  // sans ouvrir le menu. Overlay plein cadre, comme les autres écrans.
  const [avis, setAvis] = useState(false);

  useEffect(() => {
    // Réglages (Options 21/07) : applique taille de texte + animations réduites
    // au <html> dès le démarrage de l'app (persiste à travers accueil/jeu).
    applySettingsToDom();
    // STATISTIQUES (10/09) : une seule initialisation, à la racine — pose les
    // super-propriétés (version, source du lien, PWA), applique l'opt-out du
    // réglage, arme la carte d'abandon (`app_masquee`).
    initAnalytics({ stats: loadSettings().stats });
    // Musique (24/07) : thème d'intro sur l'accueil — armé sur le premier
    // geste (politique d'autoplay), silencieux si les mp3 manquent.
    armAudio();
    playMusic("intro");
    // eslint-disable-next-line react-hooks/set-state-in-effect -- miroir du localStorage, une seule fois au montage (illisible au rendu SSR)
    setSaved(hasSavedRun());
    const m0 = loadMemory();
    track("accueil_vu", {
      premiere_partie: m0.runsStarted === 0,
      runs: m0.runsStarted,
      morts: m0.deaths,
      traversees: m0.zonesCleared ?? 0,
      partie_en_cours: hasSavedRun(),
    });
    setADuPasse(m0.relics.length > 0 || m0.fallen.length > 0);
    setADuCodex(Object.keys(m0.codex ?? {}).length > 0);
    // La citation du Geôlier devient variable (30/07) : dès la première mort,
    // la tagline de l'accueil est SA voix — tirée du pool conditionné par le
    // contexte de la dernière mort, jamais deux fois la même de suite.
    const mem = loadMemory();
    // La voix du Geôlier dès qu'il y a un PASSÉ — une mort OU une traversée
    // réussie (7/08 : un survivant sans aucune mort mérite aussi son accueil).
    if (mem.deaths > 0 || (mem.zonesCleared ?? 0) > 0) {
      const now = Date.now();
      const joursHorsJeu = mem.lastPlayedAt
        ? Math.floor((now - mem.lastPlayedAt) / 86_400_000)
        : 0;
      const ld = mem.lastDeath;
      setCitation(
        pickJailerQuote({
          morts: mem.deaths,
          jour: ld?.day ?? 0,
          acte: ld?.acte ?? 1,
          fixation: ld?.fixation ?? false,
          rareteRare: ld ? ld.rarity !== "commune" : false,
          classe: ld?.classed ?? false,
          joursHorsJeu,
          meilleurScore: ld?.meilleurScore ?? false,
          traversee: mem.derniereFinTraversee ?? false,
        })
      );
      mutateMemory((m) => {
        m.lastPlayedAt = now;
      });
    }
    setPhase("home");
  }, []);

  /**
   * TROIS OUVERTURES, ET ELLES RACCOURCISSENT (brief V2 du 06/09).
   *
   *   • toute première partie — le Geôlier, « Qui es-tu ? / Signer », le
   *     Pacte, la MARQUE, puis l'acte. ~30 à 60 secondes, et la signature est
   *     le dernier geste : plus aucun questionnaire derrière.
   *   • réincarnation — deux phrases, pas de contrat, pas de marque : le
   *     Pacte n'est signé qu'une fois, sinon il cesse d'être irréversible.
   *   • vies suivantes — un mot, puis le monde.
   *
   * Une reprise, elle, saute droit au jeu (par le carton de reprise).
   */
  function enterGame(reprend = false) {
    // ⚠️ `reprend` peut être l'ÉVÉNEMENT de clic (COMMENCER passe `enterGame`
    // tel quel) : seule la valeur `true` veut dire « reprise ».
    const mode = reprend === true ? "reprise" : loadRun().ouverture ? "recommencer" : "nouvelle";
    // L'identifiant de partie est posé AVANT l'événement, pour que
    // `partie_commencee` le porte lui aussi : c'est la première ligne de la
    // partie, elle doit se retrouver dans son groupe.
    ouvrirRun(mode === "reprise");
    track("partie_commencee", { mode });
    if (loadRun().ouverture) {
      // LE CARTON DE REPRISE (retour Patrick 01/09) : le rappel « Nom · Jour /
      // Les Landes · Lieu » vivait sous le bouton, en 10 px gris — il alourdit
      // l'accueil sans qu'on le lise. Il devient un écran plein, joué APRÈS le
      // clic : c'est là qu'on a besoin de savoir où l'on était.
      setPhase(reprend ? "reprise" : "game");
      return;
    }
    setPhase(shouldShowIntro() ? "intro" : "retour");
  }

  if (phase === "game") return <Scene />;
  if (phase === "reprise") return <CartonReprise onDone={() => setPhase("game")} />;
  if (phase === "intro") return <Intro onDone={() => setPhase("acte")} />;
  // ⚠️ LE CARTON D'ACTE SE JOUE AUSSI EN DÉMO (retour Patrick, 25/08 : « on a
  // perdu l'introduction de l'acte 1 les Lisières, c'était beau »). Il avait
  // été sauté le 24/08 pour compresser l'entrée — mais c'est le seul écran qui
  // NOMME le monde, et il coûte un tap. La compression se paie ailleurs.
  /* ⚠️ LE RETOUR VA DROIT AU JEU. Pas de carton d'acte : il NOMME le monde,
     ce qui ne se refait pas à chaque mort — et c'est ce qui fait tenir les
     cinq à dix secondes visées. */
  if (phase === "retour") return <Retour onDone={() => { marquerOuverture(); setPhase("game"); }} />;
  // Nommer l'acte juste après le scellement du pacte, avant la première scène.
  if (phase === "acte") return <ActeScreen onDone={() => { marquerOuverture(); setPhase("game"); }} />;

  return (
    <main className="flex min-h-dvh items-center justify-center">
      <div className="phone-frame relative flex h-[800px] max-h-[100dvh] w-[390px] shrink-0 flex-col overflow-clip bg-[var(--color-bg)]">
        {phase === "home" && (
          <>
            <HeroGeolier />

            {/* Panneau charbon : marque, tagline, CTA, liens */}
            <div className="flex flex-1 flex-col items-center px-[24px] pt-[34px]">
              {/* Logo PACTUM — asset HD (1720×270, transparent) fourni par Patrick,
                  même tracé que la maquette (Figma 1963:425 / 1970:483). Downscale
                  lissé standard (pas de pixelated) : la source est bien plus
                  définie que l'affichage, contrairement aux textures tramées 1:1. */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img alt="PACTUM" src={assetUrl("assets/pactum_logo.png")} className="block w-[197px] select-none" />
              {/* La tagline (maquette 2333-7029 : mono 13, blanc) — remplacée
                  par la voix du Geôlier dès la première mort (30/07). */}
              <p className="mt-[14px] text-center font-mono text-[13px] leading-[1.5] text-[var(--color-ink)]">
                {citation ? (
                  citation
                ) : saved ? (
                  <>
                    Aucune partie ne se ressemble.
                    <br />
                    Aucune mort n&apos;est gratuite.
                  </>
                ) : (
                  <>
                    Tu choisis. Le dé décide.
                    <br />
                    Lui, il regarde.
                  </>
                )}
              </p>

              <div className="mt-[28px] flex w-[298px] flex-col gap-[12px]">
                {saved ? (
                  <>
                    <HomeCta label="REPRENDRE" onClick={() => enterGame(true)} />
                    <HomeCta
                      secondary
                      label="RECOMMENCER"
                      onClick={() => {
                        resetRun();
                        enterGame();
                      }}
                    />
                  </>
                ) : (
                  <HomeCta label="COMMENCER" onClick={enterGame} />
                )}
              </div>

              {/* Liens de pied — OPTIONS inerte (écran pas encore designé) */}
              <div className="mt-auto flex flex-col items-center gap-[14px] pb-[26px]">
                {/* ⚠️ Ces deux écrans lisent la MÉMOIRE DU COMPTE, pas la run.
                    Les conditionner à `saved` les rendait inaccessibles juste
                    après une mort — le moment exact où le joueur vient de
                    découvrir sa relique et veut la revoir. */}
                {aDuPasse && (
                  <>
                    <FooterLink label="RELIQUES" onClick={() => setOverlay("reliques")} />
                    <FooterLink label="GRAND REGISTRE" onClick={() => setOverlay("registre")} />
                  </>
                )}
                {/* LE CODEX (spec 20/08) : ordre verrouillé Reliques · Grand
                    Registre · Codex · Options — juste avant Options. Visible
                    dès qu'une entrée existe (la Borne se débloque au premier
                    pas de la première vie). */}
                {aDuCodex && <FooterLink label="CODEX" onClick={() => setOverlay("codex")} />}
                <FooterLink label="OPTIONS" onClick={() => setOverlay("options")} />
                {/* ⚠️ En ORANGE, et seul lien de pied à l'être : c'est le
                    signal d'accent de la DA, donc ce qui tranche sur quatre
                    libellés blancs identiques (demande « bien visible »).
                    Affiché seulement si le joueur a quelque chose à dire —
                    une partie en cours ou un passé de compte : avant d'avoir
                    joué, le questionnaire porterait sur rien. */}
                {(saved || aDuPasse) && (
                  <FooterLink accent label="DONNER SON AVIS" onClick={() => setAvis(true)} />
                )}
              </div>
            </div>

            {/* Le Grand Registre a son propre écran plein cadre depuis le
                26/07 (maquette 2265:24560) — les deux autres restent en
                overlay simple. */}
            {overlay === "registre" ? (
              <Registre
                heroName={loadRun().heroName}
                playerFranchis={loadRun().lieuxEngages ?? 0}
                onClose={() => setOverlay(null)}
              />
            ) : overlay === "codex" ? (
              <Codex onClose={() => setOverlay(null)} />
            ) : overlay === "reliques" ? (
              /* L'écran DESCENTE / RELIQUAIRE (spec 20/08, Figma 2496:4745).
                 Révocable jusqu'au DÉPART en run : une partie engagée scelle
                 la Descente (lecture seule) — elle se rouvre à la prochaine
                 incarnation. */
              <Reliques onClose={() => setOverlay(null)} verrouille={saved} />
            ) : (
              overlay && <HomeOverlay kind={overlay} onClose={() => setOverlay(null)} />
            )}
            {avis && (
              <div className="absolute inset-0 z-[50]" data-avis-overlay>
                <Avis source="accueil" onClose={() => setAvis(false)} />
              </div>
            )}
          </>
        )}

        {/* Numéro de version — bas à droite du cadre, blanc opacité 50 %.
            Repère de déploiement (demande Patrick 20/07) : source unique dans
            lib/version.ts, bumpée selon la grandeur du changement.
            Masqué dès qu'un écran plein cadre est ouvert : il se posait par
            dessus le Registre (vu au test du 26/07). */}
        {!overlay && !avis && (
          <span className="app-version" aria-hidden>
            v{APP_VERSION}
          </span>
        )}
      </div>
    </main>
  );
}

/**
 * CTA de l'accueil = composant Figma « Group 36720 / 36692 » (maquettes
 * 1963:370 / 1970:458), reproduit tel quel : 298×46, texte Roboto Mono
 * Medium 14px espacé 2.8px, entailles de coins charbon (2px). Primaire =
 * bloc orange plein texte charbon ; secondaire = contour orange, texte
 * orange, fond transparent. Pas de segments décalés ici — la maquette prime.
 */
export function HomeCta({ label, secondary, onClick }: { label: string; secondary?: boolean; onClick: () => void }) {
  // Structure = calques du composant Figma (et de ChoiceButton en jeu) :
  // fond + bordure en calques enfants inset-0, puis les carrés de coin 2×2
  // charbon posés PAR-DESSUS, au ras exact du coin (0,0) — jamais une
  // bordure CSS sur le bouton lui-même, qui décalerait les entailles de 1px.
  return (
    <button
      type="button"
      onClick={onClick}
      className={`group relative h-[46px] w-full cursor-pointer border-none bg-transparent font-mono text-[14px] font-medium uppercase tracking-[2.8px] ${
        secondary ? "text-[var(--color-accent)]" : "text-[var(--color-bg)]"
      }`}
    >
      {/* Pas d'état hover/active blanc (retour Patrick 16/07) : le bouton
          reste identique au repos, au survol et au clic. */}
      <span
        className={`absolute inset-0 border border-solid border-[var(--color-accent)] ${
          secondary ? "bg-transparent" : "bg-[var(--color-accent)]"
        }`}
        aria-hidden
      />
      {/* Entailles de coins 2×2 (charbon du fond), au ras du coin */}
      <span className="pointer-events-none absolute top-0 left-0 size-[2px] bg-[var(--color-bg)]" aria-hidden />
      <span className="pointer-events-none absolute bottom-0 left-0 size-[2px] bg-[var(--color-bg)]" aria-hidden />
      <span className="pointer-events-none absolute top-0 right-0 size-[2px] bg-[var(--color-bg)]" aria-hidden />
      <span className="pointer-events-none absolute bottom-0 right-0 size-[2px] bg-[var(--color-bg)]" aria-hidden />
      <span className="relative">{label}</span>
    </button>
  );
}

function FooterLink({
  label,
  onClick,
  disabled,
  accent,
}: {
  label: string;
  onClick?: () => void;
  disabled?: boolean;
  accent?: boolean;
}) {
  // Maquette 2333-7029 : mono 13, blanc plein, espacement 2.6px.
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      data-avis-accueil={accent ? "" : undefined}
      className={`font-mono text-[13px] uppercase tracking-[2.6px] ${
        accent ? "text-[var(--color-accent)]" : "text-[var(--color-ink)]"
      } ${disabled ? "cursor-not-allowed opacity-45" : "cursor-pointer"}`}
    >
      {label}
    </button>
  );
}

/** Plein cadre charbon (jamais une popup — spec §8). Depuis le 20/08, seules
    les OPTIONS passent encore ici : le Registre (26/07) et les Reliques
    (écran Descente/Reliquaire) ont chacun leur écran dédié. */
function HomeOverlay({ kind, onClose }: { kind: "options"; onClose: () => void }) {
  void kind;
  return (
    <div className="absolute inset-0 z-[9] flex flex-col bg-[var(--color-bg)]">
      {/* La croix descend sous la barre iOS (safe-area) — même hauteur que
          le menu en jeu (retour Patrick 21/08). */}
      <div className="flex items-center justify-between px-[15px] pb-[11px] pt-[calc(env(safe-area-inset-top,0px)+11px)]">
        <span className="text-[12px] font-medium uppercase tracking-[2.4px] text-[var(--color-ink)]">
          Options
        </span>
        <CloseX onClose={onClose} />
      </div>
      <div className="flex-1 overflow-y-auto pb-[24px]">
        <OptionsTab />
      </div>
    </div>
  );
}

/** Croix de fermeture — CSS propre depuis le 21/08 (décision Patrick : les
    assets pixel rendaient un glyphe illisible). Réutilisée partout. */
export function CloseX({ onClose }: { onClose: () => void }) {
  return <BoutonNav icone="croix" onClick={onClose} label="Fermer" />;
}

/**
 * LE CARTON DE REPRISE (retour Patrick 01/09).
 *
 * « Le texte en dessous de reprendre fait trop bêta » — deux lignes de 10 px
 * grises sous le bouton, qui alourdissaient l'accueil sans qu'on les lise.
 * Elles sont retirées, et ce qu'elles disaient est joué APRÈS le clic, en
 * plein cadre : c'est au moment de retourner dans la partie qu'on a besoin de
 * savoir où l'on en était.
 *
 * ⚠️ Ce n'est PAS un écran de plus à taper : il se retire tout seul (2,2 s).
 * Le tap n'est qu'un raccourci — la cadence du 31/08 (« les taps morts ») ne
 * tolère pas un tap obligatoire sur chaque reprise.
 *
 * Sans maquette Figma : langage du SKILL (Instrument Serif pour le nom,
 * Roboto Mono pour le reste, trois couleurs, aucun dégradé).
 */
function CartonReprise({ onDone }: { onDone: () => void }) {
  // Lu au montage plutôt que passé en prop : la run ne peut pas être périmée.
  const [run] = useState(() => loadRun());
  useEffect(() => {
    const t = setTimeout(onDone, 2200);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <main className="flex min-h-dvh items-center justify-center">
      <div
        className="phone-frame relative flex h-[800px] max-h-[100dvh] w-[390px] shrink-0 cursor-pointer flex-col items-center justify-center gap-[14px] overflow-clip bg-[var(--color-bg)] px-[30px]"
        onClick={onDone}
      >
        <p className="font-mono text-[12px] uppercase tracking-[2.4px] text-[var(--color-ink)] opacity-50">
          Tu reprends
        </p>
        <p className="text-center font-serif text-[36px] leading-none text-[var(--color-accent)]">
          {run.heroName}
        </p>
        {/* « Les Landes » = la ZONE (toute la prose la nomme ainsi) ; « Les
            Lisières » reste le nom de l'ACTE, sur son carton (décision 10/08).
            Ce carton parle de l'endroit où l'on marche, donc de la zone. */}
        <p className="text-center font-mono text-[13px] leading-[1.6] text-[var(--color-ink)]">
          Jour {run.day} · Les Landes
        </p>
        <p className="text-center font-mono text-[13px] leading-[1.6] text-[var(--color-ink)] opacity-50">
          {lieuNom(run.trav?.current)}
        </p>
      </div>
    </main>
  );
}
