# PACTUM — paquet de playtest (build v1.60.0)

Tu es playtesteur d'un jeu narratif mobile en français, **PACTUM** — un
livre-dont-vous-êtes-le-héros dark fantasy à mort permanente. Tu n'as pas de
navigateur, donc tu ne peux pas ouvrir le jeu (c'est une application qui a
besoin de JavaScript). Ce paquet te donne deux choses à la place : de quoi
**jouer toi-même**, et des **parties réelles enregistrées**.

---

## 1. Lance une partie (c'est le cœur du paquet)

Une commande = un écran. La partie se garde toute seule entre deux commandes.

```bash
cd jouer
python3 pactum.py nouvelle      # ouvre une vie neuve
python3 pactum.py 2             # prend le choix n° 2
python3 pactum.py               # réaffiche l'écran courant
python3 pactum.py etat          # les rouages cachés — pour ton rapport
python3 pactum.py journal       # toute la partie depuis le début
```

Python seul, aucune dépendance, aucun réseau. `nouvelle --graine=42` rejoue
exactement la même vie (utile pour comparer deux façons de jouer), et
`--nom=Cendre` impose le nom du héros.

**Joue au moins deux vies entières**, jusqu'à la mort ou jusqu'à la
« Descente » (la sortie de zone) :

1. une vie **curieuse** — regarde tout ce que le jeu propose de regarder,
   parle à tout le monde ;
2. une vie **pressée** — va droit au but, prends les options d'action.

À la fin de chaque vie, `python3 pactum.py journal` te rend la partie
complète : c'est ce texte-là qu'il faut juger.

### Ce qui est vrai ici, et ce qui ne l'est pas

- Le **contenu est celui du jeu, mot pour mot** : scènes, narrations,
  libellés de choix, les quatre issues écrites de chaque jet de dé, points
  d'intérêt, phrases de marche, citations du Geôlier. Tout est extrait des
  sources du build publié.
- Le **moteur est une réplique simplifiée** de la vraie boucle de jeu :
  dé à vingt faces contre un seuil caché, cinq paliers de résolution, santé
  invisible, traversée par liaisons, points d'intérêt, mort permanente.
- **Ne sont pas répliqués** : les illustrations, le geste tactile du dé, les
  scènes chronométrées, la mémoire entre les vies (Grand Registre, reliques,
  humeur du Geôlier), les besoins, les témoins, les chapitres du Bailli, les
  surprises. Ne les signale pas comme manquants — regarde plutôt les
  transcripts, où tout cela joue.

Dans ton rapport, distingue toujours **ce que tu as joué** de **ce que tu as
lu** dans un transcript ou déduit du code.

---

## 2. Les parties enregistrées — `transcripts/`

2 parties réelles, jouées sur le build publié, dés lancés par la vraie
physique du jeu. Chaque fichier est un script écran par écran : exactement ce
que le joueur a vu, les images affichées, les choix offerts, l'action prise.
C'est la **référence sans dérive** — tout y est citable mot pour mot, et c'est
là que se jugent la mise en scène et le rythme réel.

## 3. Les sources — `sources/`

`lib/` : le contenu et les règles (`scene-data.ts` = toutes les scènes, choix
et issues ; `etats.ts`, `besoins.ts`, `temoins.ts`, `reliques.ts`,
`chapters-data.ts`, `prologue-data.ts`…).
`components/` : le moteur d'affichage (`Scene.tsx` = la boucle de jeu,
`Die3D.tsx` = le dé, `DeathScreen.tsx` = la mort…).

À consulter quand un passage t'intrigue : tu y trouveras les variantes que ta
partie n'a pas tirées.

---

## Ce qu'on te demande de chercher

Classe chaque trouvaille, avec la **citation exacte** et sa provenance
(« joué, écran N », ou nom du transcript, ou fichier) :

1. **Rupture de cohérence** — le texte contredit la situation : un personnage
   ou un décor qui ne peut pas être là, une conséquence sans rapport avec
   l'action, une blessure sans cause, un lieu qui change sans transition.
2. **Rupture d'immersion** — vocabulaire de système qui perce, répétition mot
   pour mot dans une même vie, phrase qui « sent le bouton ».
3. **Blocage ou incohérence mécanique** — un écran d'où rien n'avance ; une
   règle qui en contredit une autre ; un choix qui ne peut jamais s'ouvrir.
4. **Confusion** — un moment où un joueur ne comprendrait pas ce qu'on attend
   de lui, ou pourquoi une chose vient d'arriver. Dis ce que tu as cru, et ce
   qui t'aurait aidé.
5. **Rythme** — trop long, trop court, trop répétitif ; les moments où tu as
   eu envie d'arrêter.

## Ce qui est VOULU (ne le signale pas comme défaut)

- Aucune barre de vie, aucun chiffre de stat ou de seuil montré au joueur.
  Les seuils existent dans le code et dans `pactum.py etat`, c'est normal —
  seul leur **affichage au joueur** serait un défaut.
- La mort permanente, y compris très tôt.
- L'esthétique : trois couleurs, gros pixels, texte tapé lettre à lettre.
- Aucune saisie de texte libre, sauf le nom du héros au prologue.
- Le Soupçon, les états, le Geôlier : des mécaniques cachées, lisibles
  seulement dans le monde. C'est le cœur du design.
- Dans `scene-data.ts`, les préfixes « 20 naturel. » et suffixes « ♦ −2 » sont
  des marqueurs d'écriture : le jeu les retire à l'affichage.

## Format du rapport

Une liste numérotée, la plus grave d'abord. Pour chaque entrée : la catégorie,
la citation exacte, sa provenance, et — si tu en as une — ta suggestion en une
phrase. Termine par un avis global de joueur : ce qui t'a retenu, ce qui t'a
perdu, et si tu aurais relancé une troisième vie.
