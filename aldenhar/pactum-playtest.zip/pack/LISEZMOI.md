# PACTUM — paquet de playtest pour analyse hors ligne

Tu es playtesteur d'un jeu narratif mobile en français, **PACTUM** — un
livre-dont-vous-êtes-le-héros dark fantasy à mort permanente. Tu n'as pas
de navigateur : ce paquet te donne le vrai matériau du jeu, tel que déployé
(build v1.51.1 du 8/08/2026).

## Contenu

- **`transcripts/`** — TROIS PARTIES RÉELLES ET COMPLÈTES, jouées sur le
  build publié juste avant l'assemblage de ce paquet, dés lancés par la
  vraie physique du jeu. Chaque fichier est un script écran par écran :
  exactement ce que le joueur a vu, les choix offerts, l'action prise.
  **C'est ta source principale** — tout y est citable mot pour mot.
- **`sources/lib/`** — le contenu et les règles : `scene-data.ts` (toutes
  les scènes, choix, issues de jets), `etats.ts`, `besoins.ts`,
  `temoins.ts`, `reliques.ts`, `surprises.ts`, `chapters-data.ts`,
  `jailer-quotes.ts`, `prologue-data.ts`…
- **`sources/components/`** — le moteur d'affichage (`Scene.tsx` : la
  boucle de jeu ; `Die3D.tsx` : le dé ; `DeathScreen.tsx` : la mort…).

## Ta mission

1. **Lis les trois transcripts comme un joueur** — du premier écran au
   dernier. C'est là que se jugent le rythme, la cohérence, l'immersion.
2. Croise avec les sources quand un passage t'intrigue : `scene-data.ts`
   contient toutes les variantes que les transcripts n'ont pas tirées.
3. Si tu veux aller plus loin, tu peux simuler des parcours à partir des
   sources — mais dans ton rapport, **distingue toujours ce que tu as LU
   dans un transcript de ce que tu as déduit du code**.

## Ce qu'on te demande de chercher

Classe chaque trouvaille, avec la **citation exacte** et le fichier/écran :

1. **Rupture de cohérence** — le texte contredit la situation (personnage
   ou décor qui ne peut pas être là, conséquence sans rapport avec
   l'action, blessure sans cause, lieu qui change sans transition).
2. **Rupture d'immersion** — vocabulaire de système qui perce, répétition
   mot pour mot dans une même vie, phrase qui « sent le bouton ».
3. **Blocage ou incohérence mécanique** — dans les transcripts : un écran
   d'où rien n'avance ; dans les sources : une règle qui contredit une
   autre, un choix qui ne peut jamais s'ouvrir, une issue impossible.
4. **Confusion** — moment où un joueur ne comprendrait pas ce que le jeu
   attend de lui, ou pourquoi une chose vient d'arriver.
5. **Rythme** — passages trop longs, trop courts, trop répétitifs.

## Ce qui est VOULU (ne le signale pas comme défaut)

- Aucune barre de vie, aucun chiffre de stat ou de seuil affiché au
  joueur ; les seuils existent dans le code, c'est normal — seul leur
  AFFICHAGE serait un défaut.
- La mort permanente, y compris tôt dans la partie.
- L'esthétique : 3 couleurs, gros pixels, tremblements, texte tapé lettre
  à lettre ; les transcripts notent parfois des artefacts de capture
  (texte tronqué à ~600 caractères) — c'est la télémétrie, pas le jeu.
- Aucune saisie de texte libre (sauf le nom du héros au prologue).
- Le Soupçon, les états, le Geôlier : mécaniques cachées lisibles
  seulement dans le monde — c'est le cœur du design.
- Les préfixes « 20 naturel. » et suffixes « ♦ −2 » dans `scene-data.ts`
  sont des marqueurs d'écriture : ils sont retirés à l'affichage.

## Format du rapport

Une liste numérotée, la plus grave d'abord. Pour chaque entrée : la
catégorie, la citation exacte, sa source (transcript + n° d'écran, ou
fichier), et — si tu en as une — ta suggestion en une phrase. Termine par
un avis global de joueur : ce qui t'a retenu, ce qui t'a perdu, et si tu
aurais relancé une troisième vie.
