# Partie de découverte — v157B (budget épuisé)

## [0] —
*image : geolier_detoure.png, pactum_logo.png*

Tu choisis. Le dé décide.
Lui, il regarde.

COMMENCER
OPTIONS
v1.57.0

CHOIX : [COMMENCER] [OPTIONS]
→ accueil

## [1] —
*image : intro_demon.png*

Tu ne te souviens pas

D'être entré, je veux dire. Personne ne s'en souvient. Tu es mort. Il y a peu.

Ce qui suit est une proposition. Personne ne l'a jamais refusée.

Touche pour commencer

→ continue

## [2] —

Une seule vie

Tu traverses mon Domaine. Une fois. Au bout, une Porte scellée : franchis-la, et tu reprends ta vie là où tu l'as laissée.

Si tu meurs, un autre viendra. Avec un autre nom.

→ continue

## [3] —
*image : intro_de.png*

Le dé tranche

Ton adresse ne te sauvera pas. Courage, ruse, instinct, empathie : ce que tu vaux vient de ce que tu étais de ton vivant.

Touche pour continuer

→ continue

## [4] —
*image : intro_epee.png*

Ta mort me sert

Ta fin est forgée en Relique. Celui qui te suivra la portera. On ne progresse pas ici en survivant. En tombant mieux.

Touche pour continuer

→ continue

## [6] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Avant que tu passes, je veux voir qui tu étais.

Touche pour continuer

→ continue

## [8] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Ne réfléchis pas. Ce n'est plus toi qui choisis, ici — c'est ce que tu as déjà fait.

Touche pour continuer

→ continue

## [10] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Un homme coule au milieu du lac gelé, personne ne bouge autour de toi.

Plonger malgré le froid
Lancer une corde depuis la berge
Détourner le regard

CHOIX : [Plonger malgré le froid] [Lancer une corde depuis la berge] [Détourner le regard]
→ choix: Plonger malgré le froid

## [12] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Une trace au sol ne correspond à aucun animal que tu connais.

Suivre la fausse piste toi-même
Éviter, prendre un chemin détourné
L'ignorer, avancer tout droit

CHOIX : [Suivre la fausse piste toi-même] [Éviter, prendre un chemin détourné] [L'ignorer, avancer tout droit]
→ choix: Suivre la fausse piste toi-même

## [14] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Une nuée de corbeaux se pose sur un même arbre, sans un cri, sans bouger.

Éviter cet arbre largement
T'approcher, observer de près
Continuer sans y prêter attention

CHOIX : [Éviter cet arbre largement] [T'approcher, observer de près] [Continuer sans y prêter attention]
→ choix: T'approcher, observer de près

## [16] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Un homme peine à parler devant une foule qui rit de lui.

Prendre sa défense publiquement
Lui parler en privé, après
Rire avec les autres, par gêne

CHOIX : [Prendre sa défense publiquement] [Lui parler en privé, après] [Rire avec les autres, par gêne]
→ choix: Rire avec les autres, par gêne

## [18] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Une dernière chose. J'ai vu qui tu étais. Il me manque comment on t'appelait.

SCELLER LE PACTE
Qu'il choisisse pour moi

CHOIX : [Qu'il choisisse pour moi]
→ sceller le pacte

## [20] borne-frontiere · Jour 1 · santé 1
*image : intro_demon.png*

Tu avances avant de comprendre. Le danger t'a toujours moins arrêté que le doute.
Mais les autres restent pour toi un bruit de fond. Ça t'a coûté. Ça te coûtera encore.

Je sais qui tu es. Le dé, lui, décidera qui tu deviens.

Touche pour commencer

→ continue

## [21] borne-frontiere · Jour 1 · santé 1
*image : scene_landes_frise_montagnes_pleine_b.png*

• LE DOMAINE •

Les Lisières

Touche pour continuer

→ continue

## [25] borne-frontiere · Jour 1 · santé 1
*image : scene_borne_frontiere_v2_a.png, geolier_portrait.png*

— JOUR 1 —

La lande s'ouvre sous un crépuscule qui ne tombe pas. La lumière reste prise entre chien et loup, comme un souffle retenu. Quelque part, une corde grince.

La pierre est seule au milieu du plateau, dressée là où tous les murets renoncent. Haute comme un homme, grise comme le reste — et pourtant l'œil ne voit qu'elle. À son pied, un tas d'offrandes. Au-delà, le sud, nu. Et à trois pas de la borne, un homme immobile, face au sud.

À partir de maintenant, il décide avec moi.

CHOIX : [Observer les alentours] [Fouiller les offrandes RUSE]
→ choix: Écouter, immobile

## [30] borne-frontiere · Jour 1 · santé 1
*image : scene_borne_frontiere_v2_a.png*

Tu ne touches à rien. Tu écoutes. Sous le vent, il y a des voix — basses, à ras de bruyère, qui se passent le mot de ton arrivée. Elles ne te menacent pas. Elles préviennent quelqu'un. Au moins, maintenant, tu sais que la lande parle.

La bruyère efface derrière toi les traces de ceux qui ont choisi avant. Devant, elle ne promet rien.

Deux directions s'ouvrent. D'un côté, des rangées de piquets jusqu'à l'horizon. De l'autre, une crête hérissée de mâts noirs.

→ continue

## [32] borne-frontiere · Jour 1 · santé 1
*image : scene_landes_liaison_plateau_d.png*

Un vieux, assis contre un muret, gratte une planchette sans te regarder. « Tout le monde a sa ligne, ici », dit-il. « Nom, motif, jours. Même toi — surtout toi. Elle est déjà ouverte. »

CHOIX : [Vers les rangées de poteaux] [Vers la crête aux cordes]
→ choix: Vers la crête aux cordes

## [37] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1
*image : scene_colline_aux_gibets_c.png*

Tu montes. Les mâts deviennent des potences.

Tu es passé sous le vent. Rien ne s'est retourné, et tu n'as regardé que tes pieds.

La pente est douce et n'en finit pas — la Colline se mérite à pas comptés. Au sommet, le cercle : neuf potences ordinaires, plantées comme les heures d'un cadran. Et au centre, l'autre. La grande. Sa corde est la seule chose neuve à dix lieues.

À gauche du cercle, un poteau isolé porte encore son occupant. À droite, les potences vides alignent leurs noms gravés.

CHOIX : [Le pied du grand gibet] [Observer les alentours] [Rester au sommet]
→ choix: Les corbeaux, sur la traverse

## [40] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_corbeaux_du_compte_b.png*

Ils sont sur la traverse du grand gibet, immobiles, et ils ne bougent pas quand tu approches — ce qui n'est pas un comportement d'oiseau. Aucun ne te regarde. Ils regardent la corde.

→ continue

## [43] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_corbeaux_du_compte_b.png*

Ils ne mangent pas. Il n'y a rien à manger ici depuis longtemps, et leurs becs sont propres. Ils attendent, et ils sont exactement assez nombreux pour ce qu'ils attendent. La même immobilité que des sentinelles payées d'avance, la même façon d'être tournés du même côté — comme des choses qu'on a postées là. Ils comptent quelque chose qui te concerne, et le compte n'a pas l'air fini.

Il n'y en a qu'un, et il se tient de travers, comme s'il gardait une place. Tu ne sais pas pour qui.

CHOIX : [Le pied du grand gibet] [Observer les alentours] [Rester au sommet]
→ choix: Le Gibet Vide, au centre

## [47] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_gibet_vide_a_b.png*

Tu marches vers le centre, et la chose grandit plus vite que tes pas. À dix mètres, tu comprends que tu avais mal jugé l'échelle. À trois, tu dois lever la tête pour voir le nœud.

Le bois est d'œuvre, assemblé pour durer mille ans. La corde neuve grince. Par grand soleil — rare, ici — l'ombre portée s'étend vers le sud, et elle a une forme que la potence n'explique pas.

→ continue

## [50] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_gibet_vide_a_b.png*

La formule est toujours la même, tu commences à la reconnaître : un nom, deux mots de motif, un nombre. Jamais de date. Comme si le jour n'avait pas d'importance — seulement combien de jours la personne avait tenu avant.

On raconte que le grand gibet a été taillé pour le Bailli, du temps où il jugeait encore. « À sa mesure », répètent ceux qui tiennent l'histoire — sans jamais expliquer quelle mesure il faudrait à un homme pour une traverse pareille.

CHOIX : [Le pied du grand gibet] [Observer les alentours] [Rester au sommet]
→ choix: Le pied du grand gibet

## [53] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_pied_grand_gibet_b.png*

Tu quittes la ligne des potences ordinaires pour celle qui les dépasse toutes. De près, elle est absurde : trois fois trop haute pour un homme, et sa corde est neuve.

Au pied du mât, dans le bois, un nom a été gravé profond, à la gouge, par quelqu’un qui prenait son temps. Il est illisible — pas effacé par la pluie : GRATTÉ, en travers, par quelque chose qui a mordu le bois plus fort que l’outil. Dessous, une date est restée entière. Elle est vieille de trente ans.

CHOIX : [Les potences du cercle] [Le poteau isolé, à gauche] [Rester au sommet]
→ choix: Les potences du cercle

## [56] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_potences_cercle_a_c.png*

Tu entres dans le cercle. Le vent monte d'un cran dès le premier pas entre deux potences — pas plus fort ailleurs, plus fort ICI, comme si l'espace entre les mâts avait son climat.

Chaque potence porte un nom gravé au pied, et une date. Les entailles sont de la même main — appliquée, régulière, la main de quelqu'un qui grave comme on rend un jugement.

→ continue

## [58] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_potences_cercle_a_c.png*

Le motif qui revient le plus n'est pas le vol, ni le meurtre. C'est trois mots : « a parlé dehors ». Tu ne sais pas encore ce qu'on parlait, ni à qui, ni pourquoi le dehors compte.

CHOIX : [Le poteau isolé, à gauche] [Rester au sommet]
→ choix: Le poteau isolé, à gauche

## [61] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_landes_poteau_pendu_c.png*

Tu contournes le cercle par la gauche. Le poteau isolé est plus bas que les autres — à hauteur d'homme, exactement. Une hauteur qu'on choisit.

Chaîne de fonction au cou, sous la corde. Un sceau au poing. Et les yeux qui s'ouvrent quand tu arrives à portée de voix : le Bailli des Landes, pendu le dernier, à la place d'honneur.

CHOIX : [Rester au sommet]
→ choix: Rester au sommet

## [65] colline-aux-gibets-2 · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_gibets_2_a.png, etat_hante.png*

Hanté
Ce que tu as vu ne s'est pas rangé. Ça reste posé de travers dans ta tête, et ça bouge quand tu ne le regardes pas.

Le vent tombe d'un coup, comme on ferme une porte. Et dans ce calme plat, les neuf cordes du cercle se mettent à bouger. Pas au hasard : ensemble. Un balancement lent, réglé, qui va et vient sur le même temps.

Ça grince en mesure. Neuf cordes, un seul rythme. Tu comprends, avec un retard qui te coûte, que ce rythme ne t'est pas indifférent — tu pourrais le compter.

Quelque chose grince très haut, très loin, à une hauteur où il n'y a rien.

CHOIX : [Hanté Ce que tu as vu ne s'est pas rangé. Ça reste posé de travers dans ta tête, et ça bouge quand tu ne le regardes pas.] [Partir avant de comprendre] [Rester et compter INSTINCT] [Arracher une écharde COURAGE]
DÉ → RÉUSSITE ÉCLATANTE
→ lance le dé

## [70] troupeau-sans-berger · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_troupeau_sans_berger_a.png*

Tu comptes. Le nombre est petit, et c'est le pire : les cordes ne battent pas les morts de la lande. Elles battent les tiennes. Le compte est juste. Tu redescends sans le dire à voix haute.

Des bêtes broutent la bruyère morte au creux du vallon — un troupeau entier, sans personne. Elles ne s’écartent pas quand tu approches : elles lèvent la tête, te regardent une seconde, et se remettent à brouter.

C’est ce détail qui te dérange le plus. Elles n’ont pas appris à se méfier.

CHOIX : [Ne plus afficher]
→ continue

## [72] troupeau-sans-berger · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_troupeau_sans_berger_a.png*

Tu comptes ce qui t'entoure — les ombres, les pierres. Il y en a toujours une de plus au deuxième compte.

CHOIX : [Les marques d’oreille] [S’avancer dans le vallon] [Ne plus afficher]
→ choix: S’avancer dans le vallon

## [77] troupeau-sans-berger-2 · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_troupeau_brebis_v2_b.png*

Une brebis s’écarte du groupe et marche droit vers le nord-est, s’arrête, revient. Puis recommence. Cinq fois pendant que tu la regardes.

Elle refait un trajet. Elle attend au bout de quelque chose qui n’arrive plus.

Dans cette direction, à un quart d’heure de marche, il y a le Champ des Fixés.

Une ombre passe à ta gauche, à la vitesse d'un homme qui marche. Quand tu regardes, rien ne marche nulle part.

CHOIX : [Continuer ton chemin] [Suivre la brebis]
→ choix: Suivre la brebis

## [81] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_des_fixes_b.png*

— JOUR 2 —

L'horizon se hérisse de piquets réguliers, rangée après rangée, jusqu'à se perdre. Tu approches d'un champ qu'on n'a pas semé — on l'a planté d'hommes.

Tu es venu par le flanc, le nez au sol. Personne ne t'a vu. Toi non plus.

Pas de tombes — des poteaux. Des rangées de poteaux plantés droit, un nom sur chaque, alignés face au nord. Dos au sud. Même morts, surtout morts, on ne les laisse pas regarder par là.

→ continue

## [85] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_des_fixes_b.png*

Au fond, des poteaux vierges attendent, déjà plantés. Près de l'entrée, la cabane du Fossoyeur.

Le champ entier est un registre debout. Chaque poteau son pendu, chaque pendu son écriteau : un nom, un motif, un nombre de jours. Une écriture de greffe, appliquée, sans colère.

Un seul écriteau détonne : le motif a été gratté au couteau, si fort que le bois est entaillé. Le nom reste, le nombre de jours reste. Ce qu'elle avait fait, quelqu'un n'a pas supporté qu'on le lise.

CHOIX : [Les rangées et leurs noms] [Observer les alentours] [Rester dans le champ]
→ choix: Les rangées et leurs noms

## [88] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_les_rangees_v2_a.png*

Tu marches entre deux rangs. Le sol est tassé par des allées et venues régulières — on entretient ce champ comme un jardin, et c'est ça qui serre le ventre.

Les noms des premières rangées sont presque effacés. Les dernières sont fraîches. Entre les deux, une rangée entière porte la même date — un seul jour, neuf fixations. Il y a une histoire là-dedans que personne ne raconte.

→ continue

## [90] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_les_rangees_v2_a.png*

Une ligne du registre n'a pas de nom. Le motif est rempli, le nombre de jours aussi — quatre-vingt-onze — et l'emplacement du nom est laissé propre. Pas gratté : jamais écrit. Quelqu'un a compté une vie sans accepter de la nommer.

CHOIX : [Les poteaux vierges, au fond] [Un vide dans une rangée pleine] [Rester dans le champ]
→ choix: Rester dans le champ

## [94] champ-des-fixes-2 · Jour 2 · santé 1 · soupçon 1 · hante
*image : monstre_fossoyeur_poteaux_a.png*

Entre les rangs, un vieil homme redresse un poteau qui penche, avec des gestes de jardinier. Il t'a vu venir de loin — les vivants font un bruit particulier, ici. Il ne s'interrompt pas : il t'attend au travail, comme on attend un outil. « La Colline, c'est la vitrine », dit-il sans qu'on demande. « Ici, c'est l'arrière-boutique. »

Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Pendant une seconde, le sol sous tes pieds est de la terre retournée de frais.

OBTENU — ONGUENT GRIS · COMMUN
L'étiquette est illisible. L'odeur, convaincante.

CHOIX : [Passer sans un mot] [Aider à redresser EMPATHIE]
DÉ → RÉUSSITE ÉCLATANTE
→ lance le dé

## [105] champ-des-fixes-2 · Jour 3 · santé 0.74 · soupçon 2 · hante
*image : monstre_fossoyeur_poteaux_a.png*

Le poteau t'échappe et le pendu chasse au bout de sa corde, dans un grand désordre de chanvre. Tout le rang se met à osciller de proche en proche. Le Fossoyeur te chasse à gestes secs : tu as réveillé le dortoir.

— JOUR 3 —

La lande t'a pris un jour. La lumière a tourné sans que tu avances.

Deux silhouettes réparent un muret à distance. Leurs mains ne s'arrêtent pas quand tu passes. Leurs têtes, si.

→ continue

## [108] champ-des-fixes-2 · Jour 3 · santé 0.74 · soupçon 2 · hante
*image : scene_hameau_dense_b.png*

D'un côté, des toits bas et une fumée qui ne monte pas droit. De l'autre, un gibet bas, à hauteur d'homme, qui bouge sans vent.

— « Tu comptes, toi aussi. » Personne autour de toi n'a ouvert la bouche.

CHOIX : [Vers la fumée d'un hameau] [Vers un gibet qui parle]
→ choix: Vers la fumée d'un hameau

## [112] serment-hameau · Jour 3 · santé 0.74 · soupçon 2 · hante
*image : scene_hameau_dense2_b.png*

Derrière toi, très loin, des battements d'ailes quittent une traverse — exactement le compte que tu n'as pas voulu faire. Un battement de plus leur répond. Plus près.

De la fumée basse, pas une flamme : des toits gris tassés derrière leurs murets. Le Hameau des Renonçants se découvre lentement, et déjà tu sens qu'on t'a vu venir de loin.

Tu es entré par où tout le monde entre. Ça se remarque, et ça permet de voir venir.

→ continue

## [116] serment-hameau · Jour 3 · santé 0.74 · soupçon 2 · hante
*image : scene_hameau_dense2_b.png*

Les toits apparaissent au creux du plateau — de l'ardoise affaissée, des murs qui tiennent par habitude. Une seule cheminée fume, sur une vingtaine.

Tu es encore loin quand tu comprends ce qui cloche : aucun chien n'aboie.

Deux femmes s'arrêtent de parler quand tu passes — mais tu as saisi la fin : « … au Hameau des Renonçants. C'est L'Écrivain public qui l'a dit. » Elles reprennent leur chemin, plus vite que nécessaire.

→ continue

## [119] serment-hameau · Jour 3 · santé 0.74 · soupçon 2 · hante
*image : scene_hameau_dense2_b.png*

Il y a un corbeau sur le toit d'en face. Il y était déjà dans l'autre rue.

Une conversation s'éteint à ton approche. Pas interrompue : pliée, rangée, comme du linge qu'on rentre avant la pluie.

CHOIX : [Observer d'abord, à couvert INSTINCT] [Descendre vers le hameau] [Utiliser — Onguent gris]
DÉ → FUNESTE
→ lance le dé

## [131] hameau-entree-2 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : scene_hameau_entree_2_v2_a.png*

Tu restes trop longtemps immobile face au village. Quand tu te redresses enfin, une silhouette se détache d'une porte, en bas, et rentre vite. Quelqu'un t'a vu observer — et observer, ici, n'est pas une chose innocente.

La première maison est à dix pas. Sur sa porte, un signe à la craie — une croix, simple, tracée à hauteur d'œil.

La poudre blanche est encore sur le seuil. Ça date de ce matin.

Tu portes la main à ton cou. Il n'y a rien. Tu l'y portes quand même.

→ continue

## [134] hameau-entree-2 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : scene_hameau_entree_2_v2_a.png*

Six, sur le faîtage d'en face. Tu changes de rue : le compte ne change pas.

Une mère tire son enfant à l'intérieur sans un mot. Plus loin, la Doyenne croise ton chemin et parle sans s'arrêter : « Quoi que tu entendes, ne réponds pas. Ici, on regarde les bouches. »

CHOIX : [Le linteau de la porte] [Observer les alentours] [Continuer dans la rue] [Utiliser — Onguent gris]
→ choix: Le gamin, en haut du muret

## [138] gamin-murets-1 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : monstre_gamin_murets_a.png*

Un enfant est assis sur la crête d'un muret, les pieds dans le vide côté lande. Il ne joue à rien. Il regarde le sud comme les adultes d'ici regardent le sud, et il le fait mieux qu'eux.

Il te laisse arriver jusqu'au pied du muret sans bouger. De près, ses genoux sont râpés partout pareil — quelqu'un qui court sur la pierre, pas sur les chemins. Il attend que tu parles le premier.

→ continue

## [141] gamin-murets-1 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : monstre_gamin_murets_a.png*

Il aligne des cailloux sur le muret, par taille. Il ne se cache pas de toi : c’est le premier habitant qui ne se méfie pas. « T’es le nouveau. T’as combien de corbeaux ? »

Il n’attend pas la réponse, et compte sur ses doigts. « Trois avant toi cette année. Deux sont ressortis. »

→ continue

## [144] gamin-murets-1 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : monstre_gamin_murets_a.png*

Il désigne la lande du menton, la crête des murets qui court vers le sud, basse et sèche. « Y a le chemin, et y a les murets. Le chemin, il fait le tour de tout. Les murets, non. »

Deux femmes s'arrêtent de parler quand tu passes — mais tu as saisi la fin : « … à l'entrée du Hameau. C'est Le Gamin des Murets qui l'a dit. » Elles reprennent leur chemin, plus vite que nécessaire.

→ continue

## [146] gamin-murets-1 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : monstre_gamin_murets_a.png*

Six corbeaux se posent quand tu débouches dans la rue — sans un cri, sans une dispute, comme des gens qui prennent leur poste.

CHOIX : [Lui demander de te guider EMPATHIE] [Lui demander qui est ressorti] [Le laisser sur son mur] [Utiliser — Onguent gris]
→ choix: Lui demander qui est ressorti

## [149] gamin-murets-2 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : scene_murets_vers_sud_c.png*

« Le grand avec la lanterne. Et une dame, mais elle a pas pris le sud. » Il replie deux doigts. « L’autre, il est allé jusqu’à la palissade. Il a fait demi-tour. Il dit que c’est pas fermé, c’est juste que ça retient. »

Le muret repart vers le sud, à hauteur de hanche, en pierre sèche posée sans mortier. On voit à l’usure du sommet que quelqu’un y marche tous les jours, et que ce quelqu’un est petit.

→ continue

## [151] gamin-murets-2 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : scene_murets_vers_sud_c.png*

Le vent dit un nom. Ce n'est pas le tien. Tu le retiens quand même.

Ils sont six, alignés, du même côté.

CHOIX : [Reprendre la ruelle] [Utiliser — Onguent gris]
→ choix: Reprendre la ruelle

## [154] gamin-murets-3 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : monstre_gamin_caillou_c.png*

Tu laisses le muret filer vers le sud sans toi. La ruelle, elle, fait le tour de tout — c’est bien ce qu’il avait dit.

« Moi j’en ai zéro », dit-il en revenant à ses cailloux. « Ma mère en a deux. Elle sait pas. Faut pas lui dire, elle a peur pour rien. »

→ continue

## [158] gamin-murets-3 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : monstre_gamin_caillou_c.png, geolier_portrait.png*

Il fouille dans sa poche et te tend une pierre plate, grise, polie comme un galet de rivière. Il n’y a pas de rivière dans les Landes. « C’est la dame de l’ouest qui me l’a donnée. »

Six, sur le faîtage d'en face. Tu changes de rue : le compte ne change pas.

Un enfant, un caillou, et personne pour l’écouter. C’est ainsi que commencent la plupart des vérités.

CHOIX : [Ne pas relever] [« Où l’as-tu vue ? » INSTINCT] [« Quelle dame ? »] [Utiliser — Onguent gris]
→ choix: « Quelle dame ? »

## [161] gamin-murets-4 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : monstre_gamin_depart_c.png*

« Ben, la dame. » Il hausse les épaules, comme si tu demandais de quelle couleur est le ciel. « Elle est jeune. Elle a un châle. Elle marche du côté du moulin, là où l’herbe est couchée. » Il repose un caillou dans la rangée, très exactement à sa place.

OBTENU — CAILLOU DE RIVIÈRE · COMMUN
Plat, gris, poli par une eau qui n'existe nulle part ici. Un enfant te l'a mis dans la main sans que tu le demandes.

« Ma mère dit que j’invente. Le rebouteux dit que j’invente. Tout le monde dit que j’invente. » Il te regarde enfin, droit. « Mais le caillou, il est vrai. Tu le tiens. »

→ continue

## [164] gamin-murets-4 · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : monstre_gamin_depart_c.png*

Il redescend du muret et ramasse ses pierres une par une, dans l’ordre. « Si tu la vois, dis-lui merci pour le caillou. J’ai oublié la dernière fois. »

Six corbeaux se posent quand tu débouches dans la rue — sans un cri, sans une dispute, comme des gens qui prennent leur poste.

CHOIX : [Le lui promettre] [Ne rien promettre] [Utiliser — Onguent gris]
→ choix: Le lui promettre

## [167] hameau-accueil-enfant · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : scene_hameau_accueil_enfant_c.png*

Il hoche la tête, satisfait, et ne vérifie pas. À dix ans, on croit encore qu’une promesse et une chose faite sont la même chose. Tu redescends la ruelle avec un caillou de rivière dans la main, dans un pays qui n’a pas de rivière.

Ils ont envoyé un gosse. Huit ans peut-être, planté au milieu de la rue, les mains dans le dos comme on lui a dit de les tenir. Aucun adulte visible — et tous les volets entrouverts de deux doigts.

→ continue

## [170] hameau-accueil-enfant · Jour 3 · santé 0.58 · soupçon 3 · hante
*image : scene_hameau_accueil_enfant_c.png*

Il récite. On entend les mots appris, dans l'ordre, avec les silences qu'on lui a fait répéter : — « Est-ce que tu dors la nuit ? Est-ce que tu as compté quelque chose aujourd'hui ? Est-ce qu'on t'a appelé par ton nom depuis que tu es descendu ? »

Il ne comprend pas ce qu'il demande. Les autres, si.

Ils sont six, alignés, du même côté.

CHOIX : [Ne pas répondre à un enfant] [Répondre à l'enfant EMPATHIE] [Répondre aux volets RUSE] [Utiliser — Onguent gris]
DÉ → ÉCHEC
→ lance le dé

## [181] hameau-entree-4 · Jour 4 · santé 0.32 · soupçon 4 · hante,fixe
*image : monstre_hameau_entree_4_c.png, etat_fixe.png*

Fixé
On ne te parle plus tout à fait à toi. On parle devant toi, de toi, à voix normale, comme on parle devant un poteau déjà planté.

Tu réponds à l'enfant, gentiment — et tu oublies les vingt personnes qui écoutent. Ta deuxième réponse est trop longue, trop précise. Un adulte sort avant la fin et le tire par le bras à l'intérieur.

— JOUR 4 —

La lande t'a pris un jour. La lumière a tourné sans que tu avances.

Au bout de la rue, un muret bas ferme le village côté sud. Le vieux y est assis, sec comme un piquet, les coudes sur les genoux. Il t'attendait là depuis le début.

CHOIX : [Fixé On ne te parle plus tout à fait à toi. On parle devant toi, de toi, à voix normale, comme on parle devant un poteau déjà planté.]
→ choix: Entrer dans le hameau

## [203] hameau-entree-5 · Jour 4 · santé 0.32 · soupçon 4 · hante,fixe
*image : scene_hameau_dense_c.png*

Il y a des traces fraîches sur ton chemin — devant toi. Quelqu'un fait ta route avant toi, dans le même sens, à petite distance. Tu ne le rattrapes jamais.

D'un côté, un chemin qui s'enfonce entre deux talus. De l'autre, des rangs d'arbres qui n'ont plus de feuilles.

CHOIX : [Vers le chemin creux] [Vers des rangs d'arbres noirs]
→ choix: Vers le chemin creux

## [207] bete-chemins-creux · Jour 4 · santé 0.32 · soupçon 4 · hante,fixe
*image : monstre_bete_chemins_creux_a.png*

• RENCONTRE •
La Bête des Chemins Creux

Les dernières maisons s'espacent, puis renoncent. Devant toi la bruyère morte reprend ses droits jusqu'à l'horizon. Dans ton dos, quelqu'un referme une porte, sans se presser.

Le sol se creuse sous tes pas, et le ciel se rétrécit à mesure que tu descends.

Tu n'as rien contourné. Tu arrives par la face, et rien ne t'a échappé en chemin.

→ continue

## [210] bete-chemins-creux · Jour 4 · santé 0.32 · soupçon 4 · hante,fixe
*image : monstre_bete_chemins_creux_a.png*

Le creux tourne — et l'odeur arrive avant la chose : suint, terre retournée, vieux cuir. Une masse se décolle du talus, longue, basse, taillée pour courir exactement entre deux murs de terre.

Pas de gueule visible. Juste une avancée du corps qui s'ouvre. La Bête ne chasse que dans le creux — c'est son couloir, son terrier, sa table. Et tu es dessus.

CHOIX : [Frapper la bête COURAGE] [Bondir hors du creux INSTINCT] [Se plaquer, immobile] [Utiliser — Onguent gris]
DÉ → FUNESTE
→ lance le dé

## [220] chemin-creux · Jour 4 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_chemin_creux_c.png, etat_boiteux.png, etat_entaille.png*

Boiteux
Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé.
Entaillé
La blessure ralentit chaque geste, tant qu'elle n'est pas soignée.

Ta lame racle du cuir sans entamer. L'avancée du corps te cueille à l'épaule et te plaque au talus — tu te dégages en y laissant du tien, et elle te laisse passer, servie.

Le chemin s'enfonce entre deux talus plus hauts que toi ; le ciel devient un ruban. C'est le plus court chemin des Landes, et le seul où l'on ne voit pas venir.

CHOIX : [Boiteux Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé.] [Entaillé La blessure ralentit chaque geste, tant qu'elle n'est pas soignée.]
→ choix: Le haut des talus

## [227] chemin-creux · Jour 4 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_chemin_talus_a_c.png*

Tu montes de trois pas dans la pente, juste assez pour voir la crête sans t'exposer entièrement. La terre y est meuble, retournée.

Des empreintes. Parallèles au chemin. Sur toute sa longueur — mais sur la crête NORD seulement : l'autre versant est intact, pas une marque. Quelque chose marche là-haut quand quelqu'un marche en bas, à la même vitesse, du même pas, et toujours du même côté. Tu redescends sans te presser, parce que se presser serait une information.

CHOIX : [La charrette embourbée] [L'homme qui marche à reculons] [Couper par la lande INSTINCT] [Utiliser — Onguent gris]
DÉ → ÉCHEC
→ lance le dé

## [238] chemin-creux-2 · Jour 4 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_chemin_creux_coude_b.png, etat_boiteux.png, etat_entaille.png*

Boiteux
Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé.
Entaillé
La blessure ralentit chaque geste, tant qu'elle n'est pas soignée.

Tu grimpes le talus et marches à découvert. La lande te voit — mais rien ne te suit. Le chemin creux, en dessous, continue sans toi.

Le chemin tourne, et le talus mange la vue d'un coup. Passé le coude : rien. C'est-à-dire l'endroit exact où il devrait y avoir quelque chose, et il n'y a rien.

Le silence y est plus épais d'un cran, comme après un bruit que tu aurais raté d'une seconde.

CHOIX : [Boiteux Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé.] [Entaillé La blessure ralentit chaque geste, tant qu'elle n'est pas soignée.]
→ choix: Longer le côté sud

## [243] chemin-creux-2 · Jour 4 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_chemin_creux_coude_b.png*

Tu passes le coude épaule contre le talus SUD, du côté vierge d'empreintes, et tu marches sans accélérer. Au-dessus, à droite, sur la crête nord, quelque chose t'accompagne un moment — puis s'arrête, parce que le versant s'interrompt et qu'elle ne traverse pas. Tu ressors du creux entier, et sans avoir couru.

Tu t'arrêtes deux fois pour souffler. La deuxième, la pierre où tu poses la main reste marquée de rouge. Le Domaine te goûte déjà.

→ continue

## [245] chemin-creux-2 · Jour 4 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_landes_liaison_sud_c.png*

D'un côté, une palissade qui coupe l'horizon, une lanterne allumée en plein jour. De l'autre, une masse trapue privée de ses ailes.

CHOIX : [Vers une palissade au sud] [Vers un moulin sans ailes]
→ choix: Vers un moulin sans ailes

## [250] campement · Jour 5 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_moulin_sans_ailes_d_d.png*

— JOUR 5 —

Tu quittes les toits. La masse trapue grandit contre le crépuscule.

Tu as pris la route droite. On t'a vu venir — et tu as eu le temps de tout regarder.

Le moulin n'a plus d'ailes mais il a gardé leur trace : quatre ombres pâles en croix sur le corps de pierre, comme un moulin fantôme peint sur le vrai.

La porte est entrouverte. Pas défoncée : entretenue. La croix d'ombres, en haut. La lucarne, qui te regarde. Et la porte, qui n'attend que toi.

→ continue

## [252] campement · Jour 5 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_moulin_sans_ailes_d_d.png*

Le chemin monte, et tu comptes tes pas comme on compte de la monnaie.

CHOIX : [Observer les alentours] [Écouter le moulin INSTINCT] [S'installer pour la halte] [Utiliser — Onguent gris]
→ choix: Fouiller le lit de bruyère

## [255] campement-2 · Jour 5 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_moulin_campement_2_a.png*

Sous la bruyère, la pierre du mur porte des marques à hauteur d'enfant : des jours comptés par paquets de cinq, sur des années. Et dans un creux, serré dans un chiffon, un bout de corde. Coupé net. On ne garde pas ça par hasard — on garde ça comme une preuve, ou comme un pardon.

→ continue

## [257] campement-2 · Jour 5 · santé 0.16 · soupçon 4 · hante,fixe,boiteux
*image : scene_moulin_campement_2_a.png*

Par la lucarne, le crépuscule ne bouge pas. On dit qu'une fille dort ici, parfois — la seule pendue qui se soit relevée. Le lit de bruyère garde une forme légère, comme un creux encore tiède.

CHOIX : [Dormir malgré le crépuscule] [Monter la garde INSTINCT] [Repartir sans s'attarder] [Utiliser — Onguent gris]
→ choix: Dormir malgré le crépuscule

## [260] campement-2 · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_landes_liaison_sud_c.png*

— JOUR 6 —

Elle passe, et elle parle sans tourner la tête. « Tu marches comme quelqu'un qui compte les jours. » Un temps, sa voix déjà derrière toi : « Moi j'ai arrêté au troisième. » Quand tu te retournes, la bruyère se referme sur rien.

D'un côté, une palissade qui coupe l'horizon, une lanterne allumée en plein jour. De l'autre, des rangs d'arbres qui n'ont plus de feuilles.

CHOIX : [Vers une palissade au sud] [Vers des rangs d'arbres noirs]
→ choix: Vers des rangs d'arbres noirs

## [265] verger-noir · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_verger_noir_d.png*

Des rangs réguliers montent de la bruyère. De loin, c'est presque rassurant.

Tu as coupé par les fougères hautes. Aucun bruit à compter, aucune vue d'ensemble.

Des arbres fruitiers plantés en rangs — le seul ordre volontaire des Landes hors du hameau. Ils ont poussé, ils ont des branches, des feuilles noires, et des fruits. C'est pire que s'ils étaient morts.

Les rangs et leurs fruits. La souche du premier arbre, au bout. Et deux silhouettes qui bêchent, tout au fond.

CHOIX : [Les fruits, dans les rangs] [Observer les alentours] [Goûter un fruit COURAGE] [Utiliser — Onguent gris]
→ choix: La souche, au bout du rang

## [269] verger-noir · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_verger_souche_a_c.png*

Au bout du rang, un arbre manque. Sa souche est nette, sciée à hauteur de genou, et le bois de coupe est gris.

Le premier arbre du verger, abattu net. Les cernes sont réguliers jusqu'aux dernières années — puis serrés, noirs, illisibles. L'arbre a compris avant les hommes où il poussait. Quelqu'un l'a abattu pour ne pas avoir à le lire. En te relevant, tu comptes les rangs par habitude, et le compte te reste dans la tête : onze vergers replantés sur une terre qui n'a jamais rien donné.

CHOIX : [Les fruits, dans les rangs] [Observer les alentours] [Goûter un fruit COURAGE] [Utiliser — Onguent gris]
→ choix: Les fruits, dans les rangs

## [272] verger-noir · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_verger_fruits_cendre_v2_c.png*

Tu entres dans un rang. L'odeur devrait arriver là — pas de pourriture : pas d'odeur du tout. Un verger qui ne sent rien.

Ronds, lourds, gris mat. La peau est parfaite et le poids ment : tu en décroches un, il pèse comme une pierre et cède comme du papier. Des fruits de cendre. Tu en gardes un. On ne sait jamais ce qu'on est prêt à parier.

OBTENU — FRUIT DE CENDRE · COMMUN
La peau est parfaite et le poids ment. Le manger est un pari : une vision, ou pire.

CHOIX : [Les deux qui bêchent, au fond] [Observer les alentours] [Goûter un fruit COURAGE] [Utiliser — Onguent gris]
→ choix: Compter les rangs

## [284] verger-noir-2 · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_verger_noir_2_v2_b.png, geolier_portrait.png*

Onze rangs. Tu recomptes : onze. Chaque rang est planté d'une essence différente, et chaque essence a donné les mêmes fruits gris. Onze tentatives, onze réponses identiques, et un douzième rang en cours de creusement au fond. Il n'y a pas de mot pour ça dans ta langue. Ici, ça s'appelle mardi.

Un fruit tombe, derrière toi. Sans vent, sans oiseau.

Quand tu le ramasses, il est encore chaud — comme une chose qui vient de cesser d'essayer.

Encore chaud. Comme tout ce qui vient de renoncer. Tu t'y feras.

CHOIX : [Le reposer au pied de l'arbre] [Sortir des rangs INSTINCT] [Utiliser — Onguent gris]
→ choix: Le reposer au pied de l'arbre

## [288] hameau-halte-1 · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_landes_hameau_ruelle_b.png*

Tu le reposes exactement sous la branche d'où il vient, bien calé dans la terre, comme on remet quelque chose à sa place. Le geste ne sert à rien. Tu le fais quand même, et le verger entier te paraît une seconde moins hostile.

Le vieux te trouve avant que tu ne le cherches. C'est comme ça, ici : on sait toujours où tu es.

— « Tu pars demain. » Ce n'est pas une question. « Personne ne marche vers le sud de nuit. Même toi. »

→ continue

## [291] hameau-halte-1 · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_landes_hameau_ruelle_b.png*

Il ne t'invite pas chez lui. Personne n'invite personne. Il te mène à la grange, au bout de la rue — la seule porte du hameau qui n'a pas de marque à la craie. Pas encore.

Six, sur le faîtage d'en face. Tu changes de rue : le compte ne change pas.

CHOIX : [Le suivre] [Demander à dormir ailleurs] [Utiliser — Onguent gris]
→ choix: Le suivre

## [296] hameau-halte-2 · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_landes_hameau_grange_a.png*

De la paille propre, une couverture qui a servi, une lampe qu'on te laisse — la mèche est courte, calculée pour s'éteindre seule.

— « On te rouvre à l'aube. » Le vieux pose la main sur la porte. « C'est pas contre toi. »

La porte se ferme. Puis le bruit que tu attendais sans le savoir : une barre qu'on pose. Dehors.

Six corbeaux se posent quand tu débouches dans la rue — sans un cri, sans une dispute, comme des gens qui prennent leur poste.

CHOIX : [Examiner la grange] [Veiller INSTINCT] [Dormir] [Utiliser — Onguent gris]
→ choix: Examiner la grange

## [298] hameau-halte-2 · Jour 6 · santé 0.51 · soupçon 4 · hante,fixe,boiteux
*image : scene_hameau_grange_poutres_a_d.png*

Tu prends la lampe et tu fais le tour, lentement, en te tenant loin des murs — le vieux réflexe de qui ne veut pas être une silhouette derrière des planches.

→ continue


Erreurs JS : 0 · HTTP≥400 : 0