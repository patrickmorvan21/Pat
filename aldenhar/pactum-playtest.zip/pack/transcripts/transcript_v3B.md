# PACTUM — transcript de partie réelle (v3B)

Profil : vie PRESSÉE ET RISQUÉE (compte vétéran, 3 morts passées). Partie jouée automatiquement
sur le build publié (v1.51.1), dés lancés par la vraie physique.
Fin de la partie : retour accueil (COMMENCER).

Chaque bloc = un écran tel qu'affiché au joueur. `> action` = ce que
le testeur a fait. Les boutons entre crochets sont les choix offerts.

---

## Écran 1

Le Registre n'inscrit pas les journées incomplètes. Reviens en faire une entière. COMMENCER RELIQUES GRAND REGISTRE OPTIONS v1.51.1

Choix affichés : [COMMENCER] · [RELIQUES] · [GRAND REGISTRE] · [OPTIONS]

## Écran 2 · Jour 1

Avant que tu passes, je veux voir qui tu étais. Touche pour continuer

## Écran 3 · Jour 1

Ne réfléchis pas. Ce n'est plus toi qui choisis, ici — c'est ce que tu as déjà fait. Touche pour continuer

## Écran 4 · Jour 1

Un pont grince sous une charge trop lourde. Tu dois traverser pour rejoindre quelqu'un de l'autre côté. Traverser sans regarder en bas Tester chaque planche Chercher un autre chemin

Choix affichés : [Traverser sans regarder en bas] · [Tester chaque planche] · [Chercher un autre chemin]

> choisit : « Chercher un autre chemin »

## Écran 5 · Jour 1

Pour entrer là où tu n'es pas invité, il te faut être quelqu'un d'autre. Voler un uniforme Te faire passer pour un messager Chercher une entrée détournée

Choix affichés : [Voler un uniforme] · [Te faire passer pour un messager] · [Chercher une entrée détournée]

> choisit : « Voler un uniforme »

## Écran 6 · Jour 1

Une odeur de fumée, là où il ne devrait pas y avoir de feu. Aller voir, tout de suite L'ignorer, sûrement rien Prévenir quelqu'un d'autre d'abord

Choix affichés : [Aller voir, tout de suite] · [L'ignorer, sûrement rien] · [Prévenir quelqu'un d'autre d'abord]

> choisit : « L'ignorer, sûrement rien »

## Écran 7 · Jour 1

Un homme enchaîné te supplie de desserrer ses liens, juste un instant. L'aider, malgré le risque Écouter son histoire d'abord Ignorer sa demande, avancer

Choix affichés : [L'aider, malgré le risque] · [Écouter son histoire d'abord] · [Ignorer sa demande, avancer]

> choisit : « L'aider, malgré le risque »

## Écran 8 · Jour 1

Une dernière chose. J'ai vu qui tu étais. Il me manque comment on t'appelait. SCELLER LE PACTE Qu'il choisisse pour moi

Choix affichés : [SCELLER LE PACTE] · [Qu'il choisisse pour moi]

## Écran 9 · Jour 1

Tu protèges les autres, rarement toi-même. Les gens te parlent, même quand ils ne veulent pas. Mais tu n'écoutes pas ce qui murmure en toi. Tu veux des preuves, et elles arrivent tard. Je sais qui tu es. Le dé, lui, décidera qui tu deviens. Touche pour commencer

## Écran 10 · Jour 1

• LE DOMAINE • Les Lisières Touche pour continuer

## Écran 11 · Jour 1

— JOUR 1 — La lande s'ouvre sous un crépuscule qui ne tombe pas. La lumière reste prise entre chien et loup, comme un souffle retenu. Quelque part, une corde grince. La pierre est seule au milieu du plateau, dressée là où tous les murets renoncent. Haute comme un homme, grise comme le reste — et pourtant l'œil ne voit qu'elle. À son pied, un tas d'offrandes. Au-delà, le sud, nu. Et à trois pas de la borne, un homme immobile, face au sud. À partir de maintenant, il décide avec moi.

Choix affichés : [Observer les alentours] · [Fouiller les offrandes RUSE] · [Répondre aux voix EMPATHIE]

> choisit : « Répondre aux voix EMPATHIE »

## Écran 12 · Jour 1

Tu réponds au vent — pas des mots, un ton. Le même que le leur. Les voix se taisent une mesure entière, puis reprennent plus bas, et cette fois elles ne parlent plus de toi. La lande sait maintenant que tu entends. Ça change la manière dont elle parle. Le chemin se creuse, remonte, se divise. Ici, on ne va pas quelque part — on s'éloigne de la Borne. Deux directions s'ouvrent. D'un côté, des rangées de piquets jusqu'à l'horizon. De l'autre, une crête hérissée de mâts noirs.

## Écran 13 · Jour 1

Un vieux, assis contre un muret, gratte une planchette sans te regarder. « Tout le monde a sa ligne, ici », dit-il. « Nom, motif, jours. Même toi — surtout toi. Elle est déjà ouverte. »

Choix affichés : [Vers les rangées de poteaux] · [Vers la crête aux cordes]

> choisit : « Vers les rangées de poteaux »

## Écran 14 · Jour 1

L'horizon se hérisse de piquets réguliers, rangée après rangée, jusqu'à se perdre. Tu approches d'un champ qu'on n'a pas semé — on l'a planté d'hommes. Tu es passé sous le vent. Rien ne s'est retourné, et tu n'as regardé que tes pieds. Pas de tombes — des poteaux. Des rangées de poteaux plantés droit, un nom sur chaque, alignés face au nord. Dos au sud. Même morts, surtout morts, on ne les laisse pas regarder par là.

## Écran 15 · Jour 1

Au fond, des poteaux vierges attendent, déjà plantés. Près de l'entrée, la cabane du Fossoyeur. Le champ entier est un registre debout. Chaque poteau son pendu, chaque pendu son écriteau : un nom, un motif, un nombre de jours. Une écriture de greffe, appliquée, sans colère. Un seul écriteau détonne : le motif a été gratté au couteau, si fort que le bois est entaillé. Le nom reste, le nombre de jours reste. Ce qu'elle avait fait, quelqu'un n'a pas supporté qu'on le lise.

Choix affichés : [Les rangées et leurs noms] · [Observer les alentours] · [Rester dans le champ]

> choisit : « Les rangées et leurs noms »

## Écran 16 · Jour 1

Tu marches entre deux rangs. Le sol est tassé par des allées et venues régulières — on entretient ce champ comme un jardin, et c'est ça qui serre le ventre. Les noms des premières rangées sont presque effacés. Les dernières sont fraîches. Entre les deux, une rangée entière porte la même date — un seul jour, neuf fixations. Il y a une histoire là-dedans que personne ne raconte.

## Écran 17 · Jour 1

La formule est toujours la même, tu commences à la reconnaître : un nom, deux mots de motif, un nombre. Jamais de date. Comme si le jour n'avait pas d'importance — seulement combien de jours la personne avait tenu avant.

Choix affichés : [Les poteaux vierges, au fond] · [Un vide dans une rangée pleine] · [Rester dans le champ]

> choisit : « Les poteaux vierges, au fond »

## Écran 18 · Jour 1

Il faut traverser tout le champ pour les atteindre. Tu comptes les poteaux vides en marchant — puis tu t'arrêtes de compter, parce que le compte monte plus vite que tes pas.

## Écran 19 · Jour 1

Trois poteaux portent déjà des noms, sans date. Le Fossoyeur grave d'avance « ceux dont c'est sûr ». Le troisième nom est récent — l'entaille est claire, le bois n'a pas encore grisé. Tu le lis, et tu le relis, et il ne change pas : c'est le tien. Quelqu'un ici sait déjà comment ça finit, et a pris le temps de tailler proprement.

Choix affichés : [Un vide dans une rangée pleine] · [Rester dans le champ]

> choisit : « Rester dans le champ »

## Écran 20 · Jour 1

Entre les rangs, un vieil homme redresse un poteau qui penche, avec des gestes de jardinier. Il t'a vu venir de loin — les vivants font un bruit particulier, ici. Il ne s'interrompt pas : il t'attend au travail, comme on attend un outil.

Choix affichés : [Passer sans un mot] · [Déchiffrer le carnet RUSE [verrouillé]] · [Aider à redresser EMPATHIE]

> choisit : « Aider à redresser EMPATHIE »

## Écran 21 · Jour 2

Le poteau t'échappe et le pendu chasse au bout de sa corde, dans un grand désordre de chanvre. Tout le rang se met à osciller de proche en proche. Le Fossoyeur te chasse à gestes secs : tu as réveillé le dortoir. — JOUR 2 — La lande t'a pris un jour. La lumière a tourné sans que tu avances. Sur une pierre du chemin, une croix à la craie — vieille, à moitié lavée. Pas la tienne. Quelqu'un d'autre, avant toi, a entendu quelque chose. Tu ne sauras pas où il pend.

## Écran 22 · Jour 2

D'un côté, un chemin qui s'enfonce entre deux talus. De l'autre, une crête hérissée de mâts noirs.

Choix affichés : [Vers le chemin creux] · [Vers la crête aux cordes]

> choisit : « Vers la crête aux cordes »

## Écran 23 · Jour 3

— JOUR 3 — Tu montes. Les mâts deviennent des potences. Tu es entré par où tout le monde entre. Ça se remarque, et ça permet de voir venir. La pente est douce et n'en finit pas — la Colline se mérite à pas comptés. Au sommet, le cercle : neuf potences ordinaires, plantées comme les heures d'un cadran. Et au centre, l'autre. La grande. Sa corde est la seule chose neuve à dix lieues.

## Écran 24 · Jour 3

À gauche du cercle, un poteau isolé porte encore son occupant. À droite, les potences vides alignent leurs noms gravés. Les cordes sont nouées différemment. Chacune par une main qui connaissait celui du bout. OBTENU — BANDAGE D'UN AUTRE · COMMUN Son premier propriétaire n'en aura plus besoin.

Choix affichés : [Le pied du grand gibet] · [Observer les alentours] · [Rester au sommet]

> choisit : « Rester au sommet »

## Écran 25 · Jour 3

Le vent tombe d'un coup, comme on ferme une porte. Et dans ce calme plat, les neuf cordes du cercle se mettent à bouger. Pas au hasard : ensemble. Un balancement lent, réglé, qui va et vient sur le même temps. Ça grince en mesure. Neuf cordes, un seul rythme. Tu comprends, avec un retard qui te coûte, que ce rythme ne t'est pas indifférent — tu pourrais le compter.

Choix affichés : [Arracher une écharde COURAGE] · [Rester et compter INSTINCT] · [Partir avant de comprendre] · [Ne plus afficher]

> choisit : « Arracher une écharde COURAGE »

## Écran 26 · Jour 3

Le bois crie sous ta lame — un son de gorge, pas de fibre. Les corbeaux décomptent un cran, tous ensemble. Tu emportes l'écharde, mais la colline emporte quelque chose de toi. Des bêtes broutent la bruyère morte au creux du vallon — un troupeau entier, sans personne. Elles ne s’écartent pas quand tu approches : elles lèvent la tête, te regardent une seconde, et se remettent à brouter. C’est ce détail qui te dérange le plus. Elles n’ont pas appris à se méfier.

Choix affichés : [Les marques d’oreille] · [S’avancer dans le vallon] · [Utiliser — Bandage d'un autre] · [Ne plus afficher]

> choisit : « S’avancer dans le vallon »

## Écran 27 · Jour 3

Une brebis s’écarte du groupe et marche droit vers le nord-est, s’arrête, revient. Puis recommence. Cinq fois pendant que tu la regardes. Elle refait un trajet. Elle attend au bout de quelque chose qui n’arrive plus. Dans cette direction, à un quart d’heure de marche, il y a le Champ des Fixés.

Choix affichés : [Continuer ton chemin] · [Utiliser — Bandage d'un autre] · [Ne plus afficher]

> choisit : « Utiliser — Bandage d'un autre »

## Écran 28 · Jour 3

Tu sors « Bandage d'un autre » de la Besace. La plaie se referme, l'entaille cède enfin. Un mot t'arrive porté par le vent, un seul, distinct : ton nom. Personne à l'horizon. Le vent des Landes ment, tu le sais. Mais il ment avec ce qu'on lui donne. D'un côté, des silhouettes grises qui se déplacent ensemble. De l'autre, une maison murée de l'intérieur.

Choix affichés : [Vers des silhouettes grises] · [Vers une maison murée] · [Ne plus afficher]

> choisit : « Vers des silhouettes grises »

## Écran 29 · Jour 3

• RENCONTRE • La Meute Grise La bruyère bouge sans vent, par plaques, autour de toi. Ce ne sont pas des ombres : ce sont des dos gris, bas sur pattes, qui resserrent un cercle patient. Tu as longé le talus à contre-jour. Mauvais angle pour être reconnu, mauvais angle pour voir.

Choix affichés : [Ne plus afficher]

## Écran 30 · Jour 3

Loin de tout muret, la lande est à eux. Tu les vois de loin — et c'est mauvais signe : la Meute Grise ne se montre que quand l'encerclement est fini. Six silhouettes couleur de bruyère morte, immobiles aux six points d'un cercle dont tu es le centre. Pas des chiens : trop patients. Pas des loups : trop organisés. La plus grande s'assoit — le signal. Le cercle se met à tourner, lentement, en se resserrant d'un pas par tour.

Choix affichés : [Ne plus afficher]

## Écran 31 · Jour 3

Ce ne sont pas des bêtes sauvages. Elles attendent quelqu'un qui ne vient plus.

Choix affichés : [Hurler le premier RUSE] · [Charger la plus grande COURAGE] · [Gagner le muret INSTINCT] · [Ne plus afficher]

> choisit : « Charger la plus grande COURAGE »

## Écran 32 · Jour 3

Boiteux Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé. Entaillé La blessure ralentit chaque geste, tant qu'elle n'est pas soignée. Elle t'a laissé venir. Le cercle se referme dans ton dos au moment exact de ton élan — des crocs te prennent au mollet, d'autres au flanc, précis, économes. Puis tout recule d'un pas : la première entaille est faite. Ils ne sont pas pressés. • RENCONTRE • La Meute Grise Le cercle est rompu, mais la meute reste — regroupée à distance de lame, en croissant, plus prudente. Ils ont compris que tu mords a

Choix affichés : [Boiteux Le genou ne plie plus tout à fait. Tu peux marcher —] · [Entaillé La blessure ralentit chaque geste, tant qu'elle n'e] · [Ne plus afficher]

> choisit : « Reculer, sans ciller INSTINCT »

## Écran 33 · Jour 3

Ton talon accroche une racine — un quart de seconde de regard perdu. Il ne leur en faut pas plus : la charge t'arrive dessus pendant que tu te rattrapes, te roule, te coûte — puis s'arrête net, croissant reformé, et la meute s'en va. L'épreuve est finie ; tu n'as pas brillé, mais tu es debout. Tu laisses le combat derrière toi, mais pas tout : la lande a bu ce qui a coulé, et elle sait maintenant quel goût tu as. Tu marches plus léger, et moins tranquille.

Choix affichés : [Ne plus afficher]

## Écran 34 · Jour 3

D'un côté, une masse trapue privée de ses ailes. De l'autre, une palissade qui coupe l'horizon, une lanterne allumée en plein jour.

Choix affichés : [Vers un moulin sans ailes] · [Vers une palissade au sud] · [Ne plus afficher]

> choisit : « Vers un moulin sans ailes »

## Écran 35 · Jour 3

Tu quittes les toits. La masse trapue grandit contre le crépuscule. Tu n'as rien contourné. Tu arrives par la face, et rien ne t'a échappé en chemin. Le moulin n'a plus d'ailes mais il a gardé leur trace : quatre ombres pâles en croix sur le corps de pierre, comme un moulin fantôme peint sur le vrai. La porte est entrouverte. Pas défoncée : entretenue. La croix d'ombres, en haut. La lucarne, qui te regarde. Et la porte, qui n'attend que toi.

Choix affichés : [Ne plus afficher]

## Écran 36 · Jour 3

Le chemin monte, et tu comptes tes pas comme on compte de la monnaie. Ce moulin a moulu autre chose que du grain, dans le temps. Demande à la meule, si tu oses la toucher.

Choix affichés : [Observer les alentours] · [S'installer pour la halte] · [Écouter le moulin INSTINCT] · [Ne plus afficher]

> choisit : « Observer les alentours »

> choisit : « La croix d'ombres, en haut »

## Écran 37 · Jour 3

Tu recules jusqu'au muret d'en face. Il faut de la distance pour la voir entière — c'est une trace, pas un détail. De loin, les quatre bandes pâles se lisent d'un coup : ce sont des zones où la pierre n'a pas vieilli, protégée des années par les ailes, puis abandonnée au vent d'un seul coup. On peut dater une catastrophe à la couleur d'un mur. Celle-ci est vieille comme le Domaine.

Choix affichés : [Ne plus afficher]

## Écran 38 · Jour 3

Le motif qui revient le plus n'est pas le vol, ni le meurtre. C'est trois mots : « a parlé dehors ». Tu ne sais pas encore ce qu'on parlait, ni à qui, ni pourquoi le dehors compte.

Choix affichés : [Observer les alentours] · [S'installer pour la halte] · [Écouter le moulin INSTINCT] · [Ne plus afficher]

> choisit : « S'installer pour la halte »

## Écran 39 · Jour 3

Par la lucarne, le crépuscule ne bouge pas. On dit qu'une fille dort ici, parfois — la seule pendue qui se soit relevée. Le lit de bruyère garde une forme légère, comme un creux encore tiède.

Choix affichés : [Dormir malgré le crépuscule] · [Monter la garde INSTINCT] · [Repartir sans s'attarder] · [Ne plus afficher]

> choisit : « Monter la garde INSTINCT »

## Écran 40 · Jour 3

Ton demi-sommeil filtre les bruits de la lande. Rien n'entre. Le repos est mince, mais il est à toi — et le creux du lit de bruyère, au matin, n'a pas changé de forme. Un berger sans troupeau te croise au détour d'un talus. Il te salue — du menton, pas de la voix — et presse le pas une fois passé. Tu l'entends s'arrêter, plus loin, pour te regarder partir.

Choix affichés : [Ne plus afficher]

## Écran 41 · Jour 3

D'un côté, un gibet bas, à hauteur d'homme, qui bouge sans vent. De l'autre, une eau noire où les roseaux ne bougent pas. Le Bailli s'est pendu le dernier, à la place d'honneur. Le hameau dit qu'il a voulu s'échanger contre quelqu'un de bien plus gros que lui. Le hameau dit aussi que ça n'a pas marché — sinon il ne parlerait plus. Tu choisis ton chemin. C'est mignon. Ça ne change que l'ordre des choses.

Choix affichés : [Vers un gibet qui parle] · [Vers une eau qui ne bouge pas] · [Ne plus afficher]

> choisit : « Vers une eau qui ne bouge pas »

## Écran 42 · Jour 4

— JOUR 4 — Le vent tombe d'un coup, comme coupé au couteau. Tes derniers pas ne font plus de bruit. Tu as coupé par les fougères hautes. Aucun bruit à compter, aucune vue d'ensemble. L'eau est noire et parfaitement plate — le seul endroit des Landes que le vent évite. La berge est piétinée en un seul point, tassée par des années de genoux. On ne vient pas ici puiser. On vient s'agenouiller. Le point de berge usé. L'eau. Et dans les roseaux, un reflet de métal.

Choix affichés : [Ne plus afficher]

## Écran 43 · Jour 4

Le chemin monte, et tu comptes tes pas comme on compte de la monnaie. Les gens du hameau y viennent quand même. Ils cherchent quelqu'un, pas leur reflet.

Choix affichés : [Les creux dans la berge] · [Observer les alentours] · [Boire à la mare COURAGE] · [Ne plus afficher]

> choisit : « Observer les alentours »

> choisit : « Le point de berge usé »

## Écran 44 · Jour 4

Tu contournes la mare par la droite pour atteindre le seul endroit où la boue est tassée. Le sol y est dur comme un seuil de maison. Deux creux dans la terre, à largeur de genoux, refaits par des centaines de personnes au même endroit exact. À côté, des marques de doigts crispés dans la boue séchée. On ne s'agenouille pas ici pour prier. On s'agenouille pour vérifier.

Choix affichés : [Les creux dans la berge] · [Observer les alentours] · [Boire à la mare COURAGE] · [Ne plus afficher]

> choisit : « Les creux dans la berge »

## Écran 45 · Jour 4

Tu longes la berge jusqu’à l’endroit où la terre est tassée, luisante, usée jusqu’à la pierre. On s’agenouille ici depuis longtemps. Les creux de genoux sont doubles. Une paire devant, au ras de l’eau. Une autre juste derrière, plus large, plus profonde — et orientée dans le même sens. Quelqu’un se tenait toujours au-dessus de celui qui se penchait. Ce n’est pas un endroit où l’on vient voir son reflet : c’est un endroit où on l’amène.

Choix affichés : [L'eau] · [Observer les alentours] · [Boire à la mare COURAGE] · [Ne plus afficher]

> choisit : « Boire à la mare COURAGE »

## Écran 46 · Jour 5

Fiévreux Le froid t'a lâché d'un coup, et c'est mauvais signe : ce n'est plus l'air qui te réchauffe. Tes mains tremblent quand tu ne les regardes pas. Tu bois — et l'eau reste au bord des lèvres, sans descendre, une seconde de trop. Quand elle passe enfin, tu as l'impression très nette d'avoir avalé quelque chose qui a accepté de se laisser avaler. — JOUR 5 — La lande t'a pris un jour. La lumière a tourné sans que tu avances.

Choix affichés : [Fiévreux Le froid t'a lâché d'un coup, et c'est mauvais sign] · [Ne plus afficher]

> choisit : « Lui parler EMPATHIE »

## Écran 47 · Jour 6

Il te voit — et le fait que tu l'aies vu, lui, est la pire chose qui pouvait lui arriver aujourd'hui. Il part très vite, sans un mot, et tu sais qu'il racontera cette rencontre autrement que toi. — JOUR 6 — La lande t'a pris un jour. La lumière a tourné sans que tu avances.

Choix affichés : [Ne plus afficher]

## Écran 48 · Jour 6

Entre deux rangs du verger, une silhouette immobile. Tu la fixes ; elle attend que tu l'aies bien vue, puis reprend sa marche entre les arbres, du pas de quelqu'un qui rentre chez lui. Les fruits de cendre ne bougent pas sur son passage. D'un côté, des bâches tendues et pas une voix. De l'autre, un gibet bas, à hauteur d'homme, qui bouge sans vent.

Choix affichés : [Vers un marché muet] · [Vers un gibet qui parle] · [Ne plus afficher]

> choisit : « Vers un gibet qui parle »

## Écran 49 · Jour 6

Tu contournes la crête. Ce que tu prenais pour un épouvantail tourne la tête. Tu as pris la route droite. On t'a vu venir — et tu as eu le temps de tout regarder. Au revers de la colline, un gibet bas, à hauteur d'homme. Le pendu qui s'y balance ouvre les yeux à ton approche. Chaîne de fonction au cou, sous la corde. Un sceau au poing. Le Bailli des Landes — pendu le dernier, à la place d'honneur.

Choix affichés : [Ne plus afficher]

## Écran 50 · Jour 6

Il ne demande pas qu'on le descende. Il demande qu'on l'écoute. Ce n'est pas la même peur.

Choix affichés : [Détailler le sceau à son poing] · [Le jauger sans approcher INSTINCT] · [S'approcher du gibet bas] · [Ne plus afficher]

> choisit : « Détailler le sceau à son poing »

## Écran 51 · Jour 6

Le sceau est serré dans sa main comme une charge qu'on n'a pas rendue. Le motif t'arrête : tu l'as déjà vu. Partout, en fait — gravé discret dans la pierre de la borne, le bois des poteaux, le fer du puits. Les Landes entières sont timbrées à sa marque. « Approche », dit-il, et la corde grince sur chaque syllabe. « Tout ce qui entre dans mes Landes passe en jugement. Toi aussi. » Il sourit. « Surtout toi. »

Choix affichés : [Passer sans un mot] · [Répondre à son jugement EMPATHIE] · [Lui demander combien il en a signé] · [Trancher sa corde COURAGE] · [Ne plus afficher]

> choisit : « Trancher sa corde COURAGE »

## Écran 52 · Jour 1

v1.51.1

## Écran 53 · Jour 1

Deux mille avant toi ont refait exactement ce geste. Vas-y. COMMENCER RELIQUES GRAND REGISTRE OPTIONS v1.51.1

Choix affichés : [COMMENCER] · [RELIQUES] · [GRAND REGISTRE] · [OPTIONS]
