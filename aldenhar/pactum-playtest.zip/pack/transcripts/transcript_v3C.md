# PACTUM — transcript de partie réelle (v3C)

Profil : vie PREMIER CHOIX (prend toujours la première option, compte neuf). Partie jouée automatiquement
sur le build publié (v1.51.1), dés lancés par la vraie physique.
Fin de la partie : budget épuisé (260 actions).

Chaque bloc = un écran tel qu'affiché au joueur. `> action` = ce que
le testeur a fait. Les boutons entre crochets sont les choix offerts.

---

## Écran 1

Tu choisis. Le dé décide. Lui, il regarde. COMMENCER OPTIONS v1.51.2

Choix affichés : [COMMENCER] · [OPTIONS]

## Écran 2

Tu ne te souviens pas D'être entré, je veux dire. Personne ne s'en souvient. Tu es mort. Il y a peu. Ce qui suit est une proposition. Personne ne l'a jamais refusée. Touche pour commencer

## Écran 3

Une seule vie Tu traverses mon Domaine. Une fois. Au bout, une Porte scellée : franchis-la, et tu reprends ta vie là où tu l'as laissée. Si tu meurs, un autre viendra. Avec un autre nom.

## Écran 4

Le dé tranche Ton adresse ne te sauvera pas. Courage, ruse, instinct, empathie : ce que tu vaux vient de ce que tu étais de ton vivant. Touche pour continuer

## Écran 5

Ta mort me sert Ta fin est forgée en Relique. Celui qui te suivra la portera. On ne progresse pas ici en survivant. En tombant mieux.

## Écran 6 · Jour 1

Avant que tu passes, je veux voir qui tu étais. Touche pour continuer

## Écran 7 · Jour 1

Ne réfléchis pas. Ce n'est plus toi qui choisis, ici — c'est ce que tu as déjà fait. Touche pour continuer

## Écran 8 · Jour 1

Un pont grince sous une charge trop lourde. Tu dois traverser pour rejoindre quelqu'un de l'autre côté. Traverser sans regarder en bas Tester chaque planche Chercher un autre chemin

Choix affichés : [Traverser sans regarder en bas] · [Tester chaque planche] · [Chercher un autre chemin]

> choisit : « Traverser sans regarder en bas »

## Écran 9 · Jour 1

Un garde-frontière fouille chaque sac, et le tien contient ce qu'il ne faut pas. Distraire le garde, glisser à travers Payer un bakchich Tenter ta chance, honnêtement

Choix affichés : [Distraire le garde, glisser à travers] · [Payer un bakchich] · [Tenter ta chance, honnêtement]

> choisit : « Distraire le garde, glisser à travers »

## Écran 10 · Jour 1

L'eau a une couleur qui ne va pas, un peu trop claire pour la saison. Chercher une autre source Boire quand même, la soif presse Tester d'abord un peu, prudent

Choix affichés : [Chercher une autre source] · [Boire quand même, la soif presse] · [Tester d'abord un peu, prudent]

> choisit : « Chercher une autre source »

## Écran 11 · Jour 1

Un voyageur perdu tente de te parler, dans une langue que tu ne comprends pas. Chercher à l'aider malgré la barrière Lui indiquer une direction, au hasard Faire semblant de ne pas comprendre

Choix affichés : [Chercher à l'aider malgré la barrière] · [Lui indiquer une direction, au hasard] · [Faire semblant de ne pas comprendre]

> choisit : « Chercher à l'aider malgré la barrière »

## Écran 12 · Jour 1

Une dernière chose. J'ai vu qui tu étais. Il me manque comment on t'appelait. SCELLER LE PACTE Qu'il choisisse pour moi

Choix affichés : [SCELLER LE PACTE] · [Qu'il choisisse pour moi]

## Écran 13 · Jour 1

Tu avances avant de comprendre. Le danger t'a toujours moins arrêté que le doute. Mais les autres restent pour toi un bruit de fond. Ça t'a coûté. Ça te coûtera encore. Je sais qui tu es. Le dé, lui, décidera qui tu deviens. Touche pour commencer

## Écran 14 · Jour 1

• LE DOMAINE • Les Lisières Touche pour continuer

## Écran 15 · Jour 1

— JOUR 1 — La lande s'ouvre sous un crépuscule qui ne tombe pas. La lumière reste prise entre chien et loup, comme un souffle retenu. Quelque part, une corde grince. La pierre est seule au milieu du plateau, dressée là où tous les murets renoncent. Haute comme un homme, grise comme le reste — et pourtant l'œil ne voit qu'elle. À son pied, un tas d'offrandes. Au-delà, le sud, nu. Et à trois pas de la borne, un homme immobile, face au sud. À partir de maintenant, il décide avec moi.

Choix affichés : [Observer les alentours] · [Fouiller les offrandes RUSE] · [Répondre aux voix EMPATHIE]

> choisit : « Observer les alentours »

> choisit : « Les gravures de la pierre »

## Écran 16 · Jour 1

Tu fais le tour de la pierre lentement, la main à plat sur le granit. Il est froid d'une froideur qui ne vient pas du vent. Des marques sur toutes les faces, de toutes les mains, de toutes les époques : des noms, des dates, des traits de comptage. Le côté nord est saturé — les adieux de ceux qui partaient. Le côté sud est presque vierge. Trois marques seulement. On ne grave pas au retour quand personne ne revient. Alors qui a gravé côté sud ?

## Écran 17 · Jour 1

Personne ne dit son nom. On dit « elle », et on change de sujet, et on regarde ailleurs. Un hameau qui compte tout, qui grave tout, qui affiche ses morts sur des écriteaux — et qui n'écrit pas ce nom-là.

Choix affichés : [Observer les alentours] · [Fouiller les offrandes RUSE] · [Répondre aux voix EMPATHIE]

> choisit : « Observer les alentours »

> choisit : « Un angle cassé, au ras du sol »

## Écran 18 · Jour 1

Un angle de la borne manque. Tu t'accroupis : la cassure est nette, faite au burin, patiemment. Quelqu'un a voulu emporter un morceau de la limite avec lui. L'éclat est encore là, à demi enterré sous la bruyère. Il ne l'a pas pris. Ou il n'a pas pu. La pierre tient dans le creux de ta main, exactement comme si elle avait été taillée pour. OBTENU — PIERRE DE RETOUR · RARE Un éclat descellé de la Borne. Les Renonçants disent qu'on revient, si on la porte. Personne n'est revenu.

Choix affichés : [Observer les alentours] · [Fouiller les offrandes RUSE] · [Répondre aux voix EMPATHIE]

> choisit : « Observer les alentours »

> choisit : « L'homme qui regarde le sud »

## Écran 19 · Jour 1

Tu quittes la borne et tu marches vers lui, sans te presser, en faisant sonner tes pas — on n'arrive pas dans le dos de quelqu'un, ici. L'herbe autour de ses pieds est couchée, morte. Il est là depuis des jours. Immobile — mais pas comme on se repose : comme on lutte. Il ne se retourne pas. Il t'a entendu, pourtant — ses épaules l'ont dit.

Choix affichés : [Ne plus afficher]

## Écran 20 · Jour 1

— « Tu l'entends fort, toi ? » Sa voix est calme, épuisée d'être calme. « Moi, c'est encore bas. Comme des gens qui parlent dans la maison d'à côté. On comprend pas les mots. On comprend juste... qu'on parle de nous. »

Choix affichés : [« Depuis combien de temps ? »] · [Mentir : « Je n'entends rien. » RUSE] · [Ne plus afficher]

> choisit : « « Depuis combien de temps ? » »

## Écran 21 · Jour 1

— « Ma femme dit trois semaines. » Un temps. « Ma femme dit beaucoup de choses en pleurant, maintenant. » Il ne quitte pas le sud des yeux en le disant, et c'est ça, le plus dur à voir : il parle d'elle au présent et il regarde ailleurs.

Choix affichés : [Ne plus afficher]

## Écran 22 · Jour 1

— « Je calcule. » Il montre la borne du menton, sans la regarder. « Si je rentre, ils me liront sur la figure et je finirai au bout d'une corde qui ne retient rien. Si je passe la pierre, je finis comme ceux qui passent la pierre. » Un temps. « Tu descends. Tu vas voir ce qu'on devient. Alors dis-moi ce que tu choisirais. »

Choix affichés : [Le raccompagner au hameau EMPATHIE] · [Ne pas répondre et partir] · [« Passe. »] · [Ne plus afficher]

> choisit : « Le raccompagner au hameau EMPATHIE »

## Écran 23 · Jour 2

Il ne bouge pas. Il s'assied au pied de la borne, dos à la pierre, face au sud — et c'est pire que tout, parce que maintenant il est confortable. — JOUR 2 — La lande t'a pris un jour. La lumière a tourné sans que tu avances. Il te laisse partir le premier. C'est important pour lui : que tu ne le voies pas décider.

Choix affichés : [Ne plus afficher]

## Écran 24 · Jour 2

Au bout de vingt pas tu te retournes quand même. La borne est seule au milieu du plateau. Il n'y a plus personne à côté — et rien, sur la bruyère couchée, ne dit dans quel sens il est parti. OBTENU — BAUME DE MOUSSE NOIRE · COMMUN Ça sent la cave. Ça referme les plaies.

Choix affichés : [Reprendre la route] · [Ne plus afficher]

> choisit : « Reprendre la route »

## Écran 25 · Jour 2

Deux silhouettes réparent un muret à distance. Leurs mains ne s'arrêtent pas quand tu passes. Leurs têtes, si. Deux directions s'ouvrent. D'un côté, une crête hérissée de mâts noirs. De l'autre, une masse trapue privée de ses ailes. Une femme traverse la lande en biais, un fagot sur l'épaule, et te suit des yeux sans ralentir. Puis elle se signe à l'envers. « Si tu dors au moulin », dit-elle sans que tu aies rien demandé, « laisse le lit de bruyère comme tu l'as trouvé. Il sert encore. »

Choix affichés : [Vers la crête aux cordes] · [Vers un moulin sans ailes] · [Ne plus afficher]

> choisit : « Vers la crête aux cordes »

## Écran 26 · Jour 2

Tu montes. Les mâts deviennent des potences. Tu es entré par où tout le monde entre. Ça se remarque, et ça permet de voir venir. La pente est douce et n'en finit pas — la Colline se mérite à pas comptés. Au sommet, le cercle : neuf potences ordinaires, plantées comme les heures d'un cadran. Et au centre, l'autre. La grande. Sa corde est la seule chose neuve à dix lieues.

Choix affichés : [Ne plus afficher]

## Écran 27 · Jour 2

À gauche du cercle, un poteau isolé porte encore son occupant. À droite, les potences vides alignent leurs noms gravés.

Choix affichés : [Le pied du grand gibet] · [Observer les alentours] · [Rester au sommet] · [Ne plus afficher]

> choisit : « Le pied du grand gibet »

## Écran 28 · Jour 2

Tu quittes la ligne des potences ordinaires pour celle qui les dépasse toutes. De près, elle est absurde : trois fois trop haute pour un homme, et sa corde est neuve. Au pied du mât, dans le bois, un nom a été gravé profond, à la gouge, par quelqu’un qui prenait son temps. Il est illisible — pas effacé par la pluie : GRATTÉ, en travers, par quelque chose qui a mordu le bois plus fort que l’outil. Dessous, une date est restée entière. Elle est vieille de trente ans.

Choix affichés : [Les corbeaux, sur la traverse] · [Observer les alentours] · [Rester au sommet] · [Ne plus afficher]

> choisit : « Les corbeaux, sur la traverse »

## Écran 29 · Jour 2

Ils sont sur la traverse du grand gibet, immobiles, et ils ne bougent pas quand tu approches — ce qui n'est pas un comportement d'oiseau. Aucun ne te regarde. Ils regardent la corde.

Choix affichés : [Ne plus afficher]

## Écran 30 · Jour 2

Ils ne mangent pas. Il n'y a rien à manger ici depuis longtemps, et leurs becs sont propres. Ils attendent, et ils sont exactement assez nombreux pour ce qu'ils attendent. Ce sont les mêmes que sur les toits du hameau : la même immobilité, la même façon d'être tournés du même côté. En bas, ils comptent quelque chose qui te concerne. Ici aussi — mais pas la même chose.

Choix affichés : [Ne plus afficher]

## Écran 31 · Jour 2

Il n'y en a qu'un, et il se tient de travers, comme s'il gardait une place. Tu ne sais pas pour qui.

Choix affichés : [Les potences du cercle] · [Observer les alentours] · [Rester au sommet] · [Ne plus afficher]

> choisit : « Les potences du cercle »

## Écran 32 · Jour 2

Tu entres dans le cercle. Le vent monte d'un cran dès le premier pas entre deux potences — pas plus fort ailleurs, plus fort ICI, comme si l'espace entre les mâts avait son climat. Chaque potence porte un nom gravé au pied, et une date. Les entailles sont de la même main — appliquée, régulière, la main de quelqu'un qui grave comme on rend un jugement.

Choix affichés : [Ne plus afficher]

## Écran 33 · Jour 2

Tu recoupes deux phrases entendues à un jour d'écart : elle était la fille du Bailli. Voilà pourquoi le motif de son écriteau a été gratté. Voilà, peut-être, pourquoi la dernière entaille de la chaire tremble.

Choix affichés : [Le Gibet Vide, au centre] · [Le poteau isolé, à gauche] · [Rester au sommet] · [Ne plus afficher]

> choisit : « Le Gibet Vide, au centre »

## Écran 34 · Jour 2

Tu marches vers le centre, et la chose grandit plus vite que tes pas. À dix mètres, tu comprends que tu avais mal jugé l'échelle. À trois, tu dois lever la tête pour voir le nœud. Le bois est d'œuvre, assemblé pour durer mille ans. La corde neuve grince. Par grand soleil — rare, ici — l'ombre portée s'étend vers le sud, et elle a une forme que la potence n'explique pas.

Choix affichés : [Ne plus afficher]

## Écran 35 · Jour 2

Des provisions apparaissent là où elle dort. Pas un festin : du pain dur, de l'eau, parfois du sel. Déposés par quelqu'un qui refuse qu'elle meure et refuse aussi qu'on le voie. Le hameau la renie à voix haute et la nourrit en silence. Le grand gibet a été taillé pour le Bailli, du temps où il jugeait encore. La traverse est à sa mesure : on l'a préparée avant lui.

Choix affichés : [Le poteau isolé, à gauche] · [Rester au sommet] · [Ne plus afficher]

> choisit : « Le poteau isolé, à gauche »

## Écran 36 · Jour 2

Tu contournes le cercle par la gauche. Le poteau isolé est plus bas que les autres — à hauteur d'homme, exactement. Une hauteur qu'on choisit. Chaîne de fonction au cou, sous la corde. Un sceau au poing. Et les yeux qui s'ouvrent quand tu arrives à portée de voix : le Bailli des Landes, pendu le dernier, à la place d'honneur.

Choix affichés : [Rester au sommet] · [Ne plus afficher]

> choisit : « Rester au sommet »

## Écran 37 · Jour 2

Hanté Ce que tu as vu ne s'est pas rangé. Ça reste posé de travers dans ta tête, et ça bouge quand tu ne le regardes pas. Le vent tombe d'un coup, comme on ferme une porte. Et dans ce calme plat, les neuf cordes du cercle se mettent à bouger. Pas au hasard : ensemble. Un balancement lent, réglé, qui va et vient sur le même temps. Ça grince en mesure. Neuf cordes, un seul rythme. Tu comprends, avec un retard qui te coûte, que ce rythme ne t'est pas indifférent — tu pourrais le compter. Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau. OBTENU — FIOLE D'EAU DE GOUTTIÈRE · COMMUN Trou

Choix affichés : [Hanté Ce que tu as vu ne s'est pas rangé. Ça reste posé de t] · [Arracher une écharde COURAGE] · [Rester et compter INSTINCT] · [Partir avant de comprendre] · [Ne plus afficher]

> choisit : « Arracher une écharde COURAGE »

## Écran 38 · Jour 2

Tu détaches une longue écharde du montant. Le bois est doux, poli par des mains — combien de mains ? L'ombre au sol frémit, mais ne bouge pas vers toi. Des bêtes broutent la bruyère morte au creux du vallon — un troupeau entier, sans personne. Elles ne s’écartent pas quand tu approches : elles lèvent la tête, te regardent une seconde, et se remettent à brouter. C’est ce détail qui te dérange le plus. Elles n’ont pas appris à se méfier.

Choix affichés : [Ne plus afficher]

## Écran 39 · Jour 2

Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau. Le vent dit un nom. Ce n'est pas le tien. Tu le retiens quand même.

Choix affichés : [Les marques d’oreille] · [S’avancer dans le vallon] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Les marques d’oreille »

## Écran 40 · Jour 2

Tu marches jusqu’au bord du troupeau. Les bêtes te laissent entrer entre elles comme si tu étais un piquet de plus. De près, elles sont grasses, entretenues — quelqu’un les a menées, soignées, comptées, et pas il y a trente ans : cette laine-là a vu un berger cette saison.

Choix affichés : [Ne plus afficher]

## Écran 41 · Jour 2

Tu comptes. Dix, peut-être douze. Elles portent des marques d’oreille, et les marques ne sont pas toutes les mêmes. Tu en relèves cinq différentes. Ce ne sont pas les bêtes d’un seul homme : ce sont les bêtes de cinq hommes, réunies en un seul troupeau, et personne n’est venu les séparer.

Choix affichés : [S’avancer dans le vallon] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « S’avancer dans le vallon »

## Écran 42 · Jour 2

Une brebis s’écarte du groupe et marche droit vers le nord-est, s’arrête, revient. Puis recommence. Cinq fois pendant que tu la regardes. Elle refait un trajet. Elle attend au bout de quelque chose qui n’arrive plus. Dans cette direction, à un quart d’heure de marche, il y a le Champ des Fixés. Tu portes la main à ton cou. Il n'y a rien. Tu l'y portes quand même.

Choix affichés : [Continuer ton chemin] · [Suivre la brebis] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Continuer ton chemin »

## Écran 43 · Jour 2

Tu t’éloignes, et le troupeau se referme derrière toi comme de l’eau. Dans ton dos, une clochette. Une seule, quelque part au milieu des bêtes — celle qu’on met au cou de la meneuse, pour que le berger sache où est son troupeau dans le brouillard. Elle sonne toute seule, pour personne. Sur une pierre du chemin, une croix à la craie — vieille, à moitié lavée. Pas la tienne. Quelqu'un d'autre, avant toi, a entendu quelque chose. Tu ne sauras pas où il pend.

Choix affichés : [Ne plus afficher]

## Écran 44 · Jour 2

D'un côté, des rangs d'arbres qui n'ont plus de feuilles. De l'autre, une masse trapue privée de ses ailes.

Choix affichés : [Vers des rangs d'arbres noirs] · [Vers un moulin sans ailes] · [Ne plus afficher]

> choisit : « Vers des rangs d'arbres noirs »

## Écran 45 · Jour 3

— JOUR 3 — Des rangs réguliers montent de la bruyère. De loin, c'est presque rassurant. Tu es passé sous le vent. Rien ne s'est retourné, et tu n'as regardé que tes pieds. Des arbres fruitiers plantés en rangs — le seul ordre volontaire des Landes hors du hameau. Ils ont poussé, ils ont des branches, des feuilles noires, et des fruits. C'est pire que s'ils étaient morts. Les rangs et leurs fruits. La souche du premier arbre, au bout. Et deux silhouettes qui bêchent, tout au fond.

Choix affichés : [Ne plus afficher]

## Écran 46 · Jour 3

Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Choix affichés : [Les fruits, dans les rangs] · [Observer les alentours] · [Goûter un fruit COURAGE] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Les fruits, dans les rangs »

## Écran 47 · Jour 3

Tu entres dans un rang. L'odeur devrait arriver là — pas de pourriture : pas d'odeur du tout. Un verger qui ne sent rien. Ronds, lourds, gris mat. La peau est parfaite et le poids ment : tu en décroches un, il pèse comme une pierre et cède comme du papier. Des fruits de cendre. Tu en gardes un. On ne sait jamais ce qu'on est prêt à parier.

Choix affichés : [La souche, au bout du rang] · [Observer les alentours] · [Goûter un fruit COURAGE] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « La souche, au bout du rang »

## Écran 48 · Jour 3

Au bout du rang, un arbre manque. Sa souche est nette, sciée à hauteur de genou, et le bois de coupe est gris. Le premier arbre du verger, abattu net. Les cernes sont réguliers jusqu'aux dernières années — puis serrés, noirs, illisibles. L'arbre a compris avant les hommes où il poussait. Quelqu'un l'a abattu pour ne pas avoir à le lire. En te relevant, tu comptes les rangs par habitude, et le compte te reste dans la tête : onze vergers replantés sur une terre qui n'a jamais rien donné.

Choix affichés : [Les deux qui bêchent, au fond] · [Observer les alentours] · [Goûter un fruit COURAGE] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Les deux qui bêchent, au fond »

## Écran 49 · Jour 3

Tu remontes les rangs vers eux. Ils se relaient sur la même bêche sans se parler, du geste réglé des gens qui font la même chose ensemble depuis toujours. Ils plantent. Dans cette terre. Un trou, un plant, la terre refermée du talon — et le trou suivant, deux pas plus loin. La femme se redresse la première. Elle ne sursaute pas — plus rien ne les surprend, ici.

Choix affichés : [Ne plus afficher]

## Écran 50 · Jour 3

— « C'est le onzième verger. » Elle le dit avant toute autre chose, comme on donne son nom. « Les dix premiers ont donné des fruits de cendre. Celui-là aussi. Le douzième, on verra. » L'homme continue de bêcher. Il n'a pas levé la tête. Il compte les coups de bêche à voix basse. Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau. Une ombre passe à ta gauche, à la vitesse d'un homme qui marche. Quand tu regardes, rien ne marche nulle part.

Choix affichés : [« Pourquoi continuer ? »] · [Prendre la bêche un moment EMPATHIE] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « « Pourquoi continuer ? » »

## Écran 51 · Jour 3

— « Parce qu'arrêter, c'est commencer à regarder le sud. » Elle essuie la bêche contre sa jambe, un geste d'habitude. « Bêcher, ça occupe les yeux. » Derrière elle, le compte à voix basse n'a pas manqué un coup. — « Tu viens du dehors. » Ce n'est pas une question : c'est une prière déguisée en constat. « Il te reste forcément quelque chose du dehors. N'importe quoi. Une graine, un bout de vrai bois, une chose qui a poussé sous le vrai soleil. On le planterait. »

Choix affichés : [Ne plus afficher]

## Écran 52 · Jour 3

Tu sais ce que tu as : rien. Tu arrives ici comme tout le monde y arrive — les mains vides et mort. Quelque chose grince très haut, très loin, à une hauteur où il n'y a rien.

Choix affichés : [Chercher dans ta besace] · [« Je n'ai rien. » EMPATHIE] · [Demander qui passe par ici] · [Promettre pour la prochaine fois RUSE] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Chercher dans ta besace »

## Écran 53 · Jour 3

Tu fouilles longuement, pour de vrai. Tout ce que tu portes vient d'ici : une écharde de gibet, du chanvre béni, de la cendre. Rien du dehors. Tu leur montres tes mains ouvertes, et ils regardent dedans quand même, tous les deux, comme on regarde un puits. Ils se remettent au travail avant que tu sois sorti des rangs — le onzième verger n'attend pas.

Choix affichés : [Ne plus afficher]

## Écran 54 · Jour 3

Longtemps après, tu entends encore le compte à voix basse, régulier comme une corde qui grince : c'est le bruit que fait l'espoir quand il refuse de savoir.

Choix affichés : [Remonter les rangs] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Remonter les rangs »

## Écran 55 · Jour 3

Un fruit tombe, derrière toi. Sans vent, sans oiseau. Quand tu le ramasses, il est encore chaud — comme une chose qui vient de cesser d'essayer.

Choix affichés : [Le reposer au pied de l'arbre] · [Sortir des rangs INSTINCT] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Le reposer au pied de l'arbre »

## Écran 56 · Jour 3

Tu le reposes exactement sous la branche d'où il vient, bien calé dans la terre, comme on remet quelque chose à sa place. Le geste ne sert à rien. Tu le fais quand même, et le verger entier te paraît une seconde moins hostile. Elle croise ta route sans ralentir, à trois pas, comme on croise quelqu'un dans un couloir. « Ne bois pas à la mare basse. Ils y jettent ce qu'ils ne veulent pas enterrer. » Elle est déjà loin quand tu penses à répondre.

Choix affichés : [Ne plus afficher]

## Écran 57 · Jour 3

D'un côté, une masse trapue privée de ses ailes. De l'autre, un chemin qui s'enfonce entre deux talus. Pendant une seconde, le sol sous tes pieds est de la terre retournée de frais.

Choix affichés : [Vers un moulin sans ailes] · [Vers le chemin creux] · [Ne plus afficher]

> choisit : « Vers un moulin sans ailes »

## Écran 58 · Jour 3

Tu quittes les toits. La masse trapue grandit contre le crépuscule. Tu as longé le talus à contre-jour. Mauvais angle pour être reconnu, mauvais angle pour voir. Le moulin n'a plus d'ailes mais il a gardé leur trace : quatre ombres pâles en croix sur le corps de pierre, comme un moulin fantôme peint sur le vrai. La porte est entrouverte. Pas défoncée : entretenue. La croix d'ombres, en haut. La lucarne, qui te regarde. Et la porte, qui n'attend que toi.

Choix affichés : [Ne plus afficher]

## Écran 59 · Jour 3

Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau. — « Tu comptes, toi aussi. » Personne autour de toi n'a ouvert la bouche. Le lit de bruyère du moulin est tassé, refait de frais. Quelqu'un dort ici — souvent, prudemment, sans feu. Sur la pierre du mur, à hauteur d'enfant, des marques : des jours comptés par paquets de cinq, sur des années.

Choix affichés : [Ne plus afficher]

## Écran 60 · Jour 3

Et dans un creux du mur, serré dans un chiffon : un bout de corde. Coupé net. Pas usé, pas rompu — coupé. On ne garde pas ça par hasard. On garde ça comme une preuve, ou comme un pardon.

Choix affichés : [Observer les alentours] · [S'installer pour la halte] · [Écouter le moulin INSTINCT] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Observer les alentours »

> choisit : « La crête du toit »

## Écran 61 · Jour 3

Tu contournes la tour et tu lèves les yeux vers le faîtage. La mousse a mangé toute la pierre, sauf une bande, en haut, nette comme un sentier. La bande sans mousse court sur toute la longueur du toit, large comme deux mains, usée. Puis elle s’arrête. Pas en s’amenuisant : d’un coup, à cinquante pas de la porte, comme si quelque chose qui marchait là s’était retourné chaque fois exactement au même endroit.

Choix affichés : [Observer les alentours] · [S'installer pour la halte] · [Écouter le moulin INSTINCT] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Observer les alentours »

> choisit : « La croix d'ombres, en haut »

## Écran 62 · Jour 3

Tu recules jusqu'au muret d'en face. Il faut de la distance pour la voir entière — c'est une trace, pas un détail. De loin, les quatre bandes pâles se lisent d'un coup : ce sont des zones où la pierre n'a pas vieilli, protégée des années par les ailes, puis abandonnée au vent d'un seul coup. On peut dater une catastrophe à la couleur d'un mur. Celle-ci est vieille comme le Domaine.

Choix affichés : [Ne plus afficher]

## Écran 63 · Jour 3

Les marques de comptage de son mur ne s'arrêtent pas. Elles continuent après la date qu'on devine être celle de sa pendaison. Quelqu'un compte encore ses jours — et ce quelqu'un sait qu'elle en a toujours.

Choix affichés : [Observer les alentours] · [S'installer pour la halte] · [Écouter le moulin INSTINCT] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Observer les alentours »

> choisit : « La lucarne, au-dessus de la porte »

## Écran 64 · Jour 3

Quelque chose a bougé là-haut — tu en jurerais. Tu approches sans quitter l'ouverture des yeux, ce qui est exactement la mauvaise façon d'approcher d'une porte. La lucarne est vide. Et propre : pas un grain de poussière sur le rebord intérieur. Quelqu'un s'y accoude. Souvent. Pour regarder ce chemin — celui par lequel tu viens d'arriver.

Choix affichés : [Observer les alentours] · [S'installer pour la halte] · [Écouter le moulin INSTINCT] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Observer les alentours »

> choisit : « Pousser la porte entrouverte »

## Écran 65 · Jour 3

Tu pousses du plat de la main, lentement, en laissant à ce qu'il y a dedans le temps de décider s'il veut être vu. Personne. Mais le contraire de l'abandon : une paillasse faite au carré, un pot ébréché où trempent des brins de bruyère — de la bruyère fraîche. Quelqu'un habite ici avec un soin de vivant. Tu ressors sans toucher à rien, et c'est la première politesse que tu offres aux Landes.

Choix affichés : [Ne plus afficher]

## Écran 66 · Jour 3

Les mères d'ici ne défendent pas à leurs enfants d'aller au moulin. Elles leur défendent de lui PARLER. La nuance est terrible : ils savent tous qu'elle y est. Sa corde a été coupée net, à la lame, et on l'a descendue vivante. Le brin sectionné est encore accroché à la traverse.

Choix affichés : [S'installer pour la halte] · [Écouter le moulin INSTINCT] · [Fouiller le lit de bruyère] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « S'installer pour la halte »

## Écran 67 · Jour 3

Par la lucarne, le crépuscule ne bouge pas. On dit qu'une fille dort ici, parfois — la seule pendue qui se soit relevée. Le lit de bruyère garde une forme légère, comme un creux encore tiède. Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Choix affichés : [Dormir malgré le crépuscule] · [Repartir sans s'attarder] · [Monter la garde INSTINCT] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Dormir malgré le crépuscule »

## Écran 68 · Jour 4

Fiévreux Le froid t'a lâché d'un coup, et c'est mauvais signe : ce n'est plus l'air qui te réchauffe. Tes mains tremblent quand tu ne les regardes pas. — JOUR 4 — Elle passe, et elle parle sans tourner la tête. « Tu marches comme quelqu'un qui compte les jours. » Un temps, sa voix déjà derrière toi : « Moi j'ai arrêté au troisième. » Quand tu te retournes, la bruyère se referme sur rien. D'un côté, des bâches tendues et pas une voix. De l'autre, une eau noire où les roseaux ne bougent pas. Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Choix affichés : [Fiévreux Le froid t'a lâché d'un coup, et c'est mauvais sign] · [Ne plus afficher]

> choisit : « Vers un marché muet »

## Écran 69 · Jour 4

Le chemin redescend vers les toits gris. Tu repasses la limite du village sans t'en apercevoir tout à fait : un muret, un seuil, et le bruit de la lande qui s'arrête net derrière toi. Un bourdonnement de foule sans une seule voix te parvient — des dizaines de gens qui s'affairent en silence. Tu entres dans le marché muet du hameau. Tu n'as rien contourné. Tu arrives par la face, et rien ne t'a échappé en chemin.

Choix affichés : [Ne plus afficher]

## Écran 70 · Jour 4

Au cœur du hameau, un marché sans un cri. Des étals de trois fois rien — clous, laine, racines — et des marchands qui négocient par gestes, paumes et hochements. Renoncer à la parole est le renoncement le plus courant. Le moins cher. Un corbeau sur le faîtage. Une conversation s'éteint à ton approche. Pas interrompue : pliée, rangée, comme du linge qu'on rentre avant la pluie.

Choix affichés : [Observer un troc] · [Saluer à leur manière RUSE] · [Longer les étals] · [Ne plus afficher]

> choisit : « Observer un troc »

## Écran 71 · Jour 4

Deux paumes ouvertes, un hochement, trois doigts — refus. Deux doigts — accord. Le marchandage muet a sa grammaire, et tu en apprends l'essentiel en un échange : ici, montrer ses mains vaut passeport. Les cacher vaut aveu. Au bout de la rangée, un étal différent : bric-à-brac d'ailleurs, objets qui n'ont rien à faire dans une lande. Le Colporteur te regarde venir de loin — et te reconnaît. C'est impossible. Il te fait signe quand même, comme à un client de longue date. Un corbeau sur le faîtage.

Choix affichés : [Montrer tes plaies EMPATHIE] · [Traverser sans offrir] · [Demander d’où vient la viande] · [Demander s’il soigne le soir] · [Troquer au Marché RUSE] · [Ne plus afficher]

> choisit : « Montrer tes plaies EMPATHIE »

## Écran 72 · Jour 4

Ses mains sont dures et savantes. Ça craque, ça brûle, puis ça va mieux — nettement. Il désigne ta poitrine, puis la lande, puis fait « non » du doigt : ce qu'il a resserré tiendra, à condition de ne pas courir. Tu changes de ruelle, et une conversation s'éteint à ton entrée, exactement comme on souffle une lampe. Trois pas plus loin, elle reprend derrière toi — pas la même, plus basse, plus courte.

Choix affichés : [Ne plus afficher]

## Écran 73 · Jour 4

D'un côté, une maison murée de l'intérieur. De l'autre, un gibet bas, à hauteur d'homme, qui bouge sans vent. La fièvre lâche prise d'un seul coup, comme une main qui s'ouvre. Le froid revient, et pour la première fois depuis des jours, tu es content de l'avoir. L'espace d'un pas, tes pieds ne touchent plus tout à fait le sol.

Choix affichés : [Vers une maison murée] · [Vers un gibet qui parle] · [Ne plus afficher]

> choisit : « Vers une maison murée »

## Écran 74 · Jour 5

— JOUR 5 — Tu repasses le muret d'enceinte, et le village te lâche d'un coup — plus de toits, plus de volets, plus de regards. La lande reprend, immense, et le vent te retrouve comme s'il t'avait attendu. À l'ouest, une haute toiture seule au-dessus de la bruyère. Sur le seuil, une masse grise se lève sans un aboiement. Tu as coupé par les fougères hautes. Aucun bruit à compter, aucune vue d'ensemble.

Choix affichés : [Ne plus afficher]

## Écran 75 · Jour 5

La maison se tient seule à l'ouest du hameau, haute, sans voisine — et murée de l'intérieur. Chaque fenêtre bouchée de pierres posées depuis dedans, en rangs pressés, par quelqu'un qui s'enfermait plus qu'il ne se protégeait. La maison du Bailli. Vide depuis sa corde. Pas gardée par personne. Tu comptes ce qui t'entoure — les ombres, les pierres. Il y en a toujours une de plus au deuxième compte. La porte est solide, mais ses gonds ne le sont pas. Ils sont posés à l'extérieur.

Choix affichés : [Longer les fenêtres murées] · [Avancer vers le seuil] · [Repérer ce qui garde INSTINCT] · [Ne plus afficher]

> choisit : « Longer les fenêtres murées »

## Écran 76 · Jour 5

Les pierres sont posées de l'intérieur, oui — mais pas n'importe comment : en quinconce serré, du travail soigné, fait sans hâte. Il ne s'est pas barricadé dans la panique. Il a pris le temps de bien s'enfermer. Contre quoi, une maison ne le dit pas. Contre qui, parfois. • RENCONTRE • Le Chien du Bailli

Choix affichés : [Ne plus afficher]

## Écran 77 · Jour 5

Le chien se lève du seuil sans aboyer. Gris, trop grand, le poil usé aux endroits d'un harnais qu'il ne porte plus. Son maître pend à la colline — mais l'ordre, lui, n'a jamais été levé. Personne n'entre. Il te le dit d'un seul regard. Ce chien tient un poste que la mort de son maître n'a pas fermé. Prends-en de la graine : moi aussi.

Choix affichés : [S'accroupir, lui parler EMPATHIE] · [Contourner par la cour RUSE] · [Forcer le passage COURAGE] · [Ne plus afficher]

> choisit : « S'accroupir, lui parler EMPATHIE »

## Écran 78 · Jour 5

Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps. Tu lui laisses le dos de ta main, sans bouger. Il la flaire longtemps — la lande, le gibet, peut-être une trace de son maître dessus. Il ne s'écarte pas, mais il s'assoit : ce n'est plus une garde, c'est une visite. Tu peux longer le mur. Il y a des traces fraîches sur ton chemin — devant toi. Quelqu'un fait ta route avant toi, dans le même sens, à petite distance. Tu ne le rattrapes jamais.

Choix affichés : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pou] · [Ne plus afficher]

## Écran 79 · Jour 5

Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps. D'un côté, une eau noire où les roseaux ne bougent pas. De l'autre, des silhouettes grises qui se déplacent ensemble. Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Choix affichés : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pou] · [Vers une eau qui ne bouge pas] · [Vers des silhouettes grises] · [Ne plus afficher]

> choisit : « Vers une eau qui ne bouge pas »

## Écran 80 · Jour 5

Le vent tombe d'un coup, comme coupé au couteau. Tes derniers pas ne font plus de bruit. Tu as pris la route droite. On t'a vu venir — et tu as eu le temps de tout regarder. L'eau est noire et parfaitement plate — le seul endroit des Landes que le vent évite. La berge est piétinée en un seul point, tassée par des années de genoux. On ne vient pas ici puiser. On vient s'agenouiller. Le point de berge usé. L'eau. Et dans les roseaux, un reflet de métal.

Choix affichés : [Ne plus afficher]

## Écran 81 · Jour 5

Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Choix affichés : [Les creux dans la berge] · [Observer les alentours] · [Boire à la mare COURAGE] · [Ne plus afficher]

> choisit : « Les creux dans la berge »

## Écran 82 · Jour 5

Tu longes la berge jusqu’à l’endroit où la terre est tassée, luisante, usée jusqu’à la pierre. On s’agenouille ici depuis longtemps. Les creux de genoux sont doubles. Une paire devant, au ras de l’eau. Une autre juste derrière, plus large, plus profonde — et orientée dans le même sens. Quelqu’un se tenait toujours au-dessus de celui qui se penchait. Ce n’est pas un endroit où l’on vient voir son reflet : c’est un endroit où on l’amène.

Choix affichés : [Le point de berge usé] · [Observer les alentours] · [Boire à la mare COURAGE] · [Ne plus afficher]

> choisit : « Le point de berge usé »
