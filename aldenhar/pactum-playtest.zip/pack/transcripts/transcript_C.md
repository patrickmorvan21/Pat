# Partie de découverte — v157C (budget épuisé)

## [0] —
*image : geolier_detoure.png, pactum_logo.png*

Tu choisis. Le dé décide.
Lui, il regarde.

COMMENCER
OPTIONS
v1.57.0

CHOIX : [COMMENCER] [OPTIONS]
→ accueil

## [1] —
*image : intro_demon.png*

Tu ne te souviens pas

D'être entré, je veux dire. Personne ne s'en souvient. Tu es mort. Il y a peu.

Ce qui suit est une proposition. Personne ne l'a jamais refusée.

Touche pour commencer

→ continue

## [2] —

Une seule vie

Tu traverses mon Domaine. Une fois. Au bout, une Porte scellée : franchis-la, et tu reprends ta vie là où tu l'as laissée.

Si tu meurs, un autre viendra. Avec un autre nom.

→ continue

## [3] —
*image : intro_de.png*

Le dé tranche

Ton adresse ne te sauvera pas. Courage, ruse, instinct, empathie : ce que tu vaux vient de ce que tu étais de ton vivant.

Touche pour continuer

→ continue

## [4] —
*image : intro_epee.png*

Ta mort me sert

Ta fin est forgée en Relique. Celui qui te suivra la portera. On ne progresse pas ici en survivant. En tombant mieux.

Touche pour continuer

→ continue

## [6] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Avant que tu passes, je veux voir qui tu étais.

Touche pour continuer

→ continue

## [8] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Ne réfléchis pas. Ce n'est plus toi qui choisis, ici — c'est ce que tu as déjà fait.

Touche pour continuer

→ continue

## [10] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Un loup affamé bloque le sentier entre toi et le village.

Avancer, le regarder dans les yeux
Reculer lentement, sans courir
Chercher une pierre à lancer

CHOIX : [Avancer, le regarder dans les yeux] [Reculer lentement, sans courir] [Chercher une pierre à lancer]
→ choix: Avancer, le regarder dans les yeux

## [12] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Le coffre s'ouvre, mais quelque chose dans le mécanisme sonne faux.

Chercher le compartiment caché
Prendre ce qui est visible, partir vite
Refermer, ne rien toucher

CHOIX : [Chercher le compartiment caché] [Prendre ce qui est visible, partir vite] [Refermer, ne rien toucher]
→ choix: Chercher le compartiment caché

## [14] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Le chemin sur ta carte ne colle plus au paysage que tu as sous les yeux.

Faire confiance à ce que tu vois
Suivre la carte à la lettre
Rebrousser chemin, trop incertain

CHOIX : [Faire confiance à ce que tu vois] [Suivre la carte à la lettre] [Rebrousser chemin, trop incertain]
→ choix: Suivre la carte à la lettre

## [16] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Un inconnu blessé au bord du chemin. Personne d'autre ne s'arrête.

L'aider, quitte à perdre du temps
Fouiller ses affaires d'abord
Passer ton chemin

CHOIX : [L'aider, quitte à perdre du temps] [Fouiller ses affaires d'abord] [Passer ton chemin]
→ choix: Passer ton chemin

## [18] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Une dernière chose. J'ai vu qui tu étais. Il me manque comment on t'appelait.

SCELLER LE PACTE
Qu'il choisisse pour moi

CHOIX : [Qu'il choisisse pour moi]
→ sceller le pacte

## [20] borne-frontiere · Jour 1 · santé 1
*image : intro_demon.png*

Tu avances avant de comprendre. Le danger t'a toujours moins arrêté que le doute.
Mais les autres restent pour toi un bruit de fond. Ça t'a coûté. Ça te coûtera encore.

Je sais qui tu es. Le dé, lui, décidera qui tu deviens.

Touche pour commencer

→ continue

## [21] borne-frontiere · Jour 1 · santé 1
*image : scene_landes_frise_montagnes_pleine_b.png*

• LE DOMAINE •

Les Lisières

Touche pour continuer

→ continue

## [25] borne-frontiere · Jour 1 · santé 1
*image : scene_borne_frontiere_v2_a.png, geolier_portrait.png*

— JOUR 1 —

La lande s'ouvre sous un crépuscule qui ne tombe pas. La lumière reste prise entre chien et loup, comme un souffle retenu. Quelque part, une corde grince.

La pierre est seule au milieu du plateau, dressée là où tous les murets renoncent. Haute comme un homme, grise comme le reste — et pourtant l'œil ne voit qu'elle. À son pied, un tas d'offrandes. Au-delà, le sud, nu. Et à trois pas de la borne, un homme immobile, face au sud.

À partir de maintenant, il décide avec moi.

CHOIX : [Observer les alentours] [Fouiller les offrandes RUSE]
→ choix: Écouter, immobile

## [29] borne-frontiere · Jour 1 · santé 1
*image : scene_borne_frontiere_v2_a.png*

Tu ne touches à rien. Tu écoutes. Sous le vent, il y a des voix — basses, à ras de bruyère, qui se passent le mot de ton arrivée. Elles ne te menacent pas. Elles préviennent quelqu'un. Au moins, maintenant, tu sais que la lande parle.

Où que le chemin tourne, la couronne de la colline reste en vue — et le grand gibet dépasse, patient. Tu commences à comprendre : ce n'est pas toi qui le regardes.

→ continue

## [33] borne-frontiere · Jour 1 · santé 1
*image : scene_hameau_dense_b.png, geolier_portrait.png*

Deux directions s'ouvrent. D'un côté, une crête hérissée de mâts noirs. De l'autre, des toits bas et une fumée qui ne monte pas droit.

À l'horizon, la colline porte sa couronne de potences. L'une dépasse toutes les autres — de beaucoup trop. Aucun homme n'a jamais eu cette taille. Et c'est la seule dont la corde pend, vide.

Chaque route que tu ne prends pas, quelqu'un d'autre la prend. Je tiens les deux registres.

CHOIX : [Vers la crête aux cordes] [Vers la fumée d'un hameau]
→ choix: Vers la fumée d'un hameau

## [38] serment-hameau · Jour 1 · santé 1
*image : scene_hameau_dense2_b.png*

De la fumée basse, pas une flamme : des toits gris tassés derrière leurs murets. Le Hameau des Renonçants se découvre lentement, et déjà tu sens qu'on t'a vu venir de loin.

Tu es passé sous le vent. Rien ne s'est retourné, et tu n'as regardé que tes pieds.

Les toits apparaissent au creux du plateau — de l'ardoise affaissée, des murs qui tiennent par habitude. Une seule cheminée fume, sur une vingtaine.

Tu es encore loin quand tu comprends ce qui cloche : aucun chien n'aboie.

CHOIX : [Observer d'abord, à couvert INSTINCT] [Descendre vers le hameau]
→ choix: Descendre vers le hameau

## [41] hameau-entree-2 · Jour 1 · santé 1
*image : scene_hameau_entree_2_v2_a.png*

La première maison est à dix pas. Sur sa porte, un signe à la craie — une croix, simple, tracée à hauteur d'œil.

La poudre blanche est encore sur le seuil. Ça date de ce matin.

CHOIX : [Le linteau de la porte] [Observer les alentours] [Continuer dans la rue]
→ choix: Le linteau de la porte

## [44] hameau-entree-2 · Jour 1 · santé 1
*image : scene_hameau_linteaux_v2_c.png*

Tu passes devant une porte, puis une autre, et quelque chose accroche ton regard sans que tu saches quoi. Tu reviens sur tes pas et tu lèves la tête.

Au-dessus du linteau, une entaille dans le bois. Courte, profonde, un peu de biais. Tu regardes la porte suivante : la même, à la même hauteur. Et la suivante. Ce n’est pas une marque de charpentier — le bord est écrasé, pas coupé. Rien de ce que tu connais ne laisse cette trace-là.

CHOIX : [Les fenêtres des combles] [Observer les alentours] [Continuer dans la rue]
→ choix: Continuer dans la rue

## [47] hameau-accueil-volet · Jour 1 · santé 1
*image : scene_hameau_accueil_volet_c.png*

La rue est vide. Pas déserte — vide : une porte qui bat encore, un seau posé de travers, une flaque de lait qui n'a pas eu le temps de sécher. Tout le monde vient de rentrer, et vite.

Un volet s'entrouvre à ta gauche, de deux doigts. Une voix de femme, basse, très rapide, aucun visage derrière : — « Ne touche pas les portes marquées. Ne réponds pas si on t'appelle par ton nom. Et va au muret, au bout, avant qu'on vienne te chercher. »

→ continue

## [50] hameau-accueil-volet · Jour 1 · santé 1
*image : scene_hameau_accueil_volet_c.png, geolier_portrait.png*

Le volet ne se referme pas tout de suite. Elle attend quelque chose de toi.

Elle t'a donné trois règles. Moi je t'en ai donné une seule, et tu la tiens déjà mal.

CHOIX : [La faire parler encore RUSE] [Lui demander pourquoi elle t'aide EMPATHIE] [Obéir sans un mot]
DÉ → FUNESTE
→ lance le dé

## [55] hameau-entree-4 · Jour 2 · santé 0.74 · soupçon 1
*image : monstre_hameau_entree_4_c.png*

Ta ruse est trop visible. « Tu me fais parler », constate-t-elle, sans colère, presque avec pitié. « C'est exactement ce que fait l'autre. » Le volet se ferme, et tu ne sauras pas de quel autre elle parlait.

— JOUR 2 —

La lande t'a pris un jour. La lumière a tourné sans que tu avances.

Au bout de la rue, un muret bas ferme le village côté sud. Le vieux y est assis, sec comme un piquet, les coudes sur les genoux. Il t'attendait là depuis le début.

→ continue

## [59] hameau-entree-4 · Jour 2 · santé 0.74 · soupçon 1
*image : monstre_hameau_entree_4_c.png*

Il tend la main, paume ouverte. Pas pour serrer la tienne — pour que tu la regardes. Elle est vide. C'est le geste d'ici : on jure sur rien, parce qu'il ne reste rien.

— « Trois choses, et tu dors sous un toit. Tu ne parles pas aux pendus. Tu ne regardes pas le sud plus qu'il ne faut. Et à la troisième aube, tu choisis. »

Trois hommes, un bâton. S'il fallait vraiment passer en force, ça passerait.

Un corbeau sur le faîtage.

→ continue

## [61] hameau-entree-4 · Jour 2 · santé 0.74 · soupçon 1
*image : monstre_hameau_entree_4_c.png*

Les rares mots qu'on t'adresse ont raccourci. On te répond sec, sans te regarder — pas de l'hostilité. De l'économie.

OBTENU — BANDAGE D'UN AUTRE · COMMUN
Son premier propriétaire n'en aura plus besoin.

CHOIX : [Observer les alentours] [Refuser de jurer] [Jurer du bout des lèvres] [Jurer]
→ choix: Demander pourquoi trois aubes

## [64] hameau-entree-4 · Jour 2 · santé 0.74 · soupçon 2
*image : scene_hameau_trois_aubes_v2_c.png*

Tu ne réponds pas tout de suite. Tu poses la question, et les quelques-uns qui s'étaient approchés attendent la réponse avec toi — comme si personne n'avait jamais osé la poser.

→ continue

## [66] hameau-entree-4 · Jour 2 · santé 0.74 · soupçon 2
*image : scene_hameau_trois_aubes_v2_c.png*

— « Trois aubes pour reprendre des forces. » Le vieux compte sur sa main, sans ironie aucune. « La première, on te soigne. La deuxième, on te montre ce que serait ta vie ici. À la troisième, tu repars — ou tu poses ton nom parmi les nôtres. » Il te regarde avec quelque chose qui ressemble beaucoup à de la bienveillance, et c'est bien ça qui te glace.

CHOIX : [Refuser de jurer] [Demander qui juge, ici] [Jurer du bout des lèvres] [Jurer]
→ choix: Demander qui juge, ici

## [70] hameau-entree-5 · Jour 2 · santé 0.74 · soupçon 2
*image : scene_hameau_entree_5_v2_a.png*

La vieille femme derrière le vieux répond à sa place, sans qu’on lui ait rien demandé. « Avant, on jugeait le jour. » Elle rajuste son châle. « Maintenant on juge la nuit. C’est pas moi qui ai décidé du changement d’horaire. »

Ils s'écartent. Pas beaucoup — juste assez pour que tu passes sans toucher personne, et tu comprends que c'est calculé.

La rue s'ouvre devant toi. Des volets se ferment à mesure, un par un, un peu en avance sur ton pas. Quelque part, une corde grince.

→ continue

## [74] hameau-entree-5 · Jour 2 · santé 0.74 · soupçon 2
*image : scene_hameau_entree_5_v2_a.png*

Te voilà dans le hameau. Personne ne t'a souhaité la bienvenue, et pourtant tous savaient déjà que tu venais.

Il y a un corbeau sur le toit d'en face. Il y était déjà dans l'autre rue.

Une conversation s'éteint à ton approche. Pas interrompue : pliée, rangée, comme du linge qu'on rentre avant la pluie.

CHOIX : [Entrer dans le hameau] [Utiliser — Bandage d'un autre]
→ choix: Entrer dans le hameau

## [77] hameau-entree-5 · Jour 2 · santé 0.74 · soupçon 2
*image : scene_hameau_dense_c.png*

Sur une pierre du chemin, une croix à la craie — vieille, à moitié lavée. Pas la tienne. Quelqu'un d'autre, avant toi, a entendu quelque chose. Tu ne sauras pas où il pend.

D'un côté, une masse trapue privée de ses ailes. De l'autre, une crête hérissée de mâts noirs.

CHOIX : [Vers un moulin sans ailes] [Vers la crête aux cordes]
→ choix: Vers la crête aux cordes

## [81] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3
*image : scene_colline_aux_gibets_c.png*

— JOUR 3 —

Le dernier seuil passé, la lande te reprend sans transition — le vent d'abord, l'espace ensuite. Derrière toi, le village continue de se taire, mais autrement.

Tu montes. Les mâts deviennent des potences.

Tu as coupé par les fougères hautes. Aucun bruit à compter, aucune vue d'ensemble.

→ continue

## [84] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3
*image : scene_colline_aux_gibets_c.png*

La pente est douce et n'en finit pas — la Colline se mérite à pas comptés. Au sommet, le cercle : neuf potences ordinaires, plantées comme les heures d'un cadran. Et au centre, l'autre. La grande. Sa corde est la seule chose neuve à dix lieues.

À gauche du cercle, un poteau isolé porte encore son occupant. À droite, les potences vides alignent leurs noms gravés.

→ continue

## [87] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3
*image : scene_colline_aux_gibets_c.png*

De près, le grand gibet est pire : taillé large, chevillé double, dimensionné pour un cou qui n'est pas un cou d'homme. Celui qui l'a bâti savait exactement quelle taille il visait.

Sa corde est usée en son milieu — pas au nœud, au MILIEU. Comme si quelque chose l'avait éprouvée de l'intérieur, longtemps, sans jamais s'y laisser prendre. Juste à côté, un gibet bas, à hauteur d'homme. Occupé, lui.

CHOIX : [Le pied du grand gibet] [Observer les alentours] [Rester au sommet] [Utiliser — Bandage d'un autre]
→ choix: Le pied du grand gibet

## [92] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3
*image : scene_colline_pied_grand_gibet_b.png*

Tu quittes la ligne des potences ordinaires pour celle qui les dépasse toutes. De près, elle est absurde : trois fois trop haute pour un homme, et sa corde est neuve.

Au pied du mât, dans le bois, un nom a été gravé profond, à la gouge, par quelqu’un qui prenait son temps. Il est illisible — pas effacé par la pluie : GRATTÉ, en travers, par quelque chose qui a mordu le bois plus fort que l’outil. Dessous, une date est restée entière. Elle est vieille de trente ans.

CHOIX : [Les corbeaux, sur la traverse] [Observer les alentours] [Rester au sommet] [Utiliser — Bandage d'un autre]
→ choix: Le poteau isolé, à gauche

## [96] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3
*image : scene_landes_poteau_pendu_c.png*

Tu contournes le cercle par la gauche. Le poteau isolé est plus bas que les autres — à hauteur d'homme, exactement. Une hauteur qu'on choisit.

Chaîne de fonction au cou, sous la corde. Un sceau au poing. Et les yeux qui s'ouvrent quand tu arrives à portée de voix : le Bailli des Landes, pendu le dernier, à la place d'honneur.

CHOIX : [Les corbeaux, sur la traverse] [Observer les alentours] [Rester au sommet] [Utiliser — Bandage d'un autre]
→ choix: Les potences du cercle

## [100] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3
*image : scene_colline_potences_cercle_a_c.png*

Tu entres dans le cercle. Le vent monte d'un cran dès le premier pas entre deux potences — pas plus fort ailleurs, plus fort ICI, comme si l'espace entre les mâts avait son climat.

Chaque potence porte un nom gravé au pied, et une date. Les entailles sont de la même main — appliquée, régulière, la main de quelqu'un qui grave comme on rend un jugement.

→ continue

## [102] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3
*image : scene_colline_potences_cercle_a_c.png*

Le bois du grand gibet ne vient pas des Landes. Il n'y pousse rien d'assez droit ni d'assez épais. On l'a fait monter de loin, par charrette, en plusieurs voyages — un chantier, pas un accès de colère.

CHOIX : [Les corbeaux, sur la traverse] [Le Gibet Vide, au centre] [Rester au sommet] [Utiliser — Bandage d'un autre]
→ choix: Le Gibet Vide, au centre

## [105] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3 · hante
*image : scene_colline_gibet_vide_a_b.png*

Tu marches vers le centre, et la chose grandit plus vite que tes pas. À dix mètres, tu comprends que tu avais mal jugé l'échelle. À trois, tu dois lever la tête pour voir le nœud.

Le bois est d'œuvre, assemblé pour durer mille ans. La corde neuve grince. Par grand soleil — rare, ici — l'ombre portée s'étend vers le sud, et elle a une forme que la potence n'explique pas.

→ continue

## [107] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3 · hante
*image : scene_colline_gibet_vide_a_b.png*

En le bâtissant, le Bailli aurait dit une phrase que le hameau se répète encore, sans la comprendre : « Celui-là, il faudra qu'il descende de lui-même. » On ne bâtit pas un gibet pour quelqu'un qui doit y monter volontairement. Sauf s'il n'y a pas d'autre moyen.

→ continue

## [109] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3 · hante
*image : scene_colline_gibet_vide_a_b.png*

On raconte que le grand gibet a été taillé pour le Bailli, du temps où il jugeait encore. « À sa mesure », répètent ceux qui tiennent l'histoire — sans jamais expliquer quelle mesure il faudrait à un homme pour une traverse pareille.

CHOIX : [Les corbeaux, sur la traverse] [Rester au sommet] [Utiliser — Bandage d'un autre]
→ choix: Les corbeaux, sur la traverse

## [111] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3 · hante
*image : monstre_corbeaux_du_compte_b.png*

Ils sont sur la traverse du grand gibet, immobiles, et ils ne bougent pas quand tu approches — ce qui n'est pas un comportement d'oiseau. Aucun ne te regarde. Ils regardent la corde.

→ continue

## [114] colline-aux-gibets · Jour 3 · santé 0.74 · soupçon 3 · hante
*image : monstre_corbeaux_du_compte_b.png*

Ils ne mangent pas. Il n'y a rien à manger ici depuis longtemps, et leurs becs sont propres. Ils attendent, et ils sont exactement assez nombreux pour ce qu'ils attendent. La même immobilité que des sentinelles payées d'avance, la même façon d'être tournés du même côté — comme des choses qu'on a postées là. Ils comptent quelque chose qui te concerne, et le compte n'a pas l'air fini.

Il n'y en a qu'un, et il se tient de travers, comme s'il gardait une place. Tu ne sais pas pour qui.

CHOIX : [Rester au sommet] [Utiliser — Bandage d'un autre]
→ choix: Utiliser — Bandage d'un autre

## [118] colline-aux-gibets-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : scene_colline_gibets_2_a.png, etat_hante.png*

Hanté
Ce que tu as vu ne s'est pas rangé. Ça reste posé de travers dans ta tête, et ça bouge quand tu ne le regardes pas.

Tu sors « Bandage d'un autre » de la Besace. La plaie se referme, l'entaille cède enfin.

Le vent tombe d'un coup, comme on ferme une porte. Et dans ce calme plat, les neuf cordes du cercle se mettent à bouger. Pas au hasard : ensemble. Un balancement lent, réglé, qui va et vient sur le même temps.

Ça grince en mesure. Neuf cordes, un seul rythme. Tu comprends, avec un retard qui te coûte, que ce rythme ne t'est pas indifférent — tu pourrais le compter.

OBTENU — FIOLE D'EAU DE GOUTTIÈRE · COMMUN
Trouble, tiède — mais elle apaise.

CHOIX : [Hanté Ce que tu as vu ne s'est pas rangé. Ça reste posé de travers dans ta tête, et ça bouge quand tu ne le regardes pas.] [Rester et compter INSTINCT] [Arracher une écharde COURAGE] [Partir avant de comprendre]
DÉ → FUNESTE
→ lance le dé

## [129] colline-aux-gibets-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : scene_hameau_dense_c.png*

Tu comptes. Le nombre est petit, et c'est le pire : les cordes ne battent pas les morts de la lande. Elles battent les tiennes. Le compte est juste. Tu redescends sans le dire à voix haute.

Tu redescends de la colline avec les cordes dans le dos. Longtemps, leur grincement te suit — pas parce qu'il porte loin. Parce qu'il a trouvé ton rythme de marche.

D'un côté, des bâches tendues et pas une voix. De l'autre, un craquement de bois, régulier, qui travaille.

CHOIX : [Vers un marché muet] [Vers un craquement de bois] [Ne plus afficher]
→ choix: Vers un marché muet

## [133] marche-muet · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : scene_marche_muet_c.png*

Un muret, puis un autre, puis les premiers toits — le village se referme autour de toi sans un bruit, comme une main qu'on a laissée ouverte exprès.

Un bourdonnement de foule sans une seule voix te parvient — des dizaines de gens qui s'affairent en silence. Tu entres dans le marché muet du hameau.

Tu as pris la route droite. On t'a vu venir — et tu as eu le temps de tout regarder.

→ continue

## [136] marche-muet · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : scene_marche_muet_c.png*

Au cœur du hameau, un marché sans un cri. Des étals de trois fois rien — clous, laine, racines — et des marchands qui négocient par gestes, paumes et hochements. Renoncer à la parole est le renoncement le plus courant. Le moins cher.

Quelque chose grince très haut, très loin, à une hauteur où il n'y a rien.

→ continue

## [139] marche-muet · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : scene_marche_muet_c.png*

Deux femmes s'arrêtent de parler quand tu passes — mais tu as saisi la fin : « … à la Colline aux Gibets. C'est Le Gamin des Murets qui l'a dit. » Elles reprennent leur chemin, plus vite que nécessaire.

Six corbeaux se posent quand tu débouches dans la rue — sans un cri, sans une dispute, comme des gens qui prennent leur poste.

→ continue

## [141] marche-muet · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : scene_marche_muet_c.png*

Une mère tire son enfant à l'intérieur sans un mot. Plus loin, la Doyenne croise ton chemin et parle sans s'arrêter : « Quoi que tu entendes, ne réponds pas. Ici, on regarde les bouches. »

CHOIX : [Observer un troc] [Saluer à leur manière RUSE] [Longer les étals]
→ choix: Observer un troc

## [143] marche-muet-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_colporteur_b.png*

Deux paumes ouvertes, un hochement, trois doigts — refus. Deux doigts — accord. Le marchandage muet a sa grammaire, et tu en apprends l'essentiel en un échange : ici, montrer ses mains vaut passeport. Les cacher vaut aveu.

→ continue

## [145] marche-muet-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_colporteur_b.png*

Au bout de la rangée, un étal différent : bric-à-brac d'ailleurs, objets qui n'ont rien à faire dans une lande. Le Colporteur te regarde venir de loin — et te reconnaît. C'est impossible. Il te fait signe quand même, comme à un client de longue date. Sur l'étal, aucun fruit. « Ceux du Verger, j'en prends pas », dit-il en suivant ton regard. « Personne n'en prend. »

→ continue

## [149] marche-muet-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_colporteur_b.png*

À l'étal voisin, un vieil homme écrase des feuilles dans un mortier, des fioles bouchées de cire alignées devant lui. Le Rebouteux. Il ne lève pas la tête — mais son tabouret libre est tourné vers toi.

Tu t'entends répondre à quelqu'un qui n'a pas parlé. Personne ne relève. C'est le pire.

Pendant une seconde, le sol sous tes pieds est de la terre retournée de frais.

Ils sont six, alignés, du même côté.

CHOIX : [Traverser sans offrir] [Troquer au Marché RUSE] [Demander s’il soigne le soir] [Montrer tes plaies EMPATHIE]
→ choix: Demander s’il soigne le soir

## [151] marche-muet-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_colporteur_b.png*

Le rebouteux hausse les épaules sans lever les yeux de son baume. « Je soigne pas la nuit. » Un temps. « C’est pas une règle, hein. C’est juste que personne demande. » Puis, comme on jette un os : « Et si c’est l’eau de la Mare que tu as bue, garde ta monnaie. Ça, ça se soigne pas ici. »

→ continue

## [155] marche-muet-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : scene_hameau_dense_c.png*

Le chemin longe une maison basse. Un volet se ferme — pas vite, pas peureusement. Posément. On ne se cache pas de toi : on te retire la maison, c'est différent.

D'un côté, des coups sourds sous des planches clouées. De l'autre, des silhouettes grises qui se déplacent ensemble.

Le vent dit un nom. Ce n'est pas le tien. Tu le retiens quand même.

CHOIX : [Vers des coups sourds] [Vers des silhouettes grises]
→ choix: Vers des silhouettes grises

## [158] meute-grise-1 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_meute_grise_c.png*

Derrière toi, très loin, des battements d'ailes quittent une traverse — exactement le compte que tu n'as pas voulu faire. Un battement de plus leur répond. Plus près.

• RENCONTRE •
La Meute Grise

Tu repasses le muret d'enceinte, et le village te lâche d'un coup — plus de toits, plus de volets, plus de regards. La lande reprend, immense, et le vent te retrouve comme s'il t'avait attendu.

→ continue

## [161] meute-grise-1 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_meute_grise_c.png*

La bruyère bouge sans vent, par plaques, autour de toi. Ce ne sont pas des ombres : ce sont des dos gris, bas sur pattes, qui resserrent un cercle patient.

Tu as longé le talus à contre-jour. Mauvais angle pour être reconnu, mauvais angle pour voir.

→ continue

## [164] meute-grise-1 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_meute_grise_c.png*

Loin de tout muret, la lande est à eux. Tu les vois de loin — et c'est mauvais signe : la Meute Grise ne se montre que quand l'encerclement est fini. Six silhouettes couleur de bruyère morte, immobiles aux six points d'un cercle dont tu es le centre.

Pas des chiens : trop patients. Pas des loups : trop organisés. La plus grande s'assoit — le signal. Le cercle se met à tourner, lentement, en se resserrant d'un pas par tour.

CHOIX : [Charger la plus grande COURAGE] [Gagner le muret INSTINCT] [Hurler le premier RUSE]
DÉ → RÉUSSITE ÉCLATANTE
→ lance le dé

## [174] meute-grise-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_meute_grise_c.png, etat_aguerri.png*

Aguerri
Le combat t'a affûté : tes gestes portent mieux, pour un temps.

Tu atteins le muret de justesse, une lanière de manteau en moins. Adossé à la pierre, tu ne peux plus être encerclé — juste attaqué de face, et ça, visiblement, ce n'est pas leur école. Le cercle se refait plus loin, faute de mieux.

• RENCONTRE •
La Meute Grise

Le cercle est rompu, mais la meute reste — regroupée à distance de lame, en croissant, plus prudente. Ils ont compris que tu mords aussi. Ça ne les décourage pas : ça les intéresse.

CHOIX : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps.]
→ continue

## [177] meute-grise-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_meute_grise_c.png, etat_aguerri.png*

Aguerri
Le combat t'a affûté : tes gestes portent mieux, pour un temps.

La meneuse s'avance seule d'un pas, tête basse, et te fixe. Chez eux, c'est une question. La dernière avant la charge — ou avant autre chose. À toi d'y répondre.

— « Tu comptes, toi aussi. » Personne autour de toi n'a ouvert la bouche.

CHOIX : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps.] [Jeter tes vivres RUSE] [Répondre par l'acier COURAGE] [Reculer, sans ciller INSTINCT]
DÉ → RÉUSSITE ÉCLATANTE
→ lance le dé

## [188] meute-grise-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : monstre_meute_grise_c.png*

Ta lame répond pour toi. La meneuse esquive l'essentiel, encaisse le reste, et rompt — le croissant entier reflue avec elle, réglé sur sa retraite. Ils reviendront peut-être. Pas aujourd'hui, et pas pour toi.

Il y a des traces fraîches sur ton chemin — devant toi. Quelqu'un fait ta route avant toi, dans le même sens, à petite distance. Tu ne le rattrapes jamais.

D'un côté, une masse trapue privée de ses ailes. De l'autre, un chemin qui s'enfonce entre deux talus.

→ continue

## [190] meute-grise-2 · Jour 3 · santé 0.94 · soupçon 3 · hante
*image : scene_landes_liaison_chemin_creux_a.png*

Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

CHOIX : [Vers un moulin sans ailes] [Vers le chemin creux]
→ choix: Vers le chemin creux

## [194] bete-chemins-creux · Jour 4 · santé 0.94 · soupçon 3 · hante
*image : monstre_bete_chemins_creux_a.png*

— JOUR 4 —

• RENCONTRE •
La Bête des Chemins Creux

Le sol se creuse sous tes pas, et le ciel se rétrécit à mesure que tu descends.

Tu as marché droit. Le lieu s'est ouvert devant toi bien avant que tu n'y sois.

Le creux tourne — et l'odeur arrive avant la chose : suint, terre retournée, vieux cuir. Une masse se décolle du talus, longue, basse, taillée pour courir exactement entre deux murs de terre.

→ continue

## [197] bete-chemins-creux · Jour 4 · santé 0.94 · soupçon 3 · hante
*image : monstre_bete_chemins_creux_a.png*

Pas de gueule visible. Juste une avancée du corps qui s'ouvre. La Bête ne chasse que dans le creux — c'est son couloir, son terrier, sa table. Et tu es dessus.

L'espace d'un pas, tes pieds ne touchent plus tout à fait le sol.

CHOIX : [Frapper la bête COURAGE] [Se plaquer, immobile] [Bondir hors du creux INSTINCT]
DÉ → RÉUSSITE ÉCLATANTE
→ lance le dé

## [207] chemin-creux · Jour 4 · santé 0.78 · soupçon 3 · hante,boiteux
*image : scene_chemin_creux_c.png, etat_boiteux.png, etat_entaille.png*

Boiteux
Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé.
Entaillé
La blessure ralentit chaque geste, tant qu'elle n'est pas soignée.

Ta lame racle du cuir sans entamer. L'avancée du corps te cueille à l'épaule et te plaque au talus — tu te dégages en y laissant du tien, et elle te laisse passer, servie.

Le chemin s'enfonce entre deux talus plus hauts que toi ; le ciel devient un ruban. C'est le plus court chemin des Landes, et le seul où l'on ne voit pas venir.

CHOIX : [Boiteux Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé.] [Entaillé La blessure ralentit chaque geste, tant qu'elle n'est pas soignée.]
DÉ → ÉCHEC
→ choix: Utiliser — Fiole d'eau de gouttière

## [225] chemin-creux-2 · Jour 4 · santé 1 · soupçon 3 · hante,boiteux
*image : scene_chemin_creux_coude_b.png*

Tu sors « Fiole d'eau de gouttière » de la Besace. Un peu de force te revient.

Un enfant t'observe depuis un talus, immobile. Quand tu lèves la main, il ne fuit pas : il trace quelque chose dans la terre du bout d'un bâton, sans te quitter des yeux, puis s'en va sans courir.

D'un côté, des rangées de piquets jusqu'à l'horizon. De l'autre, une masse trapue privée de ses ailes.

→ continue

## [227] chemin-creux-2 · Jour 4 · santé 1 · soupçon 3 · hante,boiteux
*image : scene_lande_generique_2.png*

Ici, on ne pend pas pour punir. On pend pour remplacer. Une corde tendue à temps, disent-ils, et personne d'autre n'est repris cette saison-là.

CHOIX : [Vers les rangées de poteaux] [Vers un moulin sans ailes]
→ choix: Vers les rangées de poteaux

## [231] champ-des-fixes · Jour 4 · santé 1 · soupçon 3 · hante,boiteux
*image : scene_champ_des_fixes_b.png*

L'horizon se hérisse de piquets réguliers, rangée après rangée, jusqu'à se perdre. Tu approches d'un champ qu'on n'a pas semé — on l'a planté d'hommes.

Tu n'as rien contourné. Tu arrives par la face, et rien ne t'a échappé en chemin.

Pas de tombes — des poteaux. Des rangées de poteaux plantés droit, un nom sur chaque, alignés face au nord. Dos au sud. Même morts, surtout morts, on ne les laisse pas regarder par là.

→ continue

## [234] champ-des-fixes · Jour 4 · santé 1 · soupçon 3 · hante,boiteux
*image : scene_champ_des_fixes_b.png*

Au fond, des poteaux vierges attendent, déjà plantés. Près de l'entrée, la cabane du Fossoyeur.

Le chemin monte, et tu comptes tes pas comme on compte de la monnaie.

CHOIX : [Les rangées et leurs noms] [Observer les alentours] [Rester dans le champ]
→ choix: Les rangées et leurs noms

## [239] champ-des-fixes · Jour 4 · santé 1 · soupçon 3 · hante,boiteux
*image : scene_champ_les_rangees_v2_a.png*

Tu marches entre deux rangs. Le sol est tassé par des allées et venues régulières — on entretient ce champ comme un jardin, et c'est ça qui serre le ventre.

Les noms des premières rangées sont presque effacés. Les dernières sont fraîches. Entre les deux, une rangée entière porte la même date — un seul jour, neuf fixations. Il y a une histoire là-dedans que personne ne raconte.

→ continue

## [241] champ-des-fixes · Jour 4 · santé 1 · soupçon 3 · hante,boiteux
*image : scene_champ_les_rangees_v2_a.png*

Il grince les nuits sans vent. Ceux qui l'ont entendu ne montent plus sur la crête après le crépuscule — non par peur du bruit, mais parce que le bruit veut dire que la corde bouge, et que rien ne la touche.

CHOIX : [Les poteaux vierges, au fond] [Un vide dans une rangée pleine] [Rester dans le champ]
→ choix: Rester dans le champ

## [244] champ-des-fixes-2 · Jour 4 · santé 1 · soupçon 3 · hante,boiteux
*image : monstre_fossoyeur_poteaux_a.png*

Entre les rangs, un vieil homme redresse un poteau qui penche, avec des gestes de jardinier. Il t'a vu venir de loin — les vivants font un bruit particulier, ici. Il ne s'interrompt pas : il t'attend au travail, comme on attend un outil. « La Colline, c'est la vitrine », dit-il sans qu'on demande. « Ici, c'est l'arrière-boutique. »

Tu portes la main à ton cou. Il n'y a rien. Tu l'y portes quand même.

CHOIX : [Aider à redresser EMPATHIE] [Passer sans un mot]
DÉ → RÉUSSITE
→ lance le dé

## [256] champ-des-fixes-2 · Jour 5 · santé 0.7 · soupçon 4 · hante,boiteux
*image : monstre_fossoyeur_poteaux_a.png*

Ébranlé
Le choc te suit : tes gestes hésitent, pour un temps.

Le poteau tombe. Le pendu, lui, reste debout.

— JOUR 5 —

La lande t'a pris un jour. La lumière a tourné sans que tu avances.

Les rangées de poteaux s'espacent, puis renoncent. Tu comptes tes pas pour ne pas compter les écriteaux. La lande reprend, vide — enfin, vide comme avant : surveillée.

D'un côté, une masse trapue privée de ses ailes. De l'autre, un gibet bas, à hauteur d'homme, qui bouge sans vent.

CHOIX : [Ébranlé Le choc te suit : tes gestes hésitent, pour un temps.]
→ continue

## [259] champ-des-fixes-2 · Jour 5 · santé 0.7 · soupçon 4 · hante,boiteux
*image : scene_landes_liaison_fourche_a.png, geolier_portrait.png*

Ébranlé
Le choc te suit : tes gestes hésitent, pour un temps.

Tu comptes ce qui t'entoure — les ombres, les pierres. Il y en a toujours une de plus au deuxième compte.

1. Le dé lui-même a eu pitié — puis non.

CHOIX : [Ébranlé Le choc te suit : tes gestes hésitent, pour un temps.] [Vers un moulin sans ailes] [Vers un gibet qui parle]
→ choix: Vers un gibet qui parle

## [263] pendu-qui-parle · Jour 5 · santé 0.7 · soupçon 4 · hante,boiteux
*image : monstre_pendu_qui_parle_a.png*

Tu contournes la crête. Ce que tu prenais pour un épouvantail tourne la tête.

Tu es venu par le flanc, le nez au sol. Personne ne t'a vu. Toi non plus.

Au revers de la colline, un gibet bas, à hauteur d'homme. Le pendu qui s'y balance ouvre les yeux à ton approche. Chaîne de fonction au cou, sous la corde. Un sceau au poing. Le Bailli des Landes — pendu le dernier, à la place d'honneur.

CHOIX : [Détailler le sceau à son poing] [Le jauger sans approcher INSTINCT] [S'approcher du gibet bas]
→ choix: S'approcher du gibet bas

## [266] pendu-qui-parle-2 · Jour 5 · santé 0.7 · soupçon 4 · hante,boiteux
*image : monstre_pendu_qui_parle_2_a.png, geolier_portrait.png*

« Approche », dit-il, et la corde grince sur chaque syllabe. « Tout ce qui entre dans mes Landes passe en jugement. Toi aussi. » Il sourit. « Surtout toi. »

Il attend toujours son accusé. Trente ans qu'il l'attend. Voilà ce que ça donne, la rigueur.

CHOIX : [Répondre à son jugement EMPATHIE] [Passer sans un mot] [Lui demander combien il en a signé] [Trancher sa corde COURAGE]
→ choix: Lui demander combien il en a signé

## [269] hameau-halte-1 · Jour 5 · santé 0.7 · soupçon 4 · hante,boiteux,fixe
*image : scene_landes_hameau_ruelle_b.png, etat_fixe.png*

Fixé
On ne te parle plus tout à fait à toi. On parle devant toi, de toi, à voix normale, comme on parle devant un poteau déjà planté.

La corde s'immobilise. Pour la première fois depuis que tu es là, il ne joue plus au juge. « J'ai signé trois cents noms. » Un temps très long, à hauteur de gibet. « Le trois cent unième était le sien. C'est celui-là qui m'a paru injuste. » Puis, plus bas, comme un point de procédure : « Alors j'ai inscrit le mien en dessous. »

Le vieux te trouve avant que tu ne le cherches. C'est comme ça, ici : on sait toujours où tu es.

CHOIX : [Fixé On ne te parle plus tout à fait à toi. On parle devant toi, de toi, à voix normale, comme on parle devant un poteau déjà planté.]
→ choix: Examiner la grange

## [287] hameau-halte-2 · Jour 5 · santé 0.7 · soupçon 4 · hante,boiteux,fixe
*image : scene_hameau_grange_poutres_a_d.png*

Tu prends la lampe et tu fais le tour, lentement, en te tenant loin des murs — le vieux réflexe de qui ne veut pas être une silhouette derrière des planches.

→ continue

## [289] hameau-halte-2 · Jour 5 · santé 0.7 · soupçon 4 · hante,boiteux,fixe
*image : scene_hameau_grange_poutres_a_d.png*

Des marques sur les poutres, à hauteur d'homme. Des bâtons de comptage — des séries de nuits. Quelqu'un a dormi ici souvent. Ou plusieurs quelqu'uns, une nuit chacun. La dernière série s'arrête à deux. Et sous chaque bâton, une encoche plus petite, régulière : quatre par nuit, toujours quatre. Ce ne sont pas les nuits qu'on compte ici. Ce sont les passages de la ronde. En sortant, tu passes la main sur la barre : le bois est lisse à l'intérieur et usé jusqu'au fil dehors, comme si l'on s'y appuyait du dehors, souvent, longtemps.

CHOIX : [Veiller INSTINCT] [Dormir]
DÉ → MALÉDICTION
→ lance le dé


Erreurs JS : 0 · HTTP≥400 : 0