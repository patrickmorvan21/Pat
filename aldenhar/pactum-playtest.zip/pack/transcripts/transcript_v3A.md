# PACTUM — transcript de partie réelle (v3A)

Profil : vie CURIEUSE (examine tout, compte neuf). Partie jouée automatiquement
sur le build publié (v1.51.1), dés lancés par la vraie physique.
Fin de la partie : budget épuisé (260 actions).

Chaque bloc = un écran tel qu'affiché au joueur. `> action` = ce que
le testeur a fait. Les boutons entre crochets sont les choix offerts.

---

## Écran 1

Tu choisis. Le dé décide. Lui, il regarde. COMMENCER OPTIONS v1.51.1

Choix affichés : [COMMENCER] · [OPTIONS]

## Écran 2

Tu ne te souviens pas D'être entré, je veux dire. Personne ne s'en souvient. Tu es mort. Il y a peu. Ce qui suit est une proposition. Personne ne l'a jamais refusée. Touche pour commencer

## Écran 3

Une seule vie Tu traverses mon Domaine. Une fois. Au bout, une Porte scellée : franchis-la, et tu reprends ta vie là où tu l'as laissée. Si tu meurs, un autre viendra. Avec un autre nom.

## Écran 4

Le dé tranche Ton adresse ne te sauvera pas. Courage, ruse, instinct, empathie : ce que tu vaux vient de ce que tu étais de ton vivant. Touche pour continuer

## Écran 5

Ta mort me sert Ta fin est forgée en Relique. Celui qui te suivra la portera. On ne progresse pas ici en survivant. En tombant mieux.

## Écran 6 · Jour 1

Avant que tu passes, je veux voir qui tu étais. Touche pour continuer

## Écran 7 · Jour 1

Ne réfléchis pas. Ce n'est plus toi qui choisis, ici — c'est ce que tu as déjà fait. Touche pour continuer

## Écran 8 · Jour 1

Trois hommes en frappent un seul, dans une ruelle sombre. Intervenir, quitte à en prendre Crier pour faire fuir les agresseurs Presser le pas, ailleurs

Choix affichés : [Intervenir, quitte à en prendre] · [Crier pour faire fuir les agresseurs] · [Presser le pas, ailleurs]

> choisit : « Presser le pas, ailleurs »

## Écran 9 · Jour 1

Un mur sonne creux, dans une pièce que tu ne devrais pas fouiller. Chercher le mécanisme caché Repartir, ce n'est pas le moment Forcer le mur directement

Choix affichés : [Chercher le mécanisme caché] · [Repartir, ce n'est pas le moment] · [Forcer le mur directement]

> choisit : « Chercher le mécanisme caché »

## Écran 10 · Jour 1

L'air se glace d'un coup, sans nuage ni vent pour l'expliquer. Te mettre à l'abri immédiatement Attendre, observer ce qui vient Continuer, en te couvrant à peine

Choix affichés : [Te mettre à l'abri immédiatement] · [Attendre, observer ce qui vient] · [Continuer, en te couvrant à peine]

> choisit : « Attendre, observer ce qui vient »

## Écran 11 · Jour 1

Un enfant vole du pain, se fait attraper, tremble devant le châtiment qui vient. Payer le pain, plaider sa cause Demander une punition plus douce Laisser faire justice

Choix affichés : [Payer le pain, plaider sa cause] · [Demander une punition plus douce] · [Laisser faire justice]

> choisit : « Demander une punition plus douce »

## Écran 12 · Jour 1

Une dernière chose. J'ai vu qui tu étais. Il me manque comment on t'appelait. SCELLER LE PACTE Qu'il choisisse pour moi

Choix affichés : [SCELLER LE PACTE] · [Qu'il choisisse pour moi]

## Écran 13 · Jour 1

Tu regardes les serrures avant les portes. Il y a toujours un autre chemin, et tu le sais. Mais les autres restent pour toi un bruit de fond. Ça t'a coûté. Ça te coûtera encore. Je sais qui tu es. Le dé, lui, décidera qui tu deviens. Touche pour commencer

## Écran 14 · Jour 1

• LE DOMAINE • Les Lisières Touche pour continuer

## Écran 15 · Jour 1

— JOUR 1 — La lande s'ouvre sous un crépuscule qui ne tombe pas. La lumière reste prise entre chien et loup, comme un souffle retenu. Quelque part, une corde grince. La pierre est seule au milieu du plateau, dressée là où tous les murets renoncent. Haute comme un homme, grise comme le reste — et pourtant l'œil ne voit qu'elle. À son pied, un tas d'offrandes. Au-delà, le sud, nu. Et à trois pas de la borne, un homme immobile, face au sud. À partir de maintenant, il décide avec moi.

Choix affichés : [Observer les alentours] · [Fouiller les offrandes RUSE] · [Répondre aux voix EMPATHIE [verrouillé]]

> choisit : « Observer les alentours »

> choisit : « Les gravures de la pierre »

## Écran 16 · Jour 1

Tu fais le tour de la pierre lentement, la main à plat sur le granit. Il est froid d'une froideur qui ne vient pas du vent. Des marques sur toutes les faces, de toutes les mains, de toutes les époques : des noms, des dates, des traits de comptage. Le côté nord est saturé — les adieux de ceux qui partaient. Le côté sud est presque vierge. Trois marques seulement. On ne grave pas au retour quand personne ne revient. Alors qui a gravé côté sud ?

## Écran 17 · Jour 1

Le bois du grand gibet ne vient pas des Landes. Il n'y pousse rien d'assez droit ni d'assez épais. On l'a fait monter de loin, par charrette, en plusieurs voyages — un chantier, pas un accès de colère.

Choix affichés : [Observer les alentours] · [Fouiller les offrandes RUSE] · [Répondre aux voix EMPATHIE [verrouillé]]

> choisit : « Fouiller les offrandes RUSE »

## Écran 18 · Jour 1

Tes doigts trient sans déranger. Un clou tordu, une mèche de cheveux — et le sens de tout ça : on n'offre pas par foi, ici. On offre par peur. Bon à savoir. OBTENU — OFFRANDES DE LA BORNE · COMMUN Pain durci, rubans, clous tordus. On les a laissés pour entrer. Tu les prends pour tenir. Où que le chemin tourne, la couronne de la colline reste en vue — et le grand gibet dépasse, patient. Tu commences à comprendre : ce n'est pas toi qui le regardes. Deux directions s'ouvrent. D'un côté, une crête hérissée de mâts noirs. De l'autre, des toits bas et une fumée qui ne monte pas droit.

## Écran 19 · Jour 1

À l'horizon, la colline porte sa couronne de potences. L'une dépasse toutes les autres — de beaucoup trop. Aucun homme n'a jamais eu cette taille. Et c'est la seule dont la corde pend, vide.

Choix affichés : [Vers la crête aux cordes] · [Vers la fumée d'un hameau]

> choisit : « Vers la crête aux cordes »

## Écran 20 · Jour 1

Tu montes. Les mâts deviennent des potences. Tu es passé sous le vent. Rien ne s'est retourné, et tu n'as regardé que tes pieds. La pente est douce et n'en finit pas — la Colline se mérite à pas comptés. Au sommet, le cercle : neuf potences ordinaires, plantées comme les heures d'un cadran. Et au centre, l'autre. La grande. Sa corde est la seule chose neuve à dix lieues. À gauche du cercle, un poteau isolé porte encore son occupant. À droite, les potences vides alignent leurs noms gravés.

## Écran 21 · Jour 1

Les potences n'ont pas le même âge. Le cercle a été complété — on a ajouté des places. De près, le grand gibet est pire : taillé large, chevillé double, dimensionné pour un cou qui n'est pas un cou d'homme. Celui qui l'a bâti savait exactement quelle taille il visait. Sa corde est usée en son milieu — pas au nœud, au MILIEU. Comme si quelque chose l'avait éprouvée de l'intérieur, longtemps, sans jamais s'y laisser prendre. Juste à côté, un gibet bas, à hauteur d'homme. Occupé, lui.

## Écran 22 · Jour 1

Les corbeaux tiennent mes comptes locaux. Bénévoles, en plus.

Choix affichés : [Le pied du grand gibet] · [Observer les alentours] · [Rester au sommet]

> choisit : « Le pied du grand gibet »

## Écran 23 · Jour 1

Tu quittes la ligne des potences ordinaires pour celle qui les dépasse toutes. De près, elle est absurde : trois fois trop haute pour un homme, et sa corde est neuve. Au pied du mât, dans le bois, un nom a été gravé profond, à la gouge, par quelqu’un qui prenait son temps. Il est illisible — pas effacé par la pluie : GRATTÉ, en travers, par quelque chose qui a mordu le bois plus fort que l’outil. Dessous, une date est restée entière. Elle est vieille de trente ans.

Choix affichés : [Les corbeaux, sur la traverse] · [Observer les alentours] · [Rester au sommet]

> choisit : « Les corbeaux, sur la traverse »

## Écran 24 · Jour 1

Ils sont sur la traverse du grand gibet, immobiles, et ils ne bougent pas quand tu approches — ce qui n'est pas un comportement d'oiseau. Aucun ne te regarde. Ils regardent la corde.

## Écran 25 · Jour 1

Ils ne mangent pas. Il n'y a rien à manger ici depuis longtemps, et leurs becs sont propres. Ils attendent, et ils sont exactement assez nombreux pour ce qu'ils attendent. Ce sont les mêmes que sur les toits du hameau : la même immobilité, la même façon d'être tournés du même côté. En bas, ils comptent quelque chose qui te concerne. Ici aussi — mais pas la même chose.

## Écran 26 · Jour 1

Il n'y en a qu'un, et il se tient de travers, comme s'il gardait une place. Tu ne sais pas pour qui.

Choix affichés : [Les potences du cercle] · [Observer les alentours] · [Rester au sommet]

> choisit : « Rester au sommet »

## Écran 27 · Jour 1

Hanté Ce que tu as vu ne s'est pas rangé. Ça reste posé de travers dans ta tête, et ça bouge quand tu ne le regardes pas. Le vent tombe d'un coup, comme on ferme une porte. Et dans ce calme plat, les neuf cordes du cercle se mettent à bouger. Pas au hasard : ensemble. Un balancement lent, réglé, qui va et vient sur le même temps. Ça grince en mesure. Neuf cordes, un seul rythme. Tu comprends, avec un retard qui te coûte, que ce rythme ne t'est pas indifférent — tu pourrais le compter. Quelque chose grince très haut, très loin, à une hauteur où il n'y a rien.

Choix affichés : [Hanté Ce que tu as vu ne s'est pas rangé. Ça reste posé de t] · [Partir avant de comprendre] · [Rester et compter INSTINCT] · [Arracher une écharde COURAGE]

> choisit : « Rester et compter INSTINCT »

## Écran 28 · Jour 1

Tu comptes. Le nombre est petit, et c'est le pire : les cordes ne battent pas les morts de la lande. Elles battent les tiennes. Le compte est juste. Tu redescends sans le dire à voix haute. Sur une pierre du chemin, une croix à la craie — vieille, à moitié lavée. Pas la tienne. Quelqu'un d'autre, avant toi, a entendu quelque chose. Tu ne sauras pas où il pend.

Choix affichés : [Ne plus afficher]

## Écran 29 · Jour 1

D'un côté, un chemin qui s'enfonce entre deux talus. De l'autre, une palissade qui coupe l'horizon, une lanterne allumée en plein jour. Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Choix affichés : [Vers le chemin creux] · [Vers une palissade au sud] · [Ne plus afficher]

> choisit : « Vers le chemin creux »

## Écran 30 · Jour 2

— JOUR 2 — • RENCONTRE • La Bête des Chemins Creux Le sol se creuse sous tes pas, et le ciel se rétrécit à mesure que tu descends. Tu es entré par où tout le monde entre. Ça se remarque, et ça permet de voir venir. Le creux tourne — et l'odeur arrive avant la chose : suint, terre retournée, vieux cuir. Une masse se décolle du talus, longue, basse, taillée pour courir exactement entre deux murs de terre.

Choix affichés : [Ne plus afficher]

## Écran 31 · Jour 2

Pas de gueule visible. Juste une avancée du corps qui s'ouvre. La Bête ne chasse que dans le creux — c'est son couloir, son terrier, sa table. Et tu es dessus.

Choix affichés : [Frapper la bête COURAGE] · [Se plaquer, immobile] · [Bondir hors du creux INSTINCT] · [Ne plus afficher]

> choisit : « Bondir hors du creux INSTINCT »

## Écran 32 · Jour 2

Boiteux Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé. Entaillé La blessure ralentit chaque geste, tant qu'elle n'est pas soignée. Le talus s'éboule sous ta prise. Tu retombes dans le creux, à demi — et la Bête prend sa part de la jambe qui traînait encore. Le chemin s'enfonce entre deux talus plus hauts que toi ; le ciel devient un ruban. C'est le plus court chemin des Landes, et le seul où l'on ne voit pas venir.

Choix affichés : [Boiteux Le genou ne plie plus tout à fait. Tu peux marcher —] · [Entaillé La blessure ralentit chaque geste, tant qu'elle n'e] · [Ne plus afficher]

> choisit : « La charrette embourbée »

## Écran 33 · Jour 2

Elle penche dans l'ornière depuis si longtemps que le bois a pris racine — des pousses sortent du moyeu. Tu contournes, la main sur le ridelle. Le chargement a disparu depuis longtemps. Le cheval aussi : le harnais pend, coupé net, pas dénoué. Sous le siège, accroché à un clou, un grelot de cuivre vert-de-grisé. Il ne sonne pas quand tu le décroches. Il sonnera quand il faudra. OBTENU — GRELOT DU CHARRETIER · COMMUN Il tinte quand quelque chose approche dans le creux. Rien ne te tombera plus dessus sans s'annoncer.

Choix affichés : [Le haut des talus] · [L'homme qui marche à reculons] · [Couper par la lande INSTINCT] · [Utiliser — Offrandes de la Borne] · [Ne plus afficher]

> choisit : « Le haut des talus »

## Écran 34 · Jour 2

Tu montes de trois pas dans la pente, juste assez pour voir la crête sans t'exposer entièrement. La terre y est meuble, retournée. Des empreintes. Parallèles au chemin. Sur toute sa longueur — mais sur la crête NORD seulement : l'autre versant est intact, pas une marque. Quelque chose marche là-haut quand quelqu'un marche en bas, à la même vitesse, du même pas, et toujours du même côté. Tu redescends sans te presser, parce que se presser serait une information.

Choix affichés : [L'homme qui marche à reculons] · [Couper par la lande INSTINCT] · [Utiliser — Offrandes de la Borne] · [Ne plus afficher]

> choisit : « Couper par la lande INSTINCT »

## Écran 35 · Jour 2

Boiteux Le genou ne plie plus tout à fait. Tu peux marcher — tu ne peux plus courir, et tu le sais avant d'avoir essayé. Entaillé La blessure ralentit chaque geste, tant qu'elle n'est pas soignée. Tu grimpes le talus et marches à découvert. La lande te voit — mais rien ne te suit. Le chemin creux, en dessous, continue sans toi. Le chemin tourne, et le talus mange la vue d'un coup. Passé le coude : rien. C'est-à-dire l'endroit exact où il devrait y avoir quelque chose, et il n'y a rien. Le silence y est plus épais d'un cran, comme après un bruit que tu aurais raté d'une seconde.

Choix affichés : [Boiteux Le genou ne plie plus tout à fait. Tu peux marcher —] · [Entaillé La blessure ralentit chaque geste, tant qu'elle n'e] · [Longer le côté sud] · [Franchir le coude INSTINCT] · [Sortir par le talus] · [Utiliser — Offrandes de la Borne] · [Ne plus afficher]

> choisit : « Utiliser — Offrandes de la Borne »

## Écran 36 · Jour 2

Tu sors « Offrandes de la Borne » de la Besace. Un peu de force te revient. Un berger sans troupeau te croise au détour d'un talus. Il te salue — du menton, pas de la voix — et presse le pas une fois passé. Tu l'entends s'arrêter, plus loin, pour te regarder partir. D'un côté, des toits bas et une fumée qui ne monte pas droit. De l'autre, une masse trapue privée de ses ailes.

Choix affichés : [Ne plus afficher]

## Écran 37 · Jour 2

— « Tu comptes, toi aussi. » Personne autour de toi n'a ouvert la bouche.

Choix affichés : [Vers la fumée d'un hameau] · [Vers un moulin sans ailes] · [Ne plus afficher]

> choisit : « Vers la fumée d'un hameau »

## Écran 38 · Jour 2

De la fumée basse, pas une flamme : des toits gris tassés derrière leurs murets. Le Hameau des Renonçants se découvre lentement, et déjà tu sens qu'on t'a vu venir de loin. Tu as pris la route droite. On t'a vu venir — et tu as eu le temps de tout regarder. Les toits apparaissent au creux du plateau — de l'ardoise affaissée, des murs qui tiennent par habitude. Une seule cheminée fume, sur une vingtaine. Tu es encore loin quand tu comprends ce qui cloche : aucun chien n'aboie.

Choix affichés : [Ne plus afficher]

## Écran 39 · Jour 2

Un corbeau sur le faîtage. Les rares mots qu'on t'adresse ont raccourci. On te répond sec, sans te regarder — pas de l'hostilité. De l'économie. OBTENU — FIOLE D'EAU DE GOUTTIÈRE · COMMUN Trouble, tiède — mais elle apaise.

Choix affichés : [Observer d'abord, à couvert INSTINCT] · [Descendre vers le hameau] · [Utiliser — Fiole d'eau de gouttière] · [Ne plus afficher]

> choisit : « Observer d'abord, à couvert INSTINCT »

## Écran 40 · Jour 2

À couvert derrière un muret, tu prends la mesure du village : onze maisons vivantes sur vingt, et pas un mouvement dehors. Ce n'est pas un hameau qui dort. C'est un hameau qui attend. La première maison est à dix pas. Sur sa porte, un signe à la craie — une croix, simple, tracée à hauteur d'œil. La poudre blanche est encore sur le seuil. Ça date de ce matin. Pendant une seconde, le sol sous tes pieds est de la terre retournée de frais. Un corbeau sur le faîtage.

Choix affichés : [Ne plus afficher]

## Écran 41 · Jour 2

Une conversation s'éteint à ton approche. Pas interrompue : pliée, rangée, comme du linge qu'on rentre avant la pluie. OBTENU — ONGUENT GRIS · COMMUN L'étiquette est illisible. L'odeur, convaincante.

Choix affichés : [Le linteau de la porte] · [Observer les alentours] · [Continuer dans la rue] · [Utiliser — Fiole d'eau de gouttière] · [Ne plus afficher]

> choisit : « Utiliser — Fiole d'eau de gouttière »

## Écran 42 · Jour 2

Tu sors « Fiole d'eau de gouttière » de la Besace. Un peu de force te revient. Tu entres dans la rue au moment où un homme se met à courir. Pas vers toi : vers la chapelle, vers la corde qui pend le long du mur. Une vieille femme l'atteint avant lui. Elle ne crie pas, elle ne le retient pas — elle pose la main sur la corde, c'est tout, et l'homme s'arrête net comme s'il se réveillait.

Choix affichés : [Ne plus afficher]

## Écran 43 · Jour 2

Le village sort quand même. Une dizaine, sur les seuils, pour un tocsin qui n'a pas sonné. Et c'est toi qu'ils regardent : tu as failli les faire sonner. Une ombre passe à ta gauche, à la vitesse d'un homme qui marche. Quand tu regardes, rien ne marche nulle part. Un corbeau sur le faîtage. OBTENU — BAUME DE MOUSSE NOIRE · COMMUN Ça sent la cave. Ça referme les plaies.

Choix affichés : [Demander qui répondrait INSTINCT] · [T'excuser d'être arrivé] · [Tirer la corde toi-même COURAGE] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « Demander qui répondrait INSTINCT »

## Écran 44 · Jour 2

Tu demandes trop vite. La vieille resserre la main sur la corde et te regarde comme on regarde quelqu'un qui a demandé le prix d'une chose qui ne se vend pas. « On ne parle pas de ça dehors. » Au bout de la rue, un muret bas ferme le village côté sud. Le vieux y est assis, sec comme un piquet, les coudes sur les genoux. Il t'attendait là depuis le début.

Choix affichés : [Ne plus afficher]

## Écran 45 · Jour 2

Il tend la main, paume ouverte. Pas pour serrer la tienne — pour que tu la regardes. Elle est vide. C'est le geste d'ici : on jure sur rien, parce qu'il ne reste rien. — « Trois choses, et tu dors sous un toit. Tu ne parles pas aux pendus. Tu ne regardes pas le sud plus qu'il ne faut. Et à la troisième aube, tu choisis. » Tu portes la main à ton cou. Il n'y a rien. Tu l'y portes quand même. Un corbeau sur le faîtage.

Choix affichés : [Observer les alentours] · [Refuser de jurer] · [Jurer] · [Jurer du bout des lèvres] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « Jurer »

## Écran 46 · Jour 2

Fixé On ne te parle plus tout à fait à toi. On parle devant toi, de toi, à voix normale, comme on parle devant un poteau déjà planté. Tu refuses. Personne ne crie. Le vieux referme lentement sa paume vide, et c'est tout. « Personne n'est chassé », répète-t-il — et cette fois tu entends ce que ça veut dire vraiment : on ne te chassera pas, on te laissera dehors. Aucune porte ne s'ouvrira. Aucun toit. Et le hameau te regardera vivre. Ils s'écartent. Pas beaucoup — juste assez pour que tu passes sans toucher personne, et tu comprends que c'est calculé.

Choix affichés : [Fixé On ne te parle plus tout à fait à toi. On parle devant ] · [Ne plus afficher]

> choisit : « Entrer dans le hameau »

## Écran 47 · Jour 2

Au loin, une cloche muette sonne quand même — trois coups mats, du bois sur du bois. Tu comprends que ça compte tes passages. Quelqu'un, quelque part, tient le total. D'un côté, une eau noire où les roseaux ne bougent pas. De l'autre, des rangées de piquets jusqu'à l'horizon.

Choix affichés : [Vers une eau qui ne bouge pas] · [Vers les rangées de poteaux] · [Ne plus afficher]

> choisit : « Vers les rangées de poteaux »

## Écran 48 · Jour 2

Les dernières maisons s'espacent, puis renoncent. Devant toi la bruyère morte reprend ses droits jusqu'à l'horizon. Dans ton dos, quelqu'un referme une porte, sans se presser. L'horizon se hérisse de piquets réguliers, rangée après rangée, jusqu'à se perdre. Tu approches d'un champ qu'on n'a pas semé — on l'a planté d'hommes. Tu n'as rien contourné. Tu arrives par la face, et rien ne t'a échappé en chemin.

Choix affichés : [Ne plus afficher]

## Écran 49 · Jour 2

Pas de tombes — des poteaux. Des rangées de poteaux plantés droit, un nom sur chaque, alignés face au nord. Dos au sud. Même morts, surtout morts, on ne les laisse pas regarder par là. Au fond, des poteaux vierges attendent, déjà plantés. Près de l'entrée, la cabane du Fossoyeur. Les poteaux vierges sont plantés d'avance, en rang. On prépare les places avant d'avoir les noms.

Choix affichés : [Les rangées et leurs noms] · [Observer les alentours] · [Rester dans le champ] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « Rester dans le champ »

## Écran 50 · Jour 2

Entre les rangs, un vieil homme redresse un poteau qui penche, avec des gestes de jardinier. Il t'a vu venir de loin — les vivants font un bruit particulier, ici. Il ne s'interrompt pas : il t'attend au travail, comme on attend un outil. Tu comptes ce qui t'entoure — les ombres, les pierres. Il y en a toujours une de plus au deuxième compte.

Choix affichés : [Écouter ce qu'on te dit maintenant] · [Passer sans un mot] · [Déchiffrer le carnet RUSE] · [Demander ce qui vient, la nuit] · [Aider à redresser EMPATHIE] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « Écouter ce qu'on te dit maintenant »

## Écran 51 · Jour 2

Le Fossoyeur ne te parle pas comme aux autres. Il parle comme on parle à quelqu'un qui a déjà son poteau quelque part. « Le troisième rang, on le plante jamais. C'est pas de la place perdue : c'est de la place gardée. » Il ne dit pas pour qui. Il y a des traces fraîches sur ton chemin — devant toi. Quelqu'un fait ta route avant toi, dans le même sens, à petite distance. Tu ne le rattrapes jamais.

Choix affichés : [Ne plus afficher]

## Écran 52 · Jour 2

D'un côté, une masse trapue privée de ses ailes. De l'autre, des bâches tendues et pas une voix. Le grand gibet de la Colline n'a jamais servi. Il n'attend pas n'importe qui : il est taillé pour un cou précis, et tant qu'il reste vide, quelque chose d'autre reste occupé.

Choix affichés : [Vers un moulin sans ailes] · [Vers un marché muet] · [Ne plus afficher]

> choisit : « Vers un marché muet »

## Écran 53 · Jour 3

— JOUR 3 — Les murets se resserrent, et la bruyère cède aux ornières. Te voilà de retour entre les toits du hameau — la barrière est ouverte, et personne ne fait mine de te compter. Ce qui veut dire qu'on a déjà fini. Un bourdonnement de foule sans une seule voix te parvient — des dizaines de gens qui s'affairent en silence. Tu entres dans le marché muet du hameau. Tu es venu par le flanc, le nez au sol. Personne ne t'a vu. Toi non plus.

Choix affichés : [Ne plus afficher]

## Écran 54 · Jour 3

Au cœur du hameau, un marché sans un cri. Des étals de trois fois rien — clous, laine, racines — et des marchands qui négocient par gestes, paumes et hochements. Renoncer à la parole est le renoncement le plus courant. Le moins cher. Personne ne parle, mais tout le monde compte. Les doigts bougent sous les manches. Ils sont six, alignés, du même côté.

Choix affichés : [Saluer à leur manière RUSE] · [Longer les étals] · [Observer un troc] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « Observer un troc »

## Écran 55 · Jour 3

Deux paumes ouvertes, un hochement, trois doigts — refus. Deux doigts — accord. Le marchandage muet a sa grammaire, et tu en apprends l'essentiel en un échange : ici, montrer ses mains vaut passeport. Les cacher vaut aveu. Au bout de la rangée, un étal différent : bric-à-brac d'ailleurs, objets qui n'ont rien à faire dans une lande. Le Colporteur te regarde venir de loin — et te reconnaît. C'est impossible. Il te fait signe quand même, comme à un client de longue date.

Choix affichés : [Ne plus afficher]

## Écran 56 · Jour 3

Ils sont six, alignés, du même côté.

Choix affichés : [Demander s’il soigne le soir] · [Troquer au Marché RUSE] · [Montrer tes plaies EMPATHIE] · [Traverser sans offrir] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « Demander s’il soigne le soir »

## Écran 57 · Jour 3

Le rebouteux hausse les épaules sans lever les yeux de son baume. « Je soigne pas la nuit. » Un temps. « C’est pas une règle, hein. C’est juste que personne demande. » Un gamin marche à ta hauteur, de l'autre côté du muret, sans te regarder. Il s'arrête quand tu t'arrêtes. À l'angle, il tourne avant toi et va dire quelque chose à quelqu'un que tu ne vois pas. D'un côté, un craquement de bois, régulier, qui travaille. De l'autre, un clocher court d'où pendent des filins.

Choix affichés : [Ne plus afficher]

## Écran 58 · Jour 3

L'espace d'un pas, tes pieds ne touchent plus tout à fait le sol.

Choix affichés : [Vers un craquement de bois] · [Vers une chapelle de cordes] · [Ne plus afficher]

> choisit : « Vers un craquement de bois »

## Écran 59 · Jour 3

• RENCONTRE • Le Pendu Mal Fixé Les dernières maisons s'espacent, puis renoncent. Devant toi la bruyère morte reprend ses droits jusqu'à l'horizon. Dans ton dos, quelqu'un referme une porte, sans se presser. Un craquement rythme ta marche, régulier, mécanique — du bois qui travaille sous un poids. Devant, une corde trop lâche laisse glisser ce qu'elle devait tenir. Tu as marché droit. Le lieu s'est ouvert devant toi bien avant que tu n'y sois.

Choix affichés : [Ne plus afficher]

## Écran 60 · Jour 3

Un craquement sec dans les rangs — un poteau vient de casser. Le pendu qui le quittait touche terre sur ses pieds, comme s'il n'attendait que ça depuis des années. Sa corde traîne derrière lui, encore nouée au cou. Il avance par à-coups, tiré par des ficelles que personne ne tient. Une Fixation ratée : ni mort ni tenu. Ce qui reste de son visage n'exprime qu'une chose — l'envie féroce d'échanger sa place. Contre la tienne.

Choix affichés : [L'emmêler dans sa corde RUSE] · [Le repousser au poteau COURAGE] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « Le repousser au poteau COURAGE »

## Écran 61 · Jour 3

Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps. Tu le repousses, pas à pas, jusqu'aux rangs. Au contact du bois cassé, ses jambes cèdent : la Fixation le reprend à moitié. Assez pour qu'il ne te suive plus. Il te regarde partir avec une envie terrible. Des bêtes broutent la bruyère morte au creux du vallon — un troupeau entier, sans personne. Elles ne s’écartent pas quand tu approches : elles lèvent la tête, te regardent une seconde, et se remettent à brouter. C’est ce détail qui te dérange le plus. Elles n’ont pas appris à se méfier.

Choix affichés : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pou] · [Les marques d’oreille] · [S’avancer dans le vallon] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « S’avancer dans le vallon »

## Écran 62 · Jour 3

Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps. Une brebis s’écarte du groupe et marche droit vers le nord-est, s’arrête, revient. Puis recommence. Cinq fois pendant que tu la regardes. Elle refait un trajet. Elle attend au bout de quelque chose qui n’arrive plus. Dans cette direction, à un quart d’heure de marche, il y a le Champ des Fixés.

Choix affichés : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pou] · [Continuer ton chemin] · [Utiliser — Onguent gris] · [Ne plus afficher]

> choisit : « Utiliser — Onguent gris »

## Écran 63 · Jour 3

Tu sors « Onguent gris » de la Besace. Un peu de force te revient. Un enfant t'observe depuis un talus, immobile. Quand tu lèves la main, il ne fuit pas : il trace quelque chose dans la terre du bout d'un bâton, sans te quitter des yeux, puis s'en va sans courir. D'un côté, une porte basse et trois bancs qu'on devine. De l'autre, une masse trapue privée de ses ailes. Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Choix affichés : [Vers une salle de juges] · [Vers un moulin sans ailes] · [Ne plus afficher]

> choisit : « Vers une salle de juges »

## Écran 64 · Jour 3

Le chemin redescend vers les toits gris. Tu repasses la limite du village sans t'en apercevoir tout à fait : un muret, un seuil, et le bruit de la lande qui s'arrête net derrière toi. Une bâtisse basse, une seule porte, et par elle un froid qui ne vient pas du dehors : le froid des endroits où l'on a beaucoup décidé. Tu entres au Petit Tribunal. Tu es entré par où tout le monde entre. Ça se remarque, et ça permet de voir venir.

Choix affichés : [Ne plus afficher]

## Écran 65 · Jour 3

La grange aux trois bancs sent le suif froid. La chaire fait face à la porte — ici, même l'entrée est un interrogatoire. Au mur, une feuille clouée. Sur la chaire, un livre ouvert. Les bancs, eux, gardent leurs traces. Le registre utilise deux encres. La dernière ligne a été ajoutée bien après les autres. Ils sont six, alignés, du même côté.

Choix affichés : [La feuille clouée au mur] · [Observer les alentours] · [Rester dans la salle] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « La feuille clouée au mur »

## Écran 66 · Jour 3

Trois pas de dalle inégale, et la feuille se précise : du papier épais, jauni, cloué aux quatre coins par quelqu'un qui ne voulait pas qu'on la décroche.

Choix affichés : [Ne plus afficher]

## Écran 67 · Jour 3

La liste des signes, de la main du Bailli. « Parler seul face au sud. Fixer les Profondeurs plus qu'il ne faut. Cesser de dormir. Répondre à ce qui n'a pas parlé. » Tu la lis deux fois. La deuxième fois, tu comptes ceux qui te concernent déjà. Et la troisième, tu les apprends — parce que c'est exactement ce qu'ils guettent chez toi.

Choix affichés : [La chaire et son livre] · [Les bancs et leurs traces] · [Rester dans la salle] · [Utiliser — Baume de mousse noire] · [Ne plus afficher]

> choisit : « Utiliser — Baume de mousse noire »

## Écran 68 · Jour 3

Tu sors « Baume de mousse noire » de la Besace. La plaie se referme, l'entaille cède enfin. La porte s'ouvre derrière toi. Un petit homme sec entre, plume et encrier serrés contre lui — et se fige net en te voyant à la chaire. Une seconde entière. Assez pour que vous sachiez tous les deux qu'il t'a vu.

Choix affichés : [Ne plus afficher]

## Écran 69 · Jour 3

Puis il fait comme si de rien : il s'installe au banc des témoins, ouvre son cahier, et se met à copier. L'Écrivain public. Il ne lève pas les yeux — mais sa plume, elle, a ralenti. Une femme pose un bol par terre à trois pas de toi, et recule avant que tu te baisses. L'écrivain trempe sa plume avant qu'on ait parlé. Il sait déjà ce qu'il va écrire. Ils sont six, alignés, du même côté. — LE GRAND REGISTRE — 1 Anselme le Patient J41 n'est pas mort — a disparu 2 Brigga aux Deux Lames J34 le pont d'os, au retour 3 Sévrin J29 a compté un crâne de trop 4 La Veuve Koll J24 Geryon, tête du milieu 5 O

Choix affichés : [Lire le Registre] · [Donner un nom à la plume] · [Quitter sans lire] · [L’interroger sur son travail] · [Ne plus afficher]

> choisit : « Quitter sans lire »

## Écran 70 · Jour 3

Tu tournes le dos à la chaire. La plume de l'Écrivain continue de gratter — elle écrit ta sortie, en ce moment même, dans une colonne que tu ne verras pas. Certains comptes, on préfère ne pas savoir où ils s'arrêtent. La porte du tribunal se referme sans bruit : on sait que tu reviendras. Tout le monde revient.

Choix affichés : [Ne plus afficher]

## Écran 71 · Jour 3

Devant toi, une porte se ferme. Puis la suivante, avant même que tu arrives à sa hauteur. Ce n'est pas de la peur : c'est de l'ordre. Le mot est passé plus vite que tes pas. D'un côté, un moignon de tour sans sommet. De l'autre, des silhouettes grises qui se déplacent ensemble.

Choix affichés : [Vers une tour qui a perdu son sommet] · [Vers des silhouettes grises] · [Ne plus afficher]

> choisit : « Vers des silhouettes grises »

## Écran 72 · Jour 4

— JOUR 4 — • RENCONTRE • La Meute Grise Tu repasses le muret d'enceinte, et le village te lâche d'un coup — plus de toits, plus de volets, plus de regards. La lande reprend, immense, et le vent te retrouve comme s'il t'avait attendu. La bruyère bouge sans vent, par plaques, autour de toi. Ce ne sont pas des ombres : ce sont des dos gris, bas sur pattes, qui resserrent un cercle patient. Tu as coupé par les fougères hautes. Aucun bruit à compter, aucune vue d'ensemble.

Choix affichés : [Ne plus afficher]

## Écran 73 · Jour 4

Loin de tout muret, la lande est à eux. Tu les vois de loin — et c'est mauvais signe : la Meute Grise ne se montre que quand l'encerclement est fini. Six silhouettes couleur de bruyère morte, immobiles aux six points d'un cercle dont tu es le centre. Pas des chiens : trop patients. Pas des loups : trop organisés. La plus grande s'assoit — le signal. Le cercle se met à tourner, lentement, en se resserrant d'un pas par tour.

Choix affichés : [Hurler le premier RUSE] · [Charger la plus grande COURAGE] · [Ne plus afficher]

> choisit : « Hurler le premier RUSE »
