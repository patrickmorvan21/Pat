# Partie de découverte — v157A (budget épuisé)

## [0] —
*image : geolier_detoure.png, pactum_logo.png*

Tu choisis. Le dé décide.
Lui, il regarde.

COMMENCER
OPTIONS
v1.57.0

CHOIX : [COMMENCER] [OPTIONS]
→ accueil

## [1] —
*image : intro_demon.png*

Tu ne te souviens pas

D'être entré, je veux dire. Personne ne s'en souvient. Tu es mort. Il y a peu.

Ce qui suit est une proposition. Personne ne l'a jamais refusée.

Touche pour commencer

→ continue

## [2] —

Une seule vie

Tu traverses mon Domaine. Une fois. Au bout, une Porte scellée : franchis-la, et tu reprends ta vie là où tu l'as laissée.

Si tu meurs, un autre viendra. Avec un autre nom.

→ continue

## [3] —
*image : intro_de.png*

Le dé tranche

Ton adresse ne te sauvera pas. Courage, ruse, instinct, empathie : ce que tu vaux vient de ce que tu étais de ton vivant.

Touche pour continuer

→ continue

## [4] —
*image : intro_epee.png*

Ta mort me sert

Ta fin est forgée en Relique. Celui qui te suivra la portera. On ne progresse pas ici en survivant. En tombant mieux.

Touche pour continuer

→ continue

## [6] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Avant que tu passes, je veux voir qui tu étais.

Touche pour continuer

→ continue

## [8] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Ne réfléchis pas. Ce n'est plus toi qui choisis, ici — c'est ce que tu as déjà fait.

Touche pour continuer

→ continue

## [10] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Un cheval fou fonce dans la foule, plus personne ne ose s'interposer.

Te jeter devant lui
Détourner la foule d'un cri
Te mettre à l'abri, comme les autres

CHOIX : [Te jeter devant lui] [Détourner la foule d'un cri] [Te mettre à l'abri, comme les autres]
→ choix: Détourner la foule d'un cri

## [12] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

On t'accuse d'un vol que tu n'as pas commis, devant tout le village.

Mentir avec aplomb
Nier tout en bloc
Disparaître dans la foule

CHOIX : [Mentir avec aplomb] [Nier tout en bloc] [Disparaître dans la foule]
→ choix: Disparaître dans la foule

## [14] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Une cloche sonne dans un clocher que tu sais abandonné depuis des années.

Aller vérifier, malgré tout
L'ignorer, le vent en est capable
Prévenir quelqu'un du village

CHOIX : [Aller vérifier, malgré tout] [L'ignorer, le vent en est capable] [Prévenir quelqu'un du village]
→ choix: L'ignorer, le vent en est capable

## [16] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Un homme malade, que tout le monde évite, te demande juste de l'eau.

La lui apporter toi-même
La poser à distance, prudent
Refuser, par peur du mal

CHOIX : [La lui apporter toi-même] [La poser à distance, prudent] [Refuser, par peur du mal]
→ choix: La poser à distance, prudent

## [18] borne-frontiere · Jour 1 · santé 1
*image : geolier_detoure.png*

Une dernière chose. J'ai vu qui tu étais. Il me manque comment on t'appelait.

SCELLER LE PACTE
Qu'il choisisse pour moi

CHOIX : [Qu'il choisisse pour moi]
→ sceller le pacte

## [20] borne-frontiere · Jour 1 · santé 1
*image : intro_demon.png*

Tu sens les choses avant de les voir. Ton corps décide souvent avant toi — et il se trompe peu.
Mais les autres restent pour toi un bruit de fond. Ça t'a coûté. Ça te coûtera encore.

Je sais qui tu es. Le dé, lui, décidera qui tu deviens.

Touche pour commencer

→ continue

## [21] borne-frontiere · Jour 1 · santé 1
*image : scene_landes_frise_montagnes_pleine_b.png*

• LE DOMAINE •

Les Lisières

Touche pour continuer

→ continue

## [25] borne-frontiere · Jour 1 · santé 1
*image : scene_borne_frontiere_v2_a.png, geolier_portrait.png*

— JOUR 1 —

La lande s'ouvre sous un crépuscule qui ne tombe pas. La lumière reste prise entre chien et loup, comme un souffle retenu. Quelque part, une corde grince.

La pierre est seule au milieu du plateau, dressée là où tous les murets renoncent. Haute comme un homme, grise comme le reste — et pourtant l'œil ne voit qu'elle. À son pied, un tas d'offrandes. Au-delà, le sud, nu. Et à trois pas de la borne, un homme immobile, face au sud.

À partir de maintenant, il décide avec moi.

CHOIX : [Observer les alentours] [Fouiller les offrandes RUSE]
→ choix: Écouter, immobile

## [30] borne-frontiere · Jour 1 · santé 1
*image : scene_borne_frontiere_v2_a.png*

Tu ne touches à rien. Tu écoutes. Sous le vent, il y a des voix — basses, à ras de bruyère, qui se passent le mot de ton arrivée. Elles ne te menacent pas. Elles préviennent quelqu'un. Au moins, maintenant, tu sais que la lande parle.

La bruyère efface derrière toi les traces de ceux qui ont choisi avant. Devant, elle ne promet rien.

Deux directions s'ouvrent. D'un côté, des rangées de piquets jusqu'à l'horizon. De l'autre, une crête hérissée de mâts noirs.

→ continue

## [33] borne-frontiere · Jour 1 · santé 1
*image : scene_landes_liaison_plateau_d.png, geolier_portrait.png*

Un vieux, assis contre un muret, gratte une planchette sans te regarder. « Tout le monde a sa ligne, ici », dit-il. « Nom, motif, jours. Même toi — surtout toi. Elle est déjà ouverte. »

Chaque route que tu ne prends pas, quelqu'un d'autre la prend. Je tiens les deux registres.

CHOIX : [Vers les rangées de poteaux] [Vers la crête aux cordes]
→ choix: Vers la crête aux cordes

## [38] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1
*image : scene_colline_aux_gibets_c.png*

Tu montes. Les mâts deviennent des potences.

Tu es passé sous le vent. Rien ne s'est retourné, et tu n'as regardé que tes pieds.

La pente est douce et n'en finit pas — la Colline se mérite à pas comptés. Au sommet, le cercle : neuf potences ordinaires, plantées comme les heures d'un cadran. Et au centre, l'autre. La grande. Sa corde est la seule chose neuve à dix lieues.

À gauche du cercle, un poteau isolé porte encore son occupant. À droite, les potences vides alignent leurs noms gravés.

CHOIX : [Le pied du grand gibet] [Observer les alentours] [Rester au sommet]
→ choix: Les corbeaux, sur la traverse

## [41] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_corbeaux_du_compte_b.png*

Ils sont sur la traverse du grand gibet, immobiles, et ils ne bougent pas quand tu approches — ce qui n'est pas un comportement d'oiseau. Aucun ne te regarde. Ils regardent la corde.

→ continue

## [44] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_corbeaux_du_compte_b.png*

Ils ne mangent pas. Il n'y a rien à manger ici depuis longtemps, et leurs becs sont propres. Ils attendent, et ils sont exactement assez nombreux pour ce qu'ils attendent. La même immobilité que des sentinelles payées d'avance, la même façon d'être tournés du même côté — comme des choses qu'on a postées là. Ils comptent quelque chose qui te concerne, et le compte n'a pas l'air fini.

Il n'y en a qu'un, et il se tient de travers, comme s'il gardait une place. Tu ne sais pas pour qui.

CHOIX : [Le pied du grand gibet] [Observer les alentours] [Rester au sommet]
→ choix: Le Gibet Vide, au centre

## [48] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_gibet_vide_a_b.png*

Tu marches vers le centre, et la chose grandit plus vite que tes pas. À dix mètres, tu comprends que tu avais mal jugé l'échelle. À trois, tu dois lever la tête pour voir le nœud.

Le bois est d'œuvre, assemblé pour durer mille ans. La corde neuve grince. Par grand soleil — rare, ici — l'ombre portée s'étend vers le sud, et elle a une forme que la potence n'explique pas.

→ continue

## [51] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_gibet_vide_a_b.png*

La formule est toujours la même, tu commences à la reconnaître : un nom, deux mots de motif, un nombre. Jamais de date. Comme si le jour n'avait pas d'importance — seulement combien de jours la personne avait tenu avant.

On raconte que le grand gibet a été taillé pour le Bailli, du temps où il jugeait encore. « À sa mesure », répètent ceux qui tiennent l'histoire — sans jamais expliquer quelle mesure il faudrait à un homme pour une traverse pareille.

CHOIX : [Le pied du grand gibet] [Observer les alentours] [Rester au sommet]
→ choix: Le pied du grand gibet

## [54] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_pied_grand_gibet_b.png*

Tu quittes la ligne des potences ordinaires pour celle qui les dépasse toutes. De près, elle est absurde : trois fois trop haute pour un homme, et sa corde est neuve.

Au pied du mât, dans le bois, un nom a été gravé profond, à la gouge, par quelqu’un qui prenait son temps. Il est illisible — pas effacé par la pluie : GRATTÉ, en travers, par quelque chose qui a mordu le bois plus fort que l’outil. Dessous, une date est restée entière. Elle est vieille de trente ans.

CHOIX : [Les potences du cercle] [Le poteau isolé, à gauche] [Rester au sommet]
→ choix: Les potences du cercle

## [57] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_potences_cercle_a_c.png*

Tu entres dans le cercle. Le vent monte d'un cran dès le premier pas entre deux potences — pas plus fort ailleurs, plus fort ICI, comme si l'espace entre les mâts avait son climat.

Chaque potence porte un nom gravé au pied, et une date. Les entailles sont de la même main — appliquée, régulière, la main de quelqu'un qui grave comme on rend un jugement.

→ continue

## [59] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_potences_cercle_a_c.png*

Le motif qui revient le plus n'est pas le vol, ni le meurtre. C'est trois mots : « a parlé dehors ». Tu ne sais pas encore ce qu'on parlait, ni à qui, ni pourquoi le dehors compte.

CHOIX : [Le poteau isolé, à gauche] [Rester au sommet]
→ choix: Le poteau isolé, à gauche

## [62] colline-aux-gibets · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_landes_poteau_pendu_c.png*

Tu contournes le cercle par la gauche. Le poteau isolé est plus bas que les autres — à hauteur d'homme, exactement. Une hauteur qu'on choisit.

Chaîne de fonction au cou, sous la corde. Un sceau au poing. Et les yeux qui s'ouvrent quand tu arrives à portée de voix : le Bailli des Landes, pendu le dernier, à la place d'honneur.

CHOIX : [Rester au sommet]
→ choix: Rester au sommet

## [66] colline-aux-gibets-2 · Jour 1 · santé 1 · soupçon 1 · hante
*image : scene_colline_gibets_2_a.png, etat_hante.png, geolier_portrait.png*

Hanté
Ce que tu as vu ne s'est pas rangé. Ça reste posé de travers dans ta tête, et ça bouge quand tu ne le regardes pas.

Le vent tombe d'un coup, comme on ferme une porte. Et dans ce calme plat, les neuf cordes du cercle se mettent à bouger. Pas au hasard : ensemble. Un balancement lent, réglé, qui va et vient sur le même temps.

Ça grince en mesure. Neuf cordes, un seul rythme. Tu comprends, avec un retard qui te coûte, que ce rythme ne t'est pas indifférent — tu pourrais le compter.

OBTENU — BAUME DE MOUSSE NOIRE · COMMUN
Ça sent la cave. Ça referme les plaies.

Le Gibet Vide n'est pas vide. Il est réservé.

CHOIX : [Hanté Ce que tu as vu ne s'est pas rangé. Ça reste posé de travers dans ta tête, et ça bouge quand tu ne le regardes pas.] [Partir avant de comprendre] [Rester et compter INSTINCT] [Arracher une écharde COURAGE]
DÉ → DESTIN
→ lance le dé

## [70] troupeau-sans-berger · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_troupeau_sans_berger_a.png*

Tu comptes jusqu'au bout, sans ciller. Le nombre tombe, et il ne te dit rien — pas encore. Tu le retiens quand même. Un jour, en te réveillant sur une autre borne, tu te souviendras de ce chiffre et tu sauras exactement ce qu'il comptait.

OBTENU — LARME DU GEÔLIER · LÉGENDAIRE
Il jure qu'il ne pleure pas. Elle existe pourtant — et te protège de justesse.

Des bêtes broutent la bruyère morte au creux du vallon — un troupeau entier, sans personne. Elles ne s’écartent pas quand tu approches : elles lèvent la tête, te regardent une seconde, et se remettent à brouter.

CHOIX : [Ne plus afficher]
→ continue

## [75] troupeau-sans-berger · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_troupeau_sans_berger_a.png, geolier_portrait.png*

C’est ce détail qui te dérange le plus. Elles n’ont pas appris à se méfier.

Une odeur de corde mouillée, ici, où il n'y a ni corde ni eau.

Une ombre passe à ta gauche, à la vitesse d'un homme qui marche. Quand tu regardes, rien ne marche nulle part.

Un 20. Rare. Je note, je n'applaudis pas.

CHOIX : [Les marques d’oreille] [S’avancer dans le vallon] [Ne plus afficher]
→ choix: S’avancer dans le vallon

## [80] troupeau-sans-berger-2 · Jour 1 · santé 1 · soupçon 1 · hante
*image : monstre_troupeau_brebis_v2_b.png*

Une brebis s’écarte du groupe et marche droit vers le nord-est, s’arrête, revient. Puis recommence. Cinq fois pendant que tu la regardes.

Elle refait un trajet. Elle attend au bout de quelque chose qui n’arrive plus.

Dans cette direction, à un quart d’heure de marche, il y a le Champ des Fixés.

Quelque chose grince très haut, très loin, à une hauteur où il n'y a rien.

CHOIX : [Continuer ton chemin] [Suivre la brebis]
→ choix: Suivre la brebis

## [84] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_des_fixes_b.png*

— JOUR 2 —

L'horizon se hérisse de piquets réguliers, rangée après rangée, jusqu'à se perdre. Tu approches d'un champ qu'on n'a pas semé — on l'a planté d'hommes.

Tu es venu par le flanc, le nez au sol. Personne ne t'a vu. Toi non plus.

Pas de tombes — des poteaux. Des rangées de poteaux plantés droit, un nom sur chaque, alignés face au nord. Dos au sud. Même morts, surtout morts, on ne les laisse pas regarder par là.

→ continue

## [88] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_des_fixes_b.png*

Au fond, des poteaux vierges attendent, déjà plantés. Près de l'entrée, la cabane du Fossoyeur.

— « Tu comptes, toi aussi. » Personne autour de toi n'a ouvert la bouche.

Le champ entier est un registre debout. Chaque poteau son pendu, chaque pendu son écriteau : un nom, un motif, un nombre de jours. Une écriture de greffe, appliquée, sans colère.

→ continue

## [90] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_des_fixes_b.png*

Un seul écriteau détonne : le motif a été gratté au couteau, si fort que le bois est entaillé. Le nom reste, le nombre de jours reste. Ce qu'elle avait fait, quelqu'un n'a pas supporté qu'on le lise.

CHOIX : [Les rangées et leurs noms] [Observer les alentours] [Rester dans le champ]
→ choix: Les rangées et leurs noms

## [93] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_les_rangees_v2_a.png*

Tu marches entre deux rangs. Le sol est tassé par des allées et venues régulières — on entretient ce champ comme un jardin, et c'est ça qui serre le ventre.

Les noms des premières rangées sont presque effacés. Les dernières sont fraîches. Entre les deux, une rangée entière porte la même date — un seul jour, neuf fixations. Il y a une histoire là-dedans que personne ne raconte.

→ continue

## [95] champ-des-fixes · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_champ_les_rangees_v2_a.png*

Une ligne du registre n'a pas de nom. Le motif est rempli, le nombre de jours aussi — quatre-vingt-onze — et l'emplacement du nom est laissé propre. Pas gratté : jamais écrit. Quelqu'un a compté une vie sans accepter de la nommer.

CHOIX : [Les poteaux vierges, au fond] [Un vide dans une rangée pleine] [Rester dans le champ]
→ choix: Rester dans le champ

## [98] champ-des-fixes-2 · Jour 2 · santé 1 · soupçon 1 · hante
*image : monstre_fossoyeur_poteaux_a.png, geolier_portrait.png*

Entre les rangs, un vieil homme redresse un poteau qui penche, avec des gestes de jardinier. Il t'a vu venir de loin — les vivants font un bruit particulier, ici. Il ne s'interrompt pas : il t'attend au travail, comme on attend un outil. « La Colline, c'est la vitrine », dit-il sans qu'on demande. « Ici, c'est l'arrière-boutique. »

Le Fossoyeur est mon employé du mois. Tous les mois. Il ne se plaint jamais du salaire.

CHOIX : [Passer sans un mot] [Aider à redresser EMPATHIE]
DÉ → DESTIN
→ lance le dé

## [108] champ-des-fixes-2 · Jour 2 · santé 1 · soupçon 1 · hante
*image : monstre_fossoyeur_poteaux_a.png*

Le poteau retrouve son aplomb. Le pendu là-haut soupire — de confort, dirait-on. « Ils dorment mal quand ça penche », dit le Fossoyeur. Il te fait signe de passer par son rang : le sien est sûr.

Un berger sans troupeau te croise au détour d'un talus. Il te salue — du menton, pas de la voix — et presse le pas une fois passé. Tu l'entends s'arrêter, plus loin, pour te regarder partir.

→ continue

## [112] champ-des-fixes-2 · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_hameau_dense_b.png*

D'un côté, des toits bas et une fumée qui ne monte pas droit. De l'autre, un gibet bas, à hauteur d'homme, qui bouge sans vent.

L'espace d'un pas, tes pieds ne touchent plus tout à fait le sol.

Ici, on ne pend pas pour punir. On pend pour remplacer. Une corde tendue à temps, disent-ils, et personne d'autre n'est repris cette saison-là.

CHOIX : [Vers la fumée d'un hameau] [Vers un gibet qui parle]
→ choix: Vers la fumée d'un hameau

## [116] serment-hameau · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_hameau_dense2_b.png*

Derrière toi, très loin, des battements d'ailes quittent une traverse — exactement le compte que tu n'as pas voulu faire. Un battement de plus leur répond. Plus près.

De la fumée basse, pas une flamme : des toits gris tassés derrière leurs murets. Le Hameau des Renonçants se découvre lentement, et déjà tu sens qu'on t'a vu venir de loin.

Tu es entré par où tout le monde entre. Ça se remarque, et ça permet de voir venir.

→ continue

## [121] serment-hameau · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_hameau_dense2_b.png*

Les toits apparaissent au creux du plateau — de l'ardoise affaissée, des murs qui tiennent par habitude. Une seule cheminée fume, sur une vingtaine.

Tu es encore loin quand tu comprends ce qui cloche : aucun chien n'aboie.

Tu comptes ce qui t'entoure — les ombres, les pierres. Il y en a toujours une de plus au deuxième compte.

Il y a un corbeau sur le toit d'en face. Il y était déjà dans l'autre rue.

→ continue

## [123] serment-hameau · Jour 2 · santé 1 · soupçon 1 · hante
*image : scene_hameau_dense2_b.png*

Les rares mots qu'on t'adresse ont raccourci. On te répond sec, sans te regarder — pas de l'hostilité. De l'économie.

CHOIX : [Observer d'abord, à couvert INSTINCT] [Descendre vers le hameau]
DÉ → RÉUSSITE ÉCLATANTE
→ lance le dé

## [135] hameau-entree-2 · Jour 2 · santé 1 · soupçon 2 · hante
*image : scene_hameau_entree_2_v2_a.png*

À couvert derrière un muret, tu prends la mesure du village : onze maisons vivantes sur vingt, et pas un mouvement dehors. Ce n'est pas un hameau qui dort. C'est un hameau qui attend.

La première maison est à dix pas. Sur sa porte, un signe à la craie — une croix, simple, tracée à hauteur d'œil.

La poudre blanche est encore sur le seuil. Ça date de ce matin.

Un corbeau descend d'un cran quand tu passes, comme on se rapproche pour mieux entendre.

→ continue

## [137] hameau-entree-2 · Jour 2 · santé 1 · soupçon 2 · hante
*image : scene_hameau_entree_2_v2_a.png*

Une conversation s'éteint à ton approche. Pas interrompue : pliée, rangée, comme du linge qu'on rentre avant la pluie.

CHOIX : [Le linteau de la porte] [Observer les alentours] [Continuer dans la rue]
→ choix: Le gamin, en haut du muret

## [141] gamin-murets-1 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_gamin_murets_a.png*

Un enfant est assis sur la crête d'un muret, les pieds dans le vide côté lande. Il ne joue à rien. Il regarde le sud comme les adultes d'ici regardent le sud, et il le fait mieux qu'eux.

Il te laisse arriver jusqu'au pied du muret sans bouger. De près, ses genoux sont râpés partout pareil — quelqu'un qui court sur la pierre, pas sur les chemins. Il attend que tu parles le premier.

→ continue

## [144] gamin-murets-1 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_gamin_murets_a.png*

Il aligne des cailloux sur le muret, par taille. Il ne se cache pas de toi : c’est le premier habitant qui ne se méfie pas. « T’es le nouveau. T’as combien de corbeaux ? »

Il n’attend pas la réponse, et compte sur ses doigts. « Trois avant toi cette année. Deux sont ressortis. »

→ continue

## [148] gamin-murets-1 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_gamin_murets_a.png*

Il désigne la lande du menton, la crête des murets qui court vers le sud, basse et sèche. « Y a le chemin, et y a les murets. Le chemin, il fait le tour de tout. Les murets, non. »

Tu t'entends répondre à quelqu'un qui n'a pas parlé. Personne ne relève. C'est le pire.

Un seul corbeau, posé de biais. Il ne cherche pas sa nourriture : il cherche un angle.

CHOIX : [Lui demander de te guider EMPATHIE] [Lui demander qui est ressorti] [Le laisser sur son mur]
→ choix: Lui demander qui est ressorti

## [151] gamin-murets-2 · Jour 2 · santé 1 · soupçon 2 · hante
*image : scene_murets_vers_sud_c.png*

« Le grand avec la lanterne. Et une dame, mais elle a pas pris le sud. » Il replie deux doigts. « L’autre, il est allé jusqu’à la palissade. Il a fait demi-tour. Il dit que c’est pas fermé, c’est juste que ça retient. »

Le muret repart vers le sud, à hauteur de hanche, en pierre sèche posée sans mortier. On voit à l’usure du sommet que quelqu’un y marche tous les jours, et que ce quelqu’un est petit.

→ continue

## [154] gamin-murets-2 · Jour 2 · santé 1 · soupçon 2 · hante
*image : scene_murets_vers_sud_c.png*

Pendant une seconde, le sol sous tes pieds est de la terre retournée de frais.

Deux femmes s'arrêtent de parler quand tu passes — mais tu as saisi la fin : « … à la Colline aux Gibets. C'est Le Gamin des Murets qui l'a dit. » Elles reprennent leur chemin, plus vite que nécessaire.

Un corbeau sur le faîtage.

CHOIX : [Reprendre la ruelle]
→ choix: Reprendre la ruelle

## [157] gamin-murets-3 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_gamin_caillou_c.png*

Tu laisses le muret filer vers le sud sans toi. La ruelle, elle, fait le tour de tout — c’est bien ce qu’il avait dit.

« Moi j’en ai zéro », dit-il en revenant à ses cailloux. « Ma mère en a deux. Elle sait pas. Faut pas lui dire, elle a peur pour rien. »

→ continue

## [161] gamin-murets-3 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_gamin_caillou_c.png*

Il fouille dans sa poche et te tend une pierre plate, grise, polie comme un galet de rivière. Il n’y a pas de rivière dans les Landes. « C’est la dame de l’ouest qui me l’a donnée. »

Deux femmes s'arrêtent de parler quand tu passes — mais tu as saisi la fin : « … à l'entrée du Hameau. C'est Le Gamin des Murets qui l'a dit. » Elles reprennent leur chemin, plus vite que nécessaire.

Un corbeau te suit de toit en toit, sans se presser.

→ continue

## [163] gamin-murets-3 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_gamin_caillou_c.png, geolier_portrait.png*

Un enfant, un caillou, et personne pour l’écouter. C’est ainsi que commencent la plupart des vérités.

CHOIX : [Ne pas relever] [« Où l’as-tu vue ? » INSTINCT] [« Quelle dame ? »]
→ choix: « Quelle dame ? »

## [166] gamin-murets-4 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_gamin_depart_c.png*

« Ben, la dame. » Il hausse les épaules, comme si tu demandais de quelle couleur est le ciel. « Elle est jeune. Elle a un châle. Elle marche du côté du moulin, là où l’herbe est couchée. » Il repose un caillou dans la rangée, très exactement à sa place.

« Ma mère dit que j’invente. Le rebouteux dit que j’invente. Tout le monde dit que j’invente. » Il te regarde enfin, droit. « Mais le caillou, il est vrai. Tu le tiens. »

→ continue

## [169] gamin-murets-4 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_gamin_depart_c.png*

Il redescend du muret et ramasse ses pierres une par une, dans l’ordre. « Si tu la vois, dis-lui merci pour le caillou. J’ai oublié la dernière fois. »

Il y a un corbeau sur le toit d'en face. Il y était déjà dans l'autre rue.

CHOIX : [Le lui promettre] [Ne rien promettre]
→ choix: Le lui promettre

## [172] hameau-entree-3 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_hameau_entree_3_v2_a.png*

Il hoche la tête, satisfait, et ne vérifie pas. À dix ans, on croit encore qu’une promesse et une chose faite sont la même chose. Tu redescends la ruelle avec un caillou de rivière dans la main, dans un pays qui n’a pas de rivière.

Ils sont trois à t'attendre au milieu de la rue. Pas armés — un bâton de marche, une fourche posée contre un mur, à portée sans être brandie.

→ continue

## [175] hameau-entree-3 · Jour 2 · santé 1 · soupçon 2 · hante
*image : monstre_hameau_entree_3_v2_a.png*

Celui du centre est vieux, sec comme un piquet. C'est lui qui parle, et sa voix ne tremble pas. Ses mains, si.

— « On ne te chasse pas. » Il le dit d'abord, comme une formule apprise. « Personne n'est chassé, ici. Mais tu descends. Ça se voit à ton pas. Et ceux qui descendent... » Il ne finit pas. Derrière lui, une femme tire un enfant à l'intérieur, sans un mot.

Un corbeau sur le faîtage.

CHOIX : [« Je ne fais que passer. »] [Demander ce qu'ils craignent EMPATHIE] [Passer sans t'arrêter COURAGE]
DÉ → RÉUSSITE ÉCLATANTE
→ lance le dé

## [186] hameau-entree-4 · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : monstre_hameau_entree_4_c.png, etat_fixe.png*

Fixé
On ne te parle plus tout à fait à toi. On parle devant toi, de toi, à voix normale, comme on parle devant un poteau déjà planté.

« Ça ne se demande pas. » Le vieux se ferme d'un coup, et les deux autres avancent d'un demi-pas. Ta question, dans leur grammaire, est déjà un aveu : seuls ceux qui entendent s'intéressent à ce qu'on entend.

— JOUR 3 —

La lande t'a pris un jour. La lumière a tourné sans que tu avances.

Au bout de la rue, un muret bas ferme le village côté sud. Le vieux y est assis, sec comme un piquet, les coudes sur les genoux. Il t'attendait là depuis le début.

CHOIX : [Fixé On ne te parle plus tout à fait à toi. On parle devant toi, de toi, à voix normale, comme on parle devant un poteau déjà planté.]
→ choix: Entrer dans le hameau

## [210] hameau-entree-5 · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_hameau_dense_c.png, geolier_portrait.png*

Il y a des traces fraîches sur ton chemin — devant toi. Quelqu'un fait ta route avant toi, dans le même sens, à petite distance. Tu ne le rattrapes jamais.

D'un côté, un chemin qui s'enfonce entre deux talus. De l'autre, des rangs d'arbres qui n'ont plus de feuilles.

Le vent dit un nom. Ce n'est pas le tien. Tu le retiens quand même.

Tu as mis moins de temps que le précédent. Il est mort plus loin, cela dit.

CHOIX : [Vers le chemin creux] [Vers des rangs d'arbres noirs]
→ choix: Vers le chemin creux

## [214] bete-chemins-creux · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : monstre_bete_chemins_creux_a.png*

• RENCONTRE •
La Bête des Chemins Creux

Les dernières maisons s'espacent, puis renoncent. Devant toi la bruyère morte reprend ses droits jusqu'à l'horizon. Dans ton dos, quelqu'un referme une porte, sans se presser.

Le sol se creuse sous tes pas, et le ciel se rétrécit à mesure que tu descends.

Tu n'as rien contourné. Tu arrives par la face, et rien ne t'a échappé en chemin.

→ continue

## [217] bete-chemins-creux · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : monstre_bete_chemins_creux_a.png*

Le creux tourne — et l'odeur arrive avant la chose : suint, terre retournée, vieux cuir. Une masse se décolle du talus, longue, basse, taillée pour courir exactement entre deux murs de terre.

Pas de gueule visible. Juste une avancée du corps qui s'ouvre. La Bête ne chasse que dans le creux — c'est son couloir, son terrier, sa table. Et tu es dessus.

CHOIX : [Frapper la bête COURAGE] [Bondir hors du creux INSTINCT] [Se plaquer, immobile] [Utiliser — Baume de mousse noire]
DÉ → FUNESTE
→ lance le dé

## [227] chemin-creux · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_chemin_creux_c.png, etat_aguerri.png*

Aguerri
Le combat t'a affûté : tes gestes portent mieux, pour un temps.

Le coup porte. La Bête se plie, surprise qu'on morde en premier, et s'enterre à mi-corps dans le talus. Tu passes. Elle ne suit pas — pas blessée à ce point, mais vexée, oui.

Le chemin s'enfonce entre deux talus plus hauts que toi ; le ciel devient un ruban. C'est le plus court chemin des Landes, et le seul où l'on ne voit pas venir.

CHOIX : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps.]
→ continue

## [229] chemin-creux · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_chemin_creux_c.png, etat_aguerri.png*

Aguerri
Le combat t'a affûté : tes gestes portent mieux, pour un temps.

Une charrette penche au premier coude. Les talus, au-dessus, sont meubles. Plus loin, le chemin tourne et la terre mange la vue. Et dans le creux, quelqu'un vient vers toi — de dos.

CHOIX : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps.] [La charrette embourbée] [Observer les alentours] [Couper par la lande INSTINCT] [Utiliser — Baume de mousse noire]
→ choix: Le haut des talus

## [233] chemin-creux · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_chemin_talus_a_c.png*

Tu montes de trois pas dans la pente, juste assez pour voir la crête sans t'exposer entièrement. La terre y est meuble, retournée.

Des empreintes. Parallèles au chemin. Sur toute sa longueur — mais sur la crête NORD seulement : l'autre versant est intact, pas une marque. Quelque chose marche là-haut quand quelqu'un marche en bas, à la même vitesse, du même pas, et toujours du même côté. Tu redescends sans te presser, parce que se presser serait une information.

CHOIX : [La charrette embourbée] [L'homme qui marche à reculons] [Couper par la lande INSTINCT] [Utiliser — Baume de mousse noire]
DÉ → RÉUSSITE
→ lance le dé

## [245] chemin-creux-2 · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_chemin_creux_coude_b.png, etat_aguerri.png, geolier_portrait.png*

Aguerri
Le combat t'a affûté : tes gestes portent mieux, pour un temps.

Tes pieds trouvent une sente que la bruyère cachait — un chemin de braconnier, tracé par quelqu'un qui savait exactement ce qu'il évitait. Tu sais maintenant le reconnaître.

OBTENU — ÉLIXIR DU CAMPEMENT PERDU · RARE
Quelqu'un l'a brassé pour un repos qui n'est jamais venu.

Le chemin tourne, et le talus mange la vue d'un coup. Passé le coude : rien. C'est-à-dire l'endroit exact où il devrait y avoir quelque chose, et il n'y a rien.

Le silence y est plus épais d'un cran, comme après un bruit que tu aurais raté d'une seconde.

Vingt. Le Domaine te laisse ce point. Il compte les siens autrement.

CHOIX : [Aguerri Le combat t'a affûté : tes gestes portent mieux, pour un temps.] [Sortir par le talus] [Longer le côté sud] [Franchir le coude INSTINCT] [Utiliser — Baume de mousse noire]
→ choix: Longer le côté sud

## [248] chemin-creux-2 · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_chemin_creux_coude_b.png*

Tu passes le coude épaule contre le talus SUD, du côté vierge d'empreintes, et tu marches sans accélérer. Au-dessus, à droite, sur la crête nord, quelque chose t'accompagne un moment — puis s'arrête, parce que le versant s'interrompt et qu'elle ne traverse pas. Tu ressors du creux entier, et sans avoir couru.

Au loin, une cloche muette sonne quand même — trois coups mats, du bois sur du bois. Tu comprends que ça compte tes passages. Quelqu'un, quelque part, tient le total.

→ continue

## [250] chemin-creux-2 · Jour 3 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_landes_liaison_sud_c.png*

D'un côté, une palissade qui coupe l'horizon, une lanterne allumée en plein jour. De l'autre, des rangs d'arbres qui n'ont plus de feuilles.

CHOIX : [Vers une palissade au sud] [Vers des rangs d'arbres noirs]
→ choix: Vers des rangs d'arbres noirs

## [255] verger-noir · Jour 4 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_verger_noir_d.png*

— JOUR 4 —

Des rangs réguliers montent de la bruyère. De loin, c'est presque rassurant.

Tu as pris la route droite. On t'a vu venir — et tu as eu le temps de tout regarder.

Des arbres fruitiers plantés en rangs — le seul ordre volontaire des Landes hors du hameau. Ils ont poussé, ils ont des branches, des feuilles noires, et des fruits. C'est pire que s'ils étaient morts.

Les rangs et leurs fruits. La souche du premier arbre, au bout. Et deux silhouettes qui bêchent, tout au fond.

CHOIX : [Les fruits, dans les rangs] [Observer les alentours] [Goûter un fruit COURAGE] [Utiliser — Baume de mousse noire]
→ choix: Les fruits, dans les rangs

## [258] verger-noir · Jour 4 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_verger_fruits_cendre_v2_c.png*

Tu entres dans un rang. L'odeur devrait arriver là — pas de pourriture : pas d'odeur du tout. Un verger qui ne sent rien.

Ronds, lourds, gris mat. La peau est parfaite et le poids ment : tu en décroches un, il pèse comme une pierre et cède comme du papier. Des fruits de cendre. Tu en gardes un. On ne sait jamais ce qu'on est prêt à parier.

CHOIX : [La souche, au bout du rang] [Observer les alentours] [Goûter un fruit COURAGE] [Utiliser — Baume de mousse noire]
→ choix: Compter les rangs

## [263] verger-noir-2 · Jour 4 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_verger_noir_2_v2_b.png*

Onze rangs. Tu recomptes : onze. Chaque rang est planté d'une essence différente, et chaque essence a donné les mêmes fruits gris. Onze tentatives, onze réponses identiques, et un douzième rang en cours de creusement au fond. Il n'y a pas de mot pour ça dans ta langue. Ici, ça s'appelle mardi.

Un fruit tombe, derrière toi. Sans vent, sans oiseau.

Quand tu le ramasses, il est encore chaud — comme une chose qui vient de cesser d'essayer.

CHOIX : [Le reposer au pied de l'arbre] [Sortir des rangs INSTINCT] [Utiliser — Baume de mousse noire]
→ choix: Le reposer au pied de l'arbre

## [266] verger-noir-2 · Jour 4 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_verger_noir_2_v2_b.png*

Tu le reposes exactement sous la branche d'où il vient, bien calé dans la terre, comme on remet quelque chose à sa place. Le geste ne sert à rien. Tu le fais quand même, et le verger entier te paraît une seconde moins hostile.

Elle passe, et elle parle sans tourner la tête. « Tu marches comme quelqu'un qui compte les jours. » Un temps, sa voix déjà derrière toi : « Moi j'ai arrêté au troisième. » Quand tu te retournes, la bruyère se referme sur rien.

→ continue

## [268] verger-noir-2 · Jour 4 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_landes_liaison_sud_c.png*

D'un côté, une palissade qui coupe l'horizon, une lanterne allumée en plein jour. De l'autre, une eau noire où les roseaux ne bougent pas.

CHOIX : [Vers une palissade au sud] [Vers une eau qui ne bouge pas]
→ choix: Vers une eau qui ne bouge pas

## [273] mare-aux-regards · Jour 4 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_mare_aux_regards_a.png*

Le vent tombe d'un coup, comme coupé au couteau. Tes derniers pas ne font plus de bruit.

Tu as coupé par les fougères hautes. Aucun bruit à compter, aucune vue d'ensemble.

L'eau est noire et parfaitement plate — le seul endroit des Landes que le vent évite.

La berge est piétinée en un seul point, tassée par des années de genoux. On ne vient pas ici puiser. On vient s'agenouiller. Le point de berge usé. L'eau. Et dans les roseaux, un reflet de métal.

CHOIX : [Les creux dans la berge] [Observer les alentours] [Boire à la mare COURAGE] [Utiliser — Baume de mousse noire]
→ choix: Les creux dans la berge

## [276] mare-aux-regards · Jour 4 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_mare_creux_doubles_v2_b.png*

Tu longes la berge jusqu’à l’endroit où la terre est tassée, luisante, usée jusqu’à la pierre. On s’agenouille ici depuis longtemps.

Les creux de genoux sont doubles. Une paire devant, au ras de l’eau. Une autre juste derrière, plus large, plus profonde — et orientée dans le même sens. Quelqu’un se tenait toujours au-dessus de celui qui se penchait. Ce n’est pas un endroit où l’on vient voir son reflet : c’est un endroit où on l’amène.

CHOIX : [Le point de berge usé] [Observer les alentours] [Boire à la mare COURAGE] [Utiliser — Baume de mousse noire]
→ choix: Le point de berge usé

## [279] mare-aux-regards · Jour 4 · santé 0.74 · soupçon 4 · hante,fixe
*image : scene_mare_berge_a_c.png*

Tu contournes la mare par la droite pour atteindre le seul endroit où la boue est tassée. Le sol y est dur comme un seuil de maison.

Deux creux dans la terre, à largeur de genoux, refaits par des centaines de personnes au même endroit exact. À côté, des marques de doigts crispés dans la boue séchée. On ne s'agenouille pas ici pour prier. On s'agenouille pour vérifier.

CHOIX : [L'eau] [Observer les alentours] [Boire à la mare COURAGE] [Utiliser — Baume de mousse noire]
DÉ → DESTIN
→ lance le dé

## [289] mare-aux-regards-2 · Jour 4 · santé 0.58 · soupçon 4 · hante,fixe,fievreux
*image : scene_mare_aux_regards_2_b.png, etat_fievreux.png*

Fiévreux
Le froid t'a lâché d'un coup, et c'est mauvais signe : ce n'est plus l'air qui te réchauffe. Tes mains tremblent quand tu ne les regardes pas.

Tu bois — et l'eau reste au bord des lèvres, sans descendre, une seconde de trop. Quand elle passe enfin, tu as l'impression très nette d'avoir avalé quelque chose qui a accepté de se laisser avaler.

Ils arrivent à deux. Le premier s'agenouille dans les creux du devant, se penche, et reste penché beaucoup trop longtemps. Le second reste debout derrière lui, dans les creux du fond, et ne regarde pas l'eau : il regarde la nuque de l'autre.

CHOIX : [Fiévreux Le froid t'a lâché d'un coup, et c'est mauvais signe : ce n'est plus l'air qui te réchauffe. Tes mains tremblent quand tu ne les regardes pas.]
DÉ → ÉCHEC
→ lance le dé


Erreurs JS : 0 · HTTP≥400 : 0