"use client";

/**
 * LE FOND DE BRAISES — le liant visuel de la séquence de mort (Notion 30/07).
 *
 * Présent en bas de TOUS les écrans de la séquence : La mort · Le fragment ·
 * Le Registre · La Relique. Un lit de braises MINCE qui respire, jamais une
 * flamme haute — le feu est passé, il reste ce qui couve.
 *
 * PORT FIDÈLE du moteur de `maquettes/flamme_braise_v3.html` (la maquette
 * validée, versionnée le 30/07), verrouillé sur le réglage retenu :
 *   grain 3 · tick 45ms · src 0.94 · boost 0.06 · cool 0.082 · lit 3 rangs ·
 *   zoneBasse 0.14 · frein 0.55 · bruit 0.52 · braises 10 · vent 1.15 ·
 *   reprise 0.05 · coolVar 0.65 · cendres 2/pas · palier 10 pas
 * (Densité haute · Hauteur moyenne · Lit mince · Irrégularité sauvage ·
 *  Cendres fines · Respiration normale.)
 *
 * Principes techniques VERROUILLÉS (tous portés tels quels) :
 *   • Deux couleurs, seuillage Bayer 4×4 — le `boost` de densité ABAISSE le
 *     seuil, jamais de dégradé, jamais d'alpha.
 *   • Respiration par PALIERS : 16 valeurs multiplicatrices (0.70 → 1.22,
 *     montée plus longue que la chute), qui montent la source ET ralentissent
 *     le refroidissement (`cool / respire`).
 *   • Quatre sources d'irrégularité, toutes gardées : un lit de braises
 *     vivantes (naissent, dérivent, déclinent après 70 % de leur vie) · un
 *     bruit de VALEUR lissé à 3 octaves (hash, jamais un sinus — rien n'est
 *     périodique) · un VENT COHÉRENT (une seule valeur qui dérive) appliqué
 *     en cisaillement sous-cellule croissant avec la hauteur · des REPRISES
 *     brèves sur une colonne.
 *   • Les cendres naissent à la crête des colonnes chaudes, montent en
 *     ondulant, suivent le vent, et se raréfient par PROBABILITÉ DE DESSIN.
 */

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { createPortal } from "react-dom";
import { animReduced } from "@/lib/settings";

const ORANGE = "#e0632a";

/* Abonnement inerte : `useSyncExternalStore` ne sert ici qu'a distinguer le
   rendu serveur du rendu client (false au prerendu, true une fois hydrate).
   C'est le pattern sans etat — `setState` dans un effet est refuse par le
   compilateur React, et un `typeof document` nu produirait un ecart
   d'hydratation. Declare au niveau module : une fonction recreee a chaque
   rendu ferait se reabonner le store en boucle. */
const SANS_ABONNEMENT = () => () => {};

const BAYER = [
  [0, 8, 2, 10],
  [12, 4, 14, 6],
  [3, 11, 1, 9],
  [15, 7, 13, 5],
];

/* Le réglage retenu, verbatim (panneau de la maquette). */
const GRAIN = 3;
const TICK = 45;
const SRC = 0.94;
const BOOST = 0.06;
const COOL = 0.082;
const LIT_RANGS = 3;
const ZONE_BASSE = 0.14;
const FREIN = 0.55;
const BRUIT = 0.52;
const N_BRAISES = 10;
const VENT = 1.15;
const REPRISE = 0.05;
const COOL_VAR = 0.65;
const CENDRES_PAR_PAS = 2;
const PALIER_PAS = 10;

/** Hauteur de foyer pour laquelle les réglages ci-dessus sont ceux de la
    maquette. Au-delà, le refroidissement est divisé d'autant (voir plus bas) :
    sans ça, agrandir le foyer n'agrandit pas la flamme — elle meurt au même
    nombre de pixels et on ajoute juste du vide au-dessus. */
const HAUTEUR_REF = 48;

/** Respiration : multiplicateur par paliers entiers — montée plus longue que
    la chute, jamais une interpolation. (Tableau BREATH de la maquette.) */
const BREATH = [0.70, 0.76, 0.84, 0.93, 1.02, 1.10, 1.17, 1.21, 1.22, 1.17, 1.09, 0.99, 0.89, 0.80, 0.74, 0.71];

/* Bruit de valeur lissé (hash) — casse toute périodicité, contrairement à un
   sinus. Copié de la maquette. */
function hash1(n: number) {
  n = (n << 13) ^ n;
  return 1 - ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824;
}
function noise1(x: number) {
  const i = Math.floor(x);
  const f = x - i;
  const a = hash1(i);
  const b = hash1(i + 1);
  const u = f * f * (3 - 2 * f);
  return a + (b - a) * u; /* -1 … 1 */
}
function fbm(x: number) {
  /* trois octaves : grosses masses + détail */
  return noise1(x) * 0.55 + noise1(x * 2.37 + 11.7) * 0.29 + noise1(x * 4.91 + 41.3) * 0.16;
}

export default function FondBraises({
  height = 56,
  className,
}: {
  /** Hauteur CSS du FOYER (la partie qui brûle), en px. Le canvas, lui,
      couvre tout le cadre : les cendres doivent pouvoir monter PAR-DESSUS
      l'interface (retour Patrick 30/07 — « là c'est coupé »), le composant
      est donc un calque plein écran posé après le contenu, jamais cliquable.
      Le profil de flamme s'étire proportionnellement (cf. HAUTEUR_REF) : une
      valeur triple donne des flammes trois fois plus hautes, pas un foyer de
      même taille avec du vide au-dessus. */
  height?: number;
  className?: string;
}) {
  const ref = useRef<HTMLCanvasElement>(null);
  /* Clé de re-mesure : elle change quand le cadre change de taille en
     CELLULES, et rien d'autre. */
  const [taille, setTaille] = useState(0);
  /* Le calque vit dans un PORTAIL vers <body> (cf. le rendu, plus bas), qui
     n'existe qu'apres le premier rendu cote client. Les deux effets ci-dessous
     dependent donc de `monte` : sans lui ils s'executaient une seule fois,
     avec `ref.current` encore null, et ne se rejouaient jamais — le canvas
     etait bien en place mais RIEN n'y etait peint (defaut attrape par une
     mesure de pixels, invisible au DOM). */
  const monte = useSyncExternalStore(SANS_ABONNEMENT, () => true, () => false);

  /* ⚠️ LE BITMAP DOIT SUIVRE LE CADRE. Sa taille était fixée une seule fois au
     montage ; or la hauteur visible bouge sur un téléphone dès que la barre
     d'outils se rétracte (cf. `--app-h`, 06/09). Le canvas est en `h-full
     w-full` : sa BOÎTE suivait, son bitmap non — le lit se faisait donc
     étirer, et le grain de la trame avec lui. On rejoue la simulation à la
     nouvelle taille plutôt que de laisser une image déformée.
     Le filtre par cellules évite de tout relancer sur un pixel de jitter :
     seule une vraie différence de grille compte. */
  useEffect(() => {
    const boite = ref.current?.parentElement;
    if (!boite || typeof ResizeObserver === "undefined") return;
    const cle = () => Math.round(boite.clientWidth / GRAIN) + "×" + Math.round(boite.clientHeight / GRAIN);
    let dernier = cle();
    const ro = new ResizeObserver(() => {
      const k = cle();
      if (k === dernier) return;
      dernier = k;
      setTaille((n) => n + 1);
    });
    ro.observe(boite);
    return () => ro.disconnect();
  }, [monte]);

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d", { alpha: true });
    if (!ctx) return;

    const cssW = cv.parentElement?.clientWidth || 390;
    const cssH = cv.parentElement?.clientHeight || 800;
    const W = Math.max(8, Math.round(cssW / GRAIN));
    /* HT = hauteur totale du canvas (tout l'écran, territoire des cendres) ;
       HF = hauteur du foyer (la simulation de chaleur reste confinée en bas). */
    const HT = Math.max(16, Math.round(cssH / GRAIN));
    const HF = Math.max(8, Math.min(HT - 4, Math.round(height / GRAIN)));
    /* La flamme s'ÉTIRE avec la hauteur demandée : la chaleur perd `cool` par
       rangée, donc diviser `cool` par le facteur d'agrandissement multiplie
       d'autant le nombre de rangées avant extinction — le profil est le même,
       à l'échelle. (Le lit, le cisaillement et la zone basse sont déjà
       exprimés en fraction de HF : ils suivent tout seuls.) */
    const coolEchelle = COOL * (HAUTEUR_REF / Math.max(1, height));
    /* Le lit incandescent suit lui aussi l'échelle : garder 3 rangées sous une
       flamme trois fois plus haute donnait un pied maigre — un feu qui flotte
       au lieu d'être posé. */
    const echelle = Math.max(1, height / HAUTEUR_REF);
    const litRangs = Math.round(LIT_RANGS * echelle);
    /* Rangées FERRÉES au bas de l'écran (voir le socle, plus bas). Fixe en
       PIXELS, pas en fraction : c'est le contact avec le bord du device, il
       doit avoir la même épaisseur quelle que soit la hauteur du foyer. */
    const SOCLE = Math.max(2, Math.round(9 / GRAIN));
    cv.width = W;
    cv.height = HT;
    ctx.imageSmoothingEnabled = false;

    /* La grille de chaleur vit SOL EN BAS (y=0 = sol), dessinée retournée —
       exactement comme la maquette. Elle ne couvre que le foyer (HF). */
    const heat = new Float32Array(W * HF);
    const Hget = (y: number, x: number) => {
      if (x < 0) x = 0;
      if (x >= W) x = W - 1;
      if (y < 0) y = 0;
      if (y >= HF) return 0;
      return heat[y * W + x];
    };

    /* Braises du lit : des foyers qui vivent, dérivent, puis déclinent. */
    type Braise = { x: number; r: number; f: number; derive: number; age: number; vie: number };
    const braises: Braise[] = [];
    const neuveBraise = (): Braise => ({
      x: Math.random() * W,
      r: 3 + Math.random() * 10,
      f: 0.45 + Math.random() * 0.75,
      derive: (Math.random() - 0.5) * 0.05,
      age: 0,
      vie: 90 + Math.random() * 400,
    });
    function majBraises() {
      while (braises.length < N_BRAISES) braises.push(neuveBraise());
      for (let i = braises.length - 1; i >= 0; i--) {
        const b = braises[i];
        b.age++;
        b.x += b.derive;
        if (b.x < -b.r) b.x = W + b.r;
        if (b.x > W + b.r) b.x = -b.r;
        if (b.age > b.vie) braises.splice(i, 1);
      }
    }
    function forceBraises(x: number) {
      let s = 0;
      for (const b of braises) {
        const d = Math.abs(x - b.x);
        if (d > b.r) continue;
        const t = 1 - d / b.r;
        /* extinction progressive en fin de vie, par paliers */
        const declin = b.age > b.vie * 0.7 ? 1 - (b.age - b.vie * 0.7) / (b.vie * 0.3) : 1;
        s += b.f * t * t * declin;
      }
      return s;
    }

    type Cendre = { x: number; y: number; v: number; sway: number; f: number; s: number; age: number; life: number };
    const cendres: Cendre[] = [];
    type Reprise = { x: number; l: number; age: number; f: number };
    const reprises: Reprise[] = [];

    let bi = 0;
    let bAcc = 0;
    let tps = 0;
    let vent = 0;
    let ventCible = 0;

    function pas() {
      tps++;
      bAcc++;
      if (bAcc >= PALIER_PAS) {
        bAcc = 0;
        bi = (bi + 1) % BREATH.length;
      }
      const respire = BREATH[bi];

      majBraises();

      /* vent cohérent : une valeur unique qui dérive lentement */
      if (Math.random() < 0.012) ventCible = (Math.random() * 2 - 1) * VENT;
      vent += (ventCible - vent) * 0.03;

      /* reprises : une colonne s'enflamme brièvement, sans prévenir */
      if (Math.random() < REPRISE)
        reprises.push({ x: (Math.random() * W) | 0, l: 6 + Math.random() * 16, age: 0, f: 0.5 + Math.random() * 0.8 });
      for (let i = reprises.length - 1; i >= 0; i--) {
        if (++reprises[i].age > reprises[i].l) reprises.splice(i, 1);
      }

      /* ── le lit : plusieurs rangées incandescentes, pas une simple ligne */
      const dx1 = tps * 0.004;
      const dx2 = tps * 0.011;
      const RANGS = Math.min(litRangs, HF - 3);
      for (let x = 0; x < W; x++) {
        const n = fbm(x * 0.055 + dx1) * 0.6 + fbm(x * 0.19 + dx2) * 0.4;
        let base = 0.4 + forceBraises(x) * 0.55 + n * BRUIT;
        for (const r of reprises) {
          const dd = Math.abs(x - r.x);
          if (dd < 4) base += r.f * (1 - dd / 4) * (1 - r.age / r.l);
        }
        const v0 = SRC * respire * base;
        for (let y = 0; y < RANGS; y++) {
          const t = 1 - y / RANGS; /* 1 au sol → 0 au sommet du lit */
          /* le sol brûle plein ; le haut du lit s'effiloche déjà */
          let v = v0 * (0.62 + 0.75 * t) * (0.86 + Math.random() * 0.3);
          /* les trous de charbon noir ne s'ouvrent qu'en haut du lit */
          if (y > RANGS * 0.45 && Math.random() < 0.05 + 0.1 * (1 - t)) v *= 0.32;
          /* ── LE SOCLE : le feu est FERRÉ au bas de l'écran.
             Sans ça, les toutes dernières rangées restent tramées (mesuré :
             69 à 77 % de remplissage, en alternance selon la ligne de Bayer)
             et on voit le charbon à travers — c'est le « bloc noir en bas »
             signalé par Patrick, une fois le cadre déjà collé au bas du
             device. On plancher donc la chaleur au-dessus du seuil de trame
             le plus haut (0,97 − BOOST) sur les premières rangées, en
             relâchant progressivement : le pied du feu est plein, son bord
             supérieur se ronge tout seul et rien ne ressemble à une barre. */
          if (y < SOCLE) {
            const force = 1 - y / SOCLE; /* 1 au sol → 0 au sommet du socle */
            v = Math.max(v, 0.86 + 0.3 * force * force);
          }
          heat[y * W + x] = Math.max(0, Math.min(1.6, v));
        }
      }

      /* ── propagation : cisaillement par le vent (échantillon sous-cellule),
         refroidissement variable par colonne, freiné dans la zone basse.
         La respiration RALENTIT aussi le refroidissement (cool / respire). */
      const coolBase = coolEchelle / respire;
      for (let y = RANGS; y < HF; y++) {
        const cis = vent * (y / HF) * 1.7; /* la flamme penche en montant */
        const zone = y / HF;
        const frein = zone < ZONE_BASSE ? FREIN + (1 - FREIN) * (zone / ZONE_BASSE) : 1;
        for (let x = 0; x < W; x++) {
          const sx = x - cis;
          const xi = Math.floor(sx);
          const fr = sx - xi;
          const g = Hget(y - 1, xi) * (1 - fr) + Hget(y - 1, xi + 1) * fr; /* échantillon décalé */
          const v = (Hget(y - 1, xi - 1) + g * 2 + Hget(y - 1, xi + 1) + Hget(y - 2, xi)) / 5.02;
          const varCool = 1 + fbm(x * 0.09 + tps * 0.006) * COOL_VAR; /* certaines colonnes tiennent */
          heat[y * W + x] = Math.max(0, v - coolBase * frein * varCool * (0.5 + Math.random() * 1.0));
        }
      }

      /* ── cendres, émises à la crête des colonnes chaudes. Elles quittent le
         foyer et montent dans TOUT le cadre (le canvas couvre l'écran) : on
         doit les voir voler par-dessus l'interface, jamais coupées. */
      for (let k = 0; k < CENDRES_PAR_PAS; k++) {
        const x = (Math.random() * W) | 0;
        let y = HF - 1;
        while (y > 0 && Hget(y, x) < 0.1) y--;
        if (y > 2)
          cendres.push({
            x,
            y: y + 1,
            v: 0.3 + Math.random() * 0.5,
            sway: 0.4 + Math.random() * 0.8,
            f: 0.05 + Math.random() * 0.12,
            s: Math.random() * 6.283,
            age: 0,
            life: 44 + Math.random() * 80,
          });
      }
      for (let i = cendres.length - 1; i >= 0; i--) {
        const a = cendres[i];
        a.age++;
        a.y += a.v;
        a.x += vent * 0.05; /* les cendres suivent le vent */
        if (a.age > a.life || a.y > HT + 2) cendres.splice(i, 1);
      }
    }

    function dessine() {
      /* Calque TRANSPARENT : seul le feu et les cendres se dessinent — le
         charbon, c'est déjà le fond de l'écran dessous. (Un fond plein ici
         masquerait toute l'interface, puisque le canvas couvre le cadre.) */
      ctx!.clearRect(0, 0, W, HT);

      ctx!.fillStyle = ORANGE;
      for (let y = 0; y < HF; y++) {
        const py = HT - 1 - y;
        const brow = BAYER[py & 3];
        for (let x = 0; x < W; x++) {
          const v = heat[y * W + x];
          if (v <= 0.02) continue;
          /* le boost de densité ABAISSE le seuil de trame */
          if (v > (brow[x & 3] + 0.5) / 16 - BOOST) ctx!.fillRect(x, py, 1, 1);
        }
      }

      for (const a of cendres) {
        const reste = 1 - a.age / a.life;
        /* raréfaction par probabilité de dessin — jamais par opacité */
        if (Math.random() > reste * 0.85) continue;
        const px = (a.x + Math.sin(a.age * a.f + a.s) * a.sway) | 0;
        const py = HT - 1 - (a.y | 0);
        if (py < 0 || py >= HT || px < 0 || px >= W) continue;
        ctx!.fillStyle = Math.random() < 0.72 ? ORANGE : "rgba(255,255,255,.55)";
        ctx!.fillRect(px, py, 1, 1);
      }
    }

    if (animReduced()) {
      for (let i = 0; i < 60; i++) pas();
      dessine();
      return;
    }

    /* Pas de temps fixe avec accumulateur (maquette) : la simulation avance à
       TICK constant quel que soit le rafraîchissement de l'écran. */
    let raf = 0;
    let acc = 0;
    let last = 0;
    function boucle(t: number) {
      raf = requestAnimationFrame(boucle);
      if (!last) last = t;
      acc += t - last;
      last = t;
      let n = 0;
      while (acc >= TICK && n < 4) {
        acc -= TICK;
        pas();
        n++;
      }
      dessine();
    }
    raf = requestAnimationFrame(boucle);
    return () => cancelAnimationFrame(raf);
  }, [height, taille, monte]);

  /* ⚠️ LE LIT DE BRAISES SORT DU CADRE — troisième correctif du même symptôme
     (« les flammes ne sont pas ferrées en bas »), et cette fois on retire la
     CAUSE au lieu de corriger la mesure.
     Les deux tentatives précédentes calculaient la hauteur visible en JS
     (`100dvh`, puis `--app-h` depuis `visualViewport`), donc le feu dépendait
     de la justesse d'une mesure : chaque contexte non prévu (barre d'outils
     qui se rétracte, PWA installée sous la barre d'état) rouvrait le trou.
     Ici il n'y a plus rien à mesurer : `position: fixed; bottom: 0` est la
     primitive que le navigateur garantit lui-même collée au bas visible.
     Le PORTAIL vers <body> n'est pas décoratif — il est obligatoire : à la
     mort la santé vaut 0, donc `.erosion-3.phone-frame` porte une animation
     `transform` PERMANENTE, et tout descendant `fixed` d'un ancêtre transformé
     est ancré à cet ancêtre au lieu du viewport. Rendu dans le cadre, le
     `fixed` aurait donc été silencieusement neutralisé.
     Bénéfice de bord : le feu ne tremble plus avec l'interface pendant les
     secousses — ce qui est aussi plus juste. */
  if (!monte) return null;

  return createPortal(
    <div className={`braises-plein pointer-events-none ${className ?? ""}`} aria-hidden>
      <canvas ref={ref} className="block h-full w-full" style={{ imageRendering: "pixelated" }} />
    </div>,
    document.body
  );
}
