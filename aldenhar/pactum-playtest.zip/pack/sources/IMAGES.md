# Les images, écran par écran

444 fichiers dans `assets/`. Chaque entrée ci-dessous donne l'écran, le fichier affiché, et le texte qu'il accompagne : c'est l'appariement à auditer.

Statuts : **dédiée** = image propre à cet écran · **héritée** = reprise d'un autre écran (le parent est nommé) · **vue générique** = image de marche ou de secours, pas écrite pour cet écran.

## En chemin

### `marche:scene_hameau_dense_c_a`
- Image : `scene_hameau_dense_c_a.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi d'une ruelle du hameau à l'autre, ou quand une des deux directions offertes est le village (le hameau grossit à l'horizon).

### `marche:scene_transition_chemin_murets_b`
- Image : `scene_transition_chemin_murets_b.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi d'une ruelle du hameau à l'autre, ou quand une des deux directions offertes est le village (le hameau grossit à l'horizon).

### `marche:scene_hameau_dense_c`
- Image : `scene_hameau_dense_c.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi d'une ruelle du hameau à l'autre, ou quand une des deux directions offertes est le village (le hameau grossit à l'horizon).

### `marche:scene_landes_liaison_plateau_e_b_a`
- Image : `scene_landes_liaison_plateau_e_b_a.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi en pleine lande, entre deux lieux extérieurs — tirée par la graine du pas : ni la provenance ni la destination ne la choisissent.

### `marche:scene_landes_liaison_fourche_b_e_a`
- Image : `scene_landes_liaison_fourche_b_e_a.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi en pleine lande, entre deux lieux extérieurs — tirée par la graine du pas : ni la provenance ni la destination ne la choisissent.

### `marche:scene_lande_arbres_morts_d_d`
- Image : `scene_lande_arbres_morts_d_d.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi en pleine lande, entre deux lieux extérieurs — tirée par la graine du pas : ni la provenance ni la destination ne la choisissent.

### `marche:scene_lande_generique_3_b_f_a`
- Image : `scene_lande_generique_3_b_f_a.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi en pleine lande, entre deux lieux extérieurs — tirée par la graine du pas : ni la provenance ni la destination ne la choisissent.

### `marche:scene_lande_generique_1_b_d`
- Image : `scene_lande_generique_1_b_d.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi EN RÉSERVE, plus jamais tirée : chacune porte une figure à l'horizon, servie pendant qu'on lit qu'on est seul (correctif 04/09).

### `marche:scene_lande_generique_2_b_b`
- Image : `scene_lande_generique_2_b_b.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi EN RÉSERVE, plus jamais tirée : chacune porte une figure à l'horizon, servie pendant qu'on lit qu'on est seul (correctif 04/09).

### `marche:scene_lande_generique_4_b_f`
- Image : `scene_lande_generique_4_b_f.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi EN RÉSERVE, plus jamais tirée : chacune porte une figure à l'horizon, servie pendant qu'on lit qu'on est seul (correctif 04/09).

### `marche:scene_transition_arrivee_hameau_b`
- Image : `scene_transition_arrivee_hameau_b.png` — vue générique
- Ce que l'écran montre : Écran de marche — servi AU SORTIR DU HAMEAU : le muret d'enceinte vient d'être franchi, le village est dans le dos, et deux routes de lande s'ouvrent devant.

## La Borne Frontière

### `borne-frontiere`
- Image : `scene_borne_frontiere_v2_a.png` — dédiée
- Ce que l'écran montre : Entrée de zone, tout premier écran du jeu. La borne-frontière dressée seule sur le plateau, ses faces gravées, les offrandes à son pied, et le chemin qui s'enfonce au sud dans le noir.
- Texte :
  > La lande s'ouvre sous un crépuscule qui ne tombe pas. Une pierre seule au milieu du plateau, plus haute qu'un homme. À son pied, un tas d'offrandes. À trois pas, un homme immobile, face au sud. Quelque part, une corde grince.
  > Au pied du tas, un mot gravé de frais, la rainure encore claire : « Hier, le pendu de la colline a répondu. »

### `aller-vers-homme`
- Image : `monstre_hesitant_c_b.png` — héritée (de `hesitant-1`)
- Ce que l'écran montre : Action « Marcher vers l'homme immobile » — ce que l'écran montre quand le héros s'en approche.

### `hesitant-1`
- Image : `monstre_hesitant_c_b.png` — dédiée
- Ce que l'écran montre : Un homme immobile face au sud, dos au hameau, planté depuis si longtemps que l'herbe s'est couchée sous lui. La borne dressée à côté de lui.
- Texte :
  > Il ne se retourne pas. Il t'a entendu, pourtant — ses épaules l'ont dit.
  > — « Tu l'entends fort, toi ? » Sa voix est calme, épuisée d'être calme. « Moi, c'est encore bas. Comme des gens qui parlent dans la maison d'à côté. On comprend pas les mots. On comprend juste... qu'on parle de nous. »

### `hesitant-2`
- Image : `monstre_hesitant_b.png` — dédiée
- Ce que l'écran montre : Il parle enfin : tourné de trois-quarts, il désigne la borne du menton sans la regarder. CHANGE : il n'est plus figé face au sud — tête tournée, menton qui pointe la pierre.
- Texte :
  > — « Je calcule. » Il montre la borne du menton, sans la regarder. « Si je rentre, ils me liront sur la figure et je finirai au bout d'une corde qui ne retient rien. Si je passe la pierre, je finis comme ceux qui passent la pierre. »
  > Un temps. « Tu descends. Tu vas voir ce qu'on devient. Alors dis-moi ce que tu choisirais. »

### `hesitant-3`
- Image : `monstre_hesitant_3_v2_a.png` — dédiée
- Ce que l'écran montre : La borne seule au milieu du plateau, la bruyère couchée à son pied, et rien qui dise dans quel sens il est parti. CHANGE : l'homme a DISPARU du cadre — même pierre, vide.
- Texte :
  > Il te laisse partir le premier. C'est important pour lui : que tu ne le voies pas décider.
  > Au bout de vingt pas tu te retournes quand même. La borne est seule au milieu du plateau, et la bruyère couchée garde une trace qui s'efface à cent pas — juste avant l'endroit où elle aurait commencé à dire quelque chose.

## La Chapelle des Cordes

### `chapelle-des-cordes`
- Image : `scene_chapelle_des_cordes_e_d.png` — dédiée
- Ce que l'écran montre : Arrivée à la Chapelle des Cordes, intérieur du hameau. Une nef courte, des dizaines de cordes coupées clouées en rangs le long des murs, du sol au plafond.
- Texte :
  > La chapelle n'a plus de dieu, mais elle est tenue. Des cordes pendent des deux murs, du plafond au sol. Au fond, l'autel est resté debout, plus propre que le reste. Près de l'entrée, un ouvrage de tressage : quelqu'un vit ici.

### `mur-cordes`
- Image : `scene_chapelle_mur_cordes_v3_d_a.png` — dédiée (de `chapelle-des-cordes`)
- Ce que l'écran montre : Action « Remonter le mur des cordes » — ce que l'écran montre quand le héros s'en approche.

### `autel-renverse`
- Image : `scene_chapelle_autel_a_c.png` — dédiée (de `chapelle-des-cordes`)
- Ce que l'écran montre : Action « Tirer la dalle de l'autel » — ce que l'écran montre quand le héros s'en approche.

### `chapelle-des-cordes-2`
- Image : `monstre_veuve_cordes_v2_b_d.png` — dédiée
- Ce que l'écran montre : Événement de la Chapelle : la Veuve aux Cordes, assise, qui refait sans fin le même nœud. Derrière elle, sous verre, la corde coupée sans nom.
- Texte :
  > Elle était là depuis le début — une femme en noir qui refait sans fin le même nœud. « Choisis ton brin. Tout le monde finit par en avoir besoin. » Derrière elle, sous verre : une corde coupée net. La seule qui n'a pas tenu.

### `chapelle-ressortir`
- Image : `scene_chapelle_cloche_sans_battant_c_a.png` — dédiée (de `chapelle-des-cordes-2`)
- Ce que l'écran montre : Action « Ressortir par le côté » — ce que l'écran montre quand le héros s'en approche.

## La Colline aux Gibets

### `colline-aux-gibets`
- Image : `scene_colline_aux_gibets_d_d.png` — dédiée
- Ce que l'écran montre : Arrivée à la Colline aux Gibets, lieu-signature de la zone. La file de potences le long de la crête nue, vue d'en bas en contre-plongée, de plus en plus hautes vers le sommet, les cordes qui balancent.
- Texte :
  > Sur la crête, les potences se suivent comme des bornes, chacune avec son nom et sa date. La dernière dépasse toutes les autres — sa corde est la seule chose neuve à dix lieues. En contrebas, un poteau porte encore son occupant.
  > Sur sa poitrine, un écriteau cloué : un nom, une date de ce mois, et au-dessus, plus gros, un seul mot — FIXÉ. On ne l'a pas pendu pour le tuer. On l'a pendu pour qu'il tienne.

### `lire-nom-grave`
- Image : `scene_colline_pied_grand_gibet_c_b.png` — dédiée (de `colline-aux-gibets`)
- Ce que l'écran montre : Action « Lire le nom gravé » — ce que l'écran montre quand le héros s'en approche.

### `compter-corbeaux`
- Image : `monstre_corbeaux_du_compte_d.png` — dédiée (de `colline-aux-gibets`)
- Ce que l'écran montre : Action « Compter les corbeaux » — ce que l'écran montre quand le héros s'en approche.

### `monter-gibet-vide`
- Image : `scene_colline_gibet_vide_a_c_d.png` — dédiée (de `colline-aux-gibets`)
- Ce que l'écran montre : Action « Monter jusqu'au Gibet Vide » — ce que l'écran montre quand le héros s'en approche.

### `colline-aux-gibets-2`
- Image : `scene_colline_aux_gibets_c.png` — dédiée
- Ce que l'écran montre : Événement de la Colline : au sommet, entre les potences. L'écharde du grand gibet se prélève ici.
- Texte :
  > Le vent tombe d'un coup. Et dans ce calme plat, toutes les cordes de la crête se mettent à bouger — ensemble. Un balancement lent, réglé. Tu pourrais le compter.

### `pendu-qui-parle`
- Image : `monstre_pendu_qui_parle_b_a.png` — dédiée
- Ce que l'écran montre : Arrivée au gardien de zone : le Bailli pendu, qui parle encore. Vu de loin, une silhouette au bout d'une corde, sur un gibet isolé.
- Texte :
  > Au revers de la colline, un gibet à corde longue : le pendu t'arrive à hauteur de regard. Chaîne de fonction au cou, un sceau au poing. À ton approche, il ouvre les yeux.
  > Sur la traverse, une rangée de corbeaux regarde le nord. Un seul est de travers. Celui-là te regarde, toi.
  > Plus bas, un poteau plus court porte un corps de ce mois, un écriteau cloué sur la poitrine : un nom, une date, et au-dessus, plus gros, un seul mot — FIXÉ. On ne l'a pas pendu pour le tuer. On l'a pendu pour qu'il tienne.

### `pendu-qui-parle-2`
- Image : `monstre_pendu_qui_parle_2_b_a.png` — dédiée
- Ce que l'écran montre : Le gardien, à hauteur d'homme. Non-combat : il juge. Son visage de pendu qui parle, le sceau à sa ceinture.
- Texte :
  > « Approche », dit-il, et la corde grince sur chaque syllabe. « Tout ce qui entre dans mes Landes passe en jugement. Toi aussi. » Il sourit. « Surtout toi. »

## La Descente

### `la-descente`
- Image : `scene_falaise_appele_d_d.png` — dédiée
- Texte :
  > La corde s'arrête. Sous tes pieds, quelque chose de plat, de taillé — et très haut au-dessus, le jour par où tu es passé s'est refermé sur lui-même.
  > Tu as traversé les Landes vivant. Peu le font. Devant, le noir n'a pas encore de nom.

## La Maison du Bailli

### `chien-du-bailli`
- Image : `scene_maison_du_bailli_c.png` — dédiée
- Ce que l'écran montre : Arrivée à la Maison du Bailli, murée. Portes et fenêtres bouchées à la pierre, de l'extérieur — on a fermé cette maison depuis la rue.
- Texte :
  > La maison se tient seule à l'ouest du hameau, haute, sans voisine — et murée de l'intérieur. Chaque fenêtre bouchée de pierres posées depuis dedans, en rangs pressés, par quelqu'un qui s'enfermait plus qu'il ne se protégeait. La maison du Bailli. Vide depuis sa corde. Aucun homme ne la garde.

### `chien-du-bailli-2`
- Image : `monstre_chien_du_bailli_b.png` — dédiée
- Ce que l'écran montre : Combat : le Chien du Bailli, qui garde encore une maison où il n'y a plus personne.
- Texte :
  > Le chien se lève du seuil sans aboyer. Gris, trop grand, le poil usé aux endroits d'un harnais qu'il ne porte plus. Son maître pend à la colline — mais l'ordre, lui, n'a jamais été levé. Personne n'entre. Il te le dit d'un seul regard.

## La Mare aux Regards

### `mare-aux-regards`
- Image : `scene_mare_aux_regards_a.png` — dédiée
- Ce que l'écran montre : Arrivée à la Mare aux Regards. Une eau noire parfaitement immobile, la berge piétinée avec deux creux de genoux, des roseaux, aucun vent.
- Texte :
  > L'eau est noire et lente — le seul endroit des Landes que le vent évite.
  > La berge est piétinée en un seul point, tassée par des années de genoux. On ne vient pas ici puiser. On vient s'agenouiller. Le point de berge usé. L'eau. Et dans les roseaux, un reflet de métal.

### `creux-doubles`
- Image : `scene_mare_creux_doubles_v2_c_b.png` — dédiée (de `mare-aux-regards`)
- Ce que l'écran montre : Action « Longer la berge usée » — ce que l'écran montre quand le héros s'en approche.

### `eau-reflet`
- Image : `scene_mare_eau_reflet_v2_b.png` — dédiée (de `mare-aux-regards`)
- Ce que l'écran montre : Action « T\u2019agenouiller et te pencher » — ce que l'écran montre quand le héros s'en approche.

### `mare-aux-regards-2`
- Image : `scene_mare_aux_regards_2_c_d.png` — dédiée
- Ce que l'écran montre : Événement de la Mare : un Renonçant qui vient vérifier son propre reflet, et te trouve là.
- Texte :
  > Ils arrivent à deux. Le premier s'agenouille dans les creux, se penche, et reste penché beaucoup trop longtemps. Le second reste debout derrière lui et ne regarde pas l'eau : il regarde la nuque de l'autre.
  > Personne ne parle. Ce n'est pas une prière — c'est un examen, et il a manifestement une procédure.
  > Quand le premier se relève, il a le visage de quelqu'un qui va rentrer chez lui et fermer ses volets pour toujours. Le second lui met une main sur l'épaule. Ils ne sont pas encore partis.

## La Palissade Sud

### `palissade-sud`
- Image : `scene_palissade_sud_a_b_a.png` — dédiée
- Ce que l'écran montre : Arrivée à la Palissade Sud, seuil de l'Acte II. Une haute palissade de rondins appointés qui ferme l'horizon, un petit portillon, une borne au premier plan.
- Texte :
  > La Palissade barre le plateau : des rondins hauts de deux hommes, un portillon, une guérite éclairée. Derrière, le sol manque — l'air y coule comme une eau froide, remontée d'un trou qu'on ne voit pas d'ici. La Descente. Dans la guérite, un homme t'a vu depuis longtemps.

### `longer-palissade`
- Image : `scene_palissade_rondins_a_d_f.png` — dédiée (de `palissade-sud`)
- Ce que l'écran montre : Action « Longer la palissade » — ce que l'écran montre quand le héros s'en approche.

### `portillon-verrou`
- Image : `scene_palissade_portillon_a_c_f.png` — dédiée (de `palissade-sud`)
- Ce que l'écran montre : Action « Examiner le portillon » — ce que l'écran montre quand le héros s'en approche.

### `homme-guerite`
- Image : `monstre_veilleur_palissade_v2_b.png` — dédiée (de `palissade-sud`)
- Ce que l'écran montre : Action « Aller vers l'homme de la guérite » — ce que l'écran montre quand le héros s'en approche.

### `veilleur-1`
- Image : `objet_lanterne_rouillee_guerite_b_a.png` — dédiée
- Ce que l'écran montre : Le Veilleur dans sa guérite de planches, une lanterne pendue à un clou au-dessus de lui.
- Texte :
  > — « Trois jours ! » Il le crie presque. « Trois jours que j'ai vu personne. Le hameau m'envoie ma soupe par le gamin, et le gamin la pose à vingt pas. Vingt pas ! Comme si veiller la porte, ça s'attrapait. »
  > Il sort de sa niche et te détaille sans gêne.
  > — « Tu descends. Évidemment que tu descends. On vient pas admirer ma palissade. »

### `veilleur-2`
- Image : `objet_lanterne_veilleur_2_c_a.png` — dédiée
- Ce que l'écran montre : Il a décroché sa lanterne et la tend à moitié, suspendue entre vous deux, le visage éclairé par en dessous. CHANGE : la lanterne a quitté son clou et devient le centre de l'image.
- Texte :
  > Il décroche sa lanterne et la soupèse, comme une décision.
  > — « En bas, y a des endroits où le noir mange tout. Ça, ça tient une nuit de plus que les autres. » Il te la tend à moitié. « Elle est à toi. Contre une histoire. Une vraie. Du dehors. »
  > « Raconte-moi la dernière chose que t'as vue. Avant. » Il te demande ta mort. C'est la seule histoire du dehors que tu possèdes encore.

### `veilleur-3`
- Image : `objet_lanterne_veilleur_3_d_b.png` — dédiée
- Ce que l'écran montre : Il note ton passage sur une planche clouée dans sa guérite, sans lever les yeux ; le portillon sud est ouvert derrière lui. CHANGE : le portillon est ouvert et il écrit — la lanterne n'est plus dans ses mains.
- Texte :
  > Il t'ouvre le portillon lui-même. Au moment où tu passes, il note sur une planche : ton passage, ta direction, l'heure.
  > — « Je note tout le monde. Comme ça, si un jour quelqu'un remonte, je saurai qui c'était. » Il sourit à sa planche. « La colonne des retours est toute neuve. »
  > Elle ne l'est pas tout à fait. Tout en haut, une marque — une seule, d'une autre main. Il ne la voit pas : sa planche commence en bas.

### `palissade-sud-2`
- Image : `monstre_palissade_sud_2_d_b.png` — dédiée
- Ce que l'écran montre : Événement de la Palissade : l'Appelé, toujours vu de dos, qui marche vers la Descente sans se retourner.
- Texte :
  > Le Veilleur regarde vers le sud. Devant lui, quelqu'un passe le portillon — d'un pas égal, sans bagage, sans se retourner — et s'éloigne dans la bruyère. « Encore un Appelé », dit le Veilleur. « On ne les rattrape pas. On les compte. »

## Le Champ des Fixés

### `champ-des-fixes`
- Image : `scene_champ_des_fixes_c.png` — dédiée
- Ce que l'écran montre : Arrivée au Champ des Fixés. Des rangées de poteaux plantés dans la lande morte, un écriteau clouté sur chacun, certains encore occupés.
- Texte :
  > Il y a eu un cimetière ici, autrefois : des stèles penchées, usées, dont plus personne ne lit les noms. Entre elles, on a planté des poteaux. Des rangées entières, un nom sur chaque, tous tournés face au nord. Dos au sud. Même morts, surtout morts, on ne les laisse pas regarder par là.
  > Au fond, des poteaux vierges attendent, déjà plantés. Près de l'entrée, la cabane du Fossoyeur.

### `les-rangees`
- Image : `scene_champ_les_rangees_v2_a.png` — dédiée (de `champ-des-fixes`)
- Ce que l'écran montre : Action « Remonter les rangées » — ce que l'écran montre quand le héros s'en approche.

### `poteaux-vierges`
- Image : `scene_champ_poteaux_vierges_c_e.png` — dédiée (de `champ-des-fixes`)
- Ce que l'écran montre : Action « Aller lire les poteaux vierges » — ce que l'écran montre quand le héros s'en approche.

### `tombe-sans-poteau`
- Image : `scene_champ_tombe_manquante_a_d_e.png` — dédiée (de `champ-des-fixes`)
- Ce que l'écran montre : Action « Aller voir le vide dans la rangée » — ce que l'écran montre quand le héros s'en approche.

### `champ-des-fixes-2`
- Image : `monstre_fossoyeur_poteaux_b_a.png` — dédiée
- Ce que l'écran montre : Événement du Champ : le Fossoyeur aux poteaux, qui grave d'avance les noms « dont c'est sûr ».
- Texte :
  > Entre les rangs, un vieil homme redresse un poteau qui penche, avec des gestes de jardinier. Il t'a vu venir de loin — les vivants font un bruit particulier, ici. Il ne s'interrompt pas : il t'attend au travail, comme on attend un outil. « La Colline, c'est la vitrine », dit-il sans qu'on demande. « Ici, c'est l'arrière-boutique. » À ses pieds, un écriteau prêt : un nom, pas de date, et sous le nom un petit signe en forme de plume.

### `pendu-mal-fixe`
- Image : `monstre_pendu_mal_fixe_v3_b.png` — dédiée
- Ce que l'écran montre : Combat, une scène. Le Pendu Mal Fixé : un bras tendu figé en plein geste d'agrippement, la corde trop longue qui laisse les pieds toucher le sol.
- Texte :
  > Un craquement sec dans les rangs — un poteau vient de casser. Le pendu qui le quittait touche terre sur ses pieds, comme s'il n'attendait que ça depuis des années. Sa corde traîne derrière lui, encore nouée au cou.
  > Il avance par à-coups, tiré par des ficelles que personne ne tient. Une Fixation ratée : ni mort ni tenu. Ce qui reste de son visage n'exprime qu'une chose — l'envie féroce d'échanger sa place. Contre la tienne.

## Le Chemin Creux

### `chemin-creux`
- Image : `scene_chemin_creux_coude_b.png` — dédiée
- Ce que l'écran montre : Arrivée au Chemin Creux. Une route encaissée entre deux hauts talus de terre, un ruban de ciel étroit au-dessus, des racines tordues qui sortent des parois.
- Texte :
  > Le chemin s'enfonce entre deux talus ; le ciel devient un ruban. Une charrette penche au premier coude — et dans le creux, quelqu'un vient vers toi. De dos.

### `charrette-embourbee`
- Image : `scene_chemin_charrette_a_d_b.png` — dédiée (de `chemin-creux`)
- Ce que l'écran montre : Action « Fouiller la charrette » — ce que l'écran montre quand le héros s'en approche.

### `talus-empreintes`
- Image : `scene_chemin_talus_a_d_c.png` — dédiée (de `chemin-creux`)
- Ce que l'écran montre : Action « Monter voir le haut des talus » — ce que l'écran montre quand le héros s'en approche.

### `marcheur-rebours`
- Image : `monstre_marcheur_rebours_v2_b_a.png` — dédiée (de `chemin-creux`)
- Ce que l'écran montre : Action « Laisser venir l'homme à reculons » — ce que l'écran montre quand le héros s'en approche.

### `chemin-creux-2`
- Image : `scene_chemin_creux_coude_c_c.png` — dédiée
- Ce que l'écran montre : Événement du Chemin Creux : le coude aveugle. Le talus mange la vue d'un coup — l'endroit exact où il devrait y avoir quelque chose, et où il n'y a rien.
- Texte :
  > Au coude : rien. L'endroit exact où il devrait y avoir quelque chose, et il n'y a rien. Le silence y est plus épais d'un cran.

### `marcheur-1`
- Image : `monstre_marcheur_1_c_b.png` — dédiée
- Ce que l'écran montre : Le Marcheur à rebours avance en marche arrière dans le chemin creux, le regard fixé derrière lui : trente ans qu'il ne montre son dos à rien.
- Texte :
  > Il ne s'arrête pas à ta hauteur. Il ralentit, c'est tout — et te parle en te dépassant, le regard toujours fixé sur le chemin derrière toi.
  > — « Marche pas côté nord du creux. » Pas de bonjour. Ici, les conseils sont les politesses. « Elle longe la crête nord. Toujours. Les empreintes du sud, c'est les vieilles. »

### `marcheur-2`
- Image : `monstre_marcheur_2_v2_c.png` — dédiée
- Ce que l'écran montre : Il s'éloigne à reculons, déjà trois pas plus loin, et te parle par-dessus son épaule ; les talus se resserrent. CHANGE : il n'est plus devant toi, il recule dans la profondeur du chemin.
- Texte :
  > — « Tu veux traverser entier ? » Il est déjà trois pas plus loin. « Alors fais comme moi jusqu'au coude. Après le coude, elle suit plus. Personne sait pourquoi. On va pas lui demander. »

### `marcheur-3`
- Image : `monstre_marcheur_3_v2_b.png` — dédiée
- Ce que l'écran montre : Au coude du chemin il pivote face au nord et lève deux doigts vers toi, juste avant que le talus ne l'avale. CHANGE : vu de dos, et le geste des deux doigts levés.
- Texte :
  > Au coude, il pivote enfin — face au nord, dos au sud — et s'éloigne à reculons vers là d'où tu viens.
  > Juste avant que le talus ne le mange, il lève deux doigts vers toi. Pas un adieu. Un décompte : deux yeux. Il te rappelle d'en garder autant derrière la tête.

### `bete-chemins-creux`
- Image : `monstre_bete_chemins_creux_a.png` — dédiée
- Ce que l'écran montre : Combat, une scène. La Bête des Chemins Creux, qui longe la crête nord au même pas que ce qui marche en bas. On ne la voit qu'en silhouette, au-dessus.
- Texte :
  > L'odeur arrive avant la chose : suint, terre retournée. Une masse se décolle du talus, longue, basse, taillée pour courir entre deux murs de terre. Le creux est son couloir — et tu es dessus.

## Le Hameau des Renonçants

### `serment-hameau`
- Image : `scene_hameau_dense2_b.png` — dédiée
- Ce que l'écran montre : Approche du Hameau des Renonçants, vu de loin. Les toits d'ardoise affaissés au creux du plateau, une seule cheminée qui fume sur vingt, aucun chien qui aboie.
- Texte :
  > Des toits au creux du plateau, une seule cheminée qui fume sur vingt. Tu es encore loin quand tu comprends ce qui cloche : aucun chien n'aboie.

### `hameau-entree-2`
- Image : `scene_hameau_dense2_b.png` — dédiée
- Ce que l'écran montre : La ruelle étroite du hameau : portes marquées à la craie, volets fermés, aucun chien.
- Texte :
  > Une rue en terre battue, des murets. Sur chaque linteau, une croix à la craie — même hauteur, même main. Sur un seuil, une femme immobile regarde une fenêtre, en face.
  > Au bout de la rue, entre deux toits : une silhouette. La forme d'un corbeau. Pas la taille d'un corbeau. Le temps de regarder mieux, le bout de la rue est vide.
  > Sur un muret, un gamin te suit des yeux sans bouger. Plus haut dans la rue, trois hommes ne font pas semblant de faire autre chose.

### `femme-seuil-1`
- Image : `monstre_femme_seuil_1_v3_a.png` — dédiée
- Ce que l'écran montre : Une femme sur le seuil d'une maison basse, châle serré, une croix à la craie sur sa porte. Elle regarde le sud.
- Texte :
  > Quand tu arrives à sa hauteur, elle tressaille. Une seconde — moins — son visage s'ouvre, et tu vois ce qu'elle était avant : quelqu'un qui attendait quelqu'un.
  > Puis ça se referme. « Non. Tu marches pas comme lui. »
  > Elle resserre son châle. « Mon fils est parti par là. » Elle ne montre pas la direction — personne ici ne montre le sud avec la main. « Il entendait plus ce que je disais, à la fin. Il entendait autre chose. »

### `femme-seuil-2`
- Image : `monstre_femme_seuil_2_c.png` — dédiée
- Ce que l'écran montre : Elle a sorti la main de sous son châle et tend une mèche de cheveux nouée d'un fil, bras à moitié tendu, sur le même seuil. CHANGE : le bras tendu et l'objet offert dans sa main.
- Texte :
  > « Tu descends, toi aussi. Ça se voit. Vous avez tous le même pas. » Elle fouille sous son châle et en tire quelque chose qu'elle tient serré.
  > « Si tu le croises. S'il reste quelque chose à croiser. »
  > Une mèche de cheveux, nouée d'un fil. « Tu lui donnes. Il saura. »

### `femme-seuil-3`
- Image : `monstre_femme_seuil_3_v2_a.png` — dédiée
- Ce que l'écran montre : Elle a repris sa place sur le seuil, mains vides, et regarde le sud — de la rue, rien ne dit qu'elle a parlé à quelqu'un. CHANGE : de nouveau immobile et les mains vides.
- Texte :
  > Elle a déjà repris sa place sur le seuil quand tu repars. De la rue, on ne voit pas qu'elle a parlé à quelqu'un. On ne voit qu'une femme qui regarde le sud.
  > Ce que tu emportes ne pèse rien. C'est la promesse qui pèse.

### `hameau-entree-3`
- Image : `monstre_hameau_entree_3_v2_b_c.png` — dédiée
- Ce que l'écran montre : Trois hommes en travers de la rue, pas armés : un bâton de marche à la main, une fourche posée contre le mur, à portée sans être brandie.
- Texte :
  > Ils sont trois au milieu de la rue. Pas armés — une fourche à portée, sans être brandie. Le vieux du centre : « On ne te chasse pas. Mais tu descends, ça se voit à ton pas. » Derrière lui, on rentre un enfant.

### `hameau-entree-4`
- Image : `scene_hameau_trois_aubes_v2_c.png` — dédiée
- Ce que l'écran montre : La paume ouverte et vide du vieux, tendue à hauteur de poitrine pour qu'on la regarde — on jure sur rien.
- Texte :
  > Le vieux t'attend sur un muret, paume ouverte — vide. Ici on jure sur rien. « Trois choses, et tu dors sous un toit : tu ne parles pas aux pendus, tu ne regardes pas le sud plus qu'il ne faut, et à la troisième aube, tu choisis. »

### `hameau-entree-5`
- Image : `scene_hameau_entree_5_v2_a.png` — dédiée
- Ce que l'écran montre : La rue qui s'ouvre devant toi, et les volets qui se ferment un par un, un peu en avance sur ton pas.
- Texte :
  > Ils s'écartent juste assez pour que tu passes sans toucher personne — c'est calculé. Devant toi, les volets se ferment un peu en avance sur ton pas.

### `hameau-halte-1`
- Image : `scene_landes_hameau_ruelle_c_b.png` — dédiée
- Ce que l'écran montre : Le vieux t'a trouvé dans la ruelle et se tient à deux pas, calme, sans barrer le passage.
- Texte :
  > Le vieux te trouve avant que tu ne le cherches. C'est comme ça, ici : on sait toujours où tu es.
  > — « Tu pars demain. » Ce n'est pas une question. « Personne ne marche vers le sud de nuit. Même toi. »
  > Il ne t'invite pas chez lui. Personne n'invite personne. Il te mène à la grange, au bout de la rue — la seule porte du hameau qui n'a pas de marque à la craie. Pas encore.

### `hameau-halte-2`
- Image : `scene_landes_hameau_grange_b_d.png` — dédiée
- Ce que l'écran montre : Intérieur de grange, la nuit : une lanterne posée au sol, la paille, la barre de porte posée DEHORS, des bâtons de comptage sur les poutres.
- Texte :
  > De la paille propre, une couverture qui a servi, une lampe qu'on te laisse — la mèche est courte, calculée pour s'éteindre seule.
  > — « On te rouvre à l'aube. » Le vieux pose la main sur la porte. « C'est pas contre toi. »
  > La porte se ferme. Puis le bruit que tu attendais sans le savoir : une barre qu'on pose. Dehors.

### `examiner-grange`
- Image : `scene_hameau_grange_poutres_a_d.png` — dédiée (de `hameau-halte-2`)
- Ce que l'écran montre : Action « Fouiller la grange à la lampe » — ce que l'écran montre quand le héros s'en approche.

### `hameau-halte-3`
- Image : `scene_hameau_halte_3_c.png` — dédiée
- Ce que l'écran montre : La grange dans le noir, vue depuis la paille : sous la porte fermée, une bande de lumière que des pieds coupent en passant. CHANGE : la lanterne est éteinte, il ne reste que la fente sous la porte.
- Texte :
  > Le hameau ne dort pas comme un village. Pas de rires, pas de disputes, pas d'enfant qui pleure. Juste des pas, parfois, qui font une ronde que personne n'a annoncée.

### `hameau-halte-4`
- Image : `monstre_hameau_halte_4_v2_c.png` — dédiée
- Ce que l'écran montre : L'aube grise, la porte relevée : le vieux seul, un quignon de pain dur tendu vers toi, le regard ailleurs. CHANGE : lumière de petit matin, la barre est levée, il tend quelque chose.
- Texte :
  > La barre se soulève au premier gris. Le vieux, seul. Il te tend un quignon dur et ne dit rien pendant que tu manges.
  > Tu regardes la barre pendant qu’il la repose contre le mur. Tu croyais qu’elle t’enfermait, ou qu’elle te protégeait. Ni l’un ni l’autre : elle indiquait que la grange était occupée.
  > — « Aujourd'hui, on fixe personne. » Il regarde ailleurs. « Alors pars pendant que c'est vrai. »

### `hameau-halte-5`
- Image : `scene_hameau_halte_5_v2_c.png` — dédiée
- Ce que l'écran montre : Le portillon sud, ouvert par le plus jeune. Les deux escortes marchent à un pas de distance de chaque côté ; le vieux reste en arrière. CHANGE : on est dehors, au portillon — plus dans la grange.
- Texte :
  > Ils sont deux à marcher avec toi jusqu'à la Palissade. Pas devant, pas derrière : à côté, à un pas de distance — l'escorte de quelqu'un qu'on ne touche pas.
  > Au portillon sud, le plus jeune ouvre. Le vieux reste en arrière. C'est lui qui parle, pourtant, au moment où tu passes :
  > — « Si tu l'entends... » Il cherche ses mots. Il les trouve : « Réponds pas. C'est tout ce qu'on sait. C'est tout ce qu'on a jamais su. »

### `hameau-halte-dehors`
- Image : `scene_hameau_nuit_dehors_v2_c.png` — dédiée
- Ce que l'écran montre : Variante de Halte pour qui a refusé le Serment : la nuit dehors, contre un muret, aucune porte ouverte.
- Texte :
  > Aucune porte, aucune grange. Tu dors contre un muret, côté nord — d'instinct.
  > La nuit des Landes n'attaque pas. Elle compte. Chaque heure a son bruit : la corde, les pas, le chant du sud. Au matin, tu n'es pas reposé — ton nom est à l'inventaire, comme un outil.

### `proces-du-heros`
- Image : `scene_proces_du_heros_v4_d_b.png` — dédiée
- Ce que l'écran montre : Scène de déroutage au dernier palier de Soupçon : le hameau te juge. Les trois bancs pleins, tous les visages tournés vers toi, la chaire vide.
- Texte :
  > Ils ne te courent pas après — ils t'attendent au tournant du muret, le hameau entier, dans ce silence de gens qui ont déjà décidé. On ne te touche pas. On marche autour de toi, jusqu'au Petit Tribunal.
  > La Doyenne laisse le silence retomber, puis referme le cahier de l'Écrivain d'une main. L'Ordonnance de la Fixation s'applique. À moins que tu ne parles mieux qu'eux.

## Le Marché Muet

### `marche-muet`
- Image : `scene_marche_muet_c.png` — dédiée
- Ce que l'écran montre : Arrivée au Marché Muet, à l'intérieur du hameau. Des étals sans marchands, des marchandises posées et personne pour les vendre.
- Texte :
  > Un marché sans un cri : des étals de trois fois rien, des marchands qui négocient par gestes. Renoncer à la parole est le renoncement le moins cher.

### `marche-muet-2`
- Image : `monstre_colporteur_c_c.png` — dédiée
- Ce que l'écran montre : Événement du Marché : le Colporteur, le seul qui parle encore, et le Rebouteux derrière lui.
- Texte :
  > Au bout de la rangée, le Colporteur te regarde venir — et te reconnaît. C'est impossible. Il te fait signe quand même. À l'étal voisin, le Rebouteux écrase des feuilles sans lever la tête ; son tabouret libre est tourné vers toi.

## Le Moulin Arrêté

### `campement`
- Image : `scene_moulin_campement_a.png` — dédiée
- Ce que l'écran montre : Arrivée au Moulin Arrêté — c'est le lieu de repos de la zone. Le moulin garde ses quatre ailes en croix devant le soleil bas, immobiles quel que soit le vent, la porte entrebâillée.
- Texte :
  > Le moulin a gardé ses quatre ailes, ouvertes en croix sur le couchant. Le vent couche la bruyère jusqu'à son pied — et elles ne bougent pas. Leur ombre non plus. Sur la crête, à cinquante pas, une ligne de faîtage s'interrompt net, sans raison.
  > La porte est entrouverte. Pas défoncée : entretenue.

### `entrer-moulin-elle`
- Image : `monstre_petite_fixee_c.png` — dédiée (de `campement`)
- Ce que l'écran montre : Action « Entrer » — ce que l'écran montre quand le héros s'en approche.

### `entrer-moulin`
- Image : `scene_moulin_interieur_a_e_b.png` — dédiée (de `campement`)
- Ce que l'écran montre : Action « Entrer » — ce que l'écran montre quand le héros s'en approche.

### `campement-2`
- Image : `scene_moulin_interieur_a_d.png` — dédiée
- Ce que l'écran montre : Événement du Moulin : la garde, ou le sommeil. Le lit de bruyère tassé, refait de frais, les marques de comptage à hauteur d'enfant sur la pierre.
- Texte :
  > Par la lucarne, le crépuscule ne bouge pas. On dit qu'une fille dort ici, parfois — la seule pendue qui se soit relevée. Le lit de bruyère garde une forme légère, comme un creux encore tiède.

## Le Petit Tribunal

### `petit-tribunal`
- Image : `scene_petit_tribunal_b_g.png` — dédiée
- Ce que l'écran montre : Arrivée au Petit Tribunal. Une salle basse de pierre servant de salle d'audience : trois bancs de bois face à une haute chaire, une feuille de règles clouée au mur.
- Texte :
  > La salle basse aux trois bancs sent le suif froid. La chaire fait face à la porte — ici, même l'entrée est un interrogatoire.
  > Au mur, une feuille clouée. Sur la chaire, un livre ouvert. Les bancs, eux, gardent leurs traces.

### `mur-ordonnance`
- Image : `scene_tribunal_ordonnance_a_d_e.png` — dédiée (de `petit-tribunal`)
- Ce que l'écran montre : Action « Lire la feuille clouée au mur » — ce que l'écran montre quand le héros s'en approche.

### `chaire-registre`
- Image : `scene_tribunal_chaire_a_d_c.png` — dédiée (de `petit-tribunal`)
- Ce que l'écran montre : Action « Monter à la chaire » — ce que l'écran montre quand le héros s'en approche.

### `les-bancs`
- Image : `scene_tribunal_bancs_a_d_b.png` — dédiée (de `petit-tribunal`)
- Ce que l'écran montre : Action « Passer la main sur les bancs » — ce que l'écran montre quand le héros s'en approche.

### `petit-tribunal-2`
- Image : `monstre_ecrivain_public_e_a.png` — dédiée
- Ce que l'écran montre : Événement du Tribunal : l'Écrivain public, qui entre, te voit à la chaire, et se met à copier sans lever les yeux.
- Texte :
  > La porte s'ouvre derrière toi. Un petit homme sec entre, plume et encrier serrés contre lui — et se fige net en te voyant à la chaire. Une seconde entière. Assez pour que vous sachiez tous les deux qu'il t'a vu.
  > Puis il fait comme si de rien : il s'installe au banc des témoins, ouvre son cahier, et se met à copier. L'Écrivain public. Il ne lève pas les yeux — mais sa plume, elle, a ralenti.

## Le Puits Condamné

### `puits-condamne`
- Image : `scene_puits_condamne_v2_b_f.png` — dédiée
- Ce que l'écran montre : Arrivée au Puits Condamné. Un puits fermé par des planches clouées en croix, par-dessus, des pierres empilées.
- Texte :
  > Un puits condamné de frais : planches neuves, chaînes, blocs de meule empilés. Tout le hameau tombe en ruine — ça, on l'entretient. Et dessous, ça cogne. Trois coups, une pause. Trois coups. Poli, comme on frappe à une porte qu'on va vous ouvrir.

### `puits-condamne-2`
- Image : `monstre_mains_du_puits_b_b.png` — dédiée
- Ce que l'écran montre : Événement du Puits (scène chronométrée) : les Mains du Puits, qui sortent entre les planches.
- Texte :
  > À ton approche, le rythme change. Plus vite, plus fort — plus personne de poli. Le cadenas saute sur son anneau à chaque série, et les planches, au dernier coup, ont bougé. Franchement bougé.

## Le Verger Noir

### `verger-noir`
- Image : `scene_verger_noir_e_f.png` — dédiée
- Ce que l'écran montre : Arrivée au Verger Noir. Des arbres noirs tordus plantés en rangs, des fruits gris et lourds sur les branches, une vieille souche au premier plan.
- Texte :
  > Des arbres fruitiers plantés en rangs — le seul ordre volontaire des Landes hors du hameau. Ils ont poussé, ils ont des branches, des feuilles noires, et des fruits. C'est pire que s'ils étaient morts.
  > Les rangs et leurs fruits. La souche du premier arbre, au bout. Et deux silhouettes penchées, tout au fond, qui bêchent sans lever la tête.

### `gouter-fruit`
- Image : `scene_verger_fruits_cendre_v2_c.png` — dédiée (de `verger-noir`)
- Ce que l'écran montre : Action « Décrocher un fruit et mordre » — ce que l'écran montre quand le héros s'en approche.

### `epoux-verger`
- Image : `monstre_epoux_verger_b_b.png` — dédiée (de `verger-noir`)
- Ce que l'écran montre : Action « Remonter vers les deux du fond » — ce que l'écran montre quand le héros s'en approche.

### `verger-noir-2`
- Image : `scene_verger_noir_2_v2_b.png` — dédiée
- Ce que l'écran montre : Événement du Verger : le fruit qui tombe encore chaud.
- Texte :
  > Un fruit tombe, derrière toi. Sans vent, sans oiseau.
  > Quand tu le ramasses, il est encore chaud — comme une chose qui vient de cesser d'essayer.

### `epoux-1`
- Image : `monstre_epoux_verger_b_b.png` — dédiée
- Ce que l'écran montre : Les Époux, deux silhouettes redressées, tournées vers toi entre les rangs du verger noir sans se parler.
- Texte :
  > La femme lève la tête la première, sans lâcher sa bêche. Elle ne sursaute pas — plus rien ne les surprend, ici.
  > — « C'est le onzième verger. » Elle le dit avant toute autre chose, comme on donne son nom. « Les dix premiers ont donné des fruits de cendre. Celui-là aussi. Le douzième, on verra. »
  > L'homme, lui, ne se redresse pas. Il n'a pas cessé de compter à voix basse pour autant, et il ne te regarde pas.

### `epoux-2`
- Image : `monstre_epoux_2_c.png` — dédiée
- Ce que l'écran montre : L'un des deux s'est redressé entre les rangs et te tend les mains ouvertes et vides, en demande. CHANGE : ils ne sont plus tous deux courbés — l'un est debout, face à toi.
- Texte :
  > — « Tu viens du dehors. » Ce n'est pas une question : c'est une prière déguisée en constat. « Il te reste forcément quelque chose du dehors. N'importe quoi. Une graine, un bout de vrai bois, une chose qui a poussé sous le vrai soleil. On le planterait. »
  > Rien de ce que tu portes n'a poussé sous un soleil, vrai ou faux. Tu arrives ici comme tout le monde y arrive — les mains vides et mort.

### `epoux-3`
- Image : `monstre_epoux_verger_b_b.png` — dédiée
- Ce que l'écran montre : Les deux silhouettes de nouveau courbées, vues de dos, qui s'éloignent entre les rangs. CHANGE : on les quitte — vus de dos, repris au travail.
- Texte :
  > Ils se remettent au travail avant que tu sois sorti des rangs — le onzième verger n'attend pas.
  > Longtemps après, tu entends encore le compte à voix basse, régulier comme une corde qui grince : c'est le bruit que fait l'espoir quand il refuse de savoir.

## Sans lieu fixe

### `tour-de-pierre`
- Image : `scene_borne_gravures_a_d.png` — héritée (de `demo-borne-geste`)
- Ce que l'écran montre : Action « Faire le tour de la pierre » — ce que l'écran montre quand le héros s'en approche.

### `fossoyeur-trou-1`
- Image : `monstre_fossoyeur_trou_1_d_a.png` — dédiée
- Texte :
  > Il taille un écriteau sur ses genoux, au bout d’une rangée. Le nom qu’il grave n’a pas encore de date. Sous le nom, il a déjà creusé un petit signe en forme de plume, machinalement, comme on trace une croix avant de savoir pour qui.
  > « Je grave à l’avance ceux dont c’est sûr. Ça fait gagner du temps le jour venu. » Le couteau ne s’arrête pas. « Comment je sais ? Je regarde les toits. Six corbeaux sur la même maison, je taille. Je me trompe jamais. »

### `fossoyeur-trou-2`
- Image : `scene_champ_poteau_retire_d_e.png` — dédiée
- Texte :
  > « Y avait un poteau là. On l’a enlevé. »
  > Tu attends.
  > « Je l’ai enlevé moi-même. Un matin. Je m’en souviens très bien : la terre, le poids, le trou après. »
  > Un temps beaucoup trop long.
  > « Et je saurais pas te dire pourquoi. C’est la seule chose de ma vie dont je sais pas la raison. »

### `fossoyeur-trou-3`
- Image : `monstre_fossoyeur_poteaux_a.png` — dédiée
- Texte :
  > Il pose l’écriteau fini contre sa jambe, face contre terre, pour qu’on n’en lise pas le nom.
  > « Va-t’en. Reviens quand t’auras une date à me donner. »

### `femme-savoir-1`
- Image : `monstre_femme_seuil_1_v3_a.png` — héritée (de `femme-seuil-1`)
- Texte :
  > Elle est à sa place, le regard au sud. Mais quand tu passes à sa hauteur, sa main t’attrape la manche.
  > Elle ne t’a jamais touché. Personne ici ne touche personne.

### `femme-savoir-2`
- Image : `monstre_femme_seuil_2_c.png` — héritée (de `femme-seuil-2`)
- Texte :
  > « Elle est encore là ? À l’ouest. La petite. » Elle se corrige toute seule, plus bas : « Enfin. On avait le même âge. »
  > Ses yeux cherchent les tiens et n’en sortent plus. « Dis-le-moi. Dis-le juste une fois. »

### `femme-savoir-3`
- Image : `monstre_femme_seuil_3_v2_a.png` — héritée (de `femme-seuil-3`)
- Texte :
  > « Quarante ans que je le vois et que je le dis pas. » Elle rit — un son épouvantable. « J'avais huit ans. On était trois sur le muret. Les deux autres sont morts vieux en jurant qu'ils avaient rien vu. »
  > Elle te lâche et reprend sa position, face au sud.
  > « Va-t'en. Et redis-le à personne. Moi je peux plus partir. Toi tu peux encore — pars avant qu'ils te comptent. »

### `gamin-murets-1`
- Image : `monstre_gamin_murets_b_b.png` — dédiée
- Texte :
  > Il aligne des cailloux par taille. Le premier habitant qui ne se méfie pas. « T’es le nouveau. T’as combien de corbeaux ? »
  > Il n’attend pas la réponse et compte sur ses doigts. « Trois avant toi cette année. Deux sont ressortis. »
  > Il désigne du menton la crête des murets, vers le sud. « Y a le chemin, et y a les murets. Le chemin, il fait le tour de tout. Les murets, non. »

### `gamin-murets-2`
- Image : `scene_murets_vers_sud_c.png` — dédiée
- Texte :
  > Le muret repart vers le sud, à hauteur de hanche, en pierre sèche posée sans mortier. On voit à l’usure du sommet que quelqu’un y marche tous les jours, et que ce quelqu’un est petit.

### `gamin-murets-3`
- Image : `monstre_gamin_caillou_c.png` — dédiée
- Texte :
  > « Moi j’en ai zéro », dit-il en revenant à ses cailloux. « Ma mère en a deux. Elle sait pas. Faut pas lui dire, elle a peur pour rien. »
  > Il fouille dans sa poche et te tend une pierre plate, grise, polie comme un galet de rivière. Il n’y a pas de rivière dans les Landes. « C’est la petite de l’ouest qui me l’a donnée. »

### `gamin-murets-4`
- Image : `monstre_gamin_depart_d_a.png` — dédiée
- Texte :
  > « Ma mère dit que j’invente. Le rebouteux dit que j’invente. Tout le monde dit que j’invente. » Il te regarde enfin, droit. « Mais le caillou, il est vrai. Tu le tiens. »
  > Il redescend du muret et ramasse ses pierres une par une, dans l’ordre. « Si tu la vois, dis-lui merci pour le caillou. J’ai oublié la dernière fois. »

### `hameau-accueil-volet`
- Image : `scene_hameau_accueil_volet_e_b.png` — dédiée
- Texte :
  > La rue est vide. Pas déserte — vide : une porte qui bat, un seau de travers, du lait qui n'a pas séché. Tout le monde vient de rentrer, et vite.
  > Un volet s'entrouvre de deux doigts. Une voix de femme, basse, aucun visage derrière : — « Ne touche pas les portes marquées. Ne réponds pas si on t'appelle par ton nom. Va au muret. »
  > Le volet ne se referme pas. Elle attend quelque chose de toi.

### `hameau-accueil-mur`
- Image : `scene_hameau_accueil_mur_b_c.png` — dédiée
- Texte :
  > Personne dans la rue. Le pignon de la grange est couvert de craie jusqu'à hauteur d'homme : des noms, deux colonnes serrées, plusieurs mains. Chaque nom a sa date. Sauf les sept derniers : à la place, une croix.
  > Un gamin accroupi tout en bas ajoute une ligne, te voit, et s'éloigne très vite sans courir — ce qui est pire. Ce qu'il vient d'écrire n'est pas un nom. C'est : « un qui descend ».

### `hameau-accueil-enfant`
- Image : `scene_hameau_accueil_enfant_d_a.png` — dédiée
- Texte :
  > Ils ont envoyé un gosse. Huit ans, planté au milieu de la rue, les mains dans le dos. Aucun adulte — et tous les volets entrouverts de deux doigts.
  > Il récite, avec les silences qu'on lui a fait répéter : — « Est-ce que tu dors la nuit ? Est-ce que tu as compté quelque chose aujourd'hui ? Est-ce qu'on t'a appelé par ton nom depuis que tu es descendu ? »
  > Il ne comprend pas ce qu'il demande. Les autres, si.

### `hameau-accueil-table`
- Image : `scene_hameau_accueil_table_b_d.png` — dédiée
- Texte :
  > Une table au milieu de la rue. Une seule. Un tabouret, un bol, une cuillère posée bien droite — et le tout tourné vers le côté par où tu arrives, comme on dresse un couvert pour quelqu'un dont on connaît l'heure.
  > Le bol fume encore. Il n'y a personne dehors, et pourtant on t'a entendu venir de loin.
  > Ce n'est pas de l'hospitalité. C'est un péage : ici, on mange avant de savoir à quoi ça engage.

### `hameau-accueil-cloche`
- Image : `scene_hameau_accueil_cloche_c_f.png` — dédiée
- Texte :
  > Tu entres dans la rue au moment où un homme se met à courir. Pas vers toi : vers la corde qui pend le long de la chapelle.
  > Une vieille l'atteint avant lui. Elle pose la main sur la corde, c'est tout, et l'homme s'arrête net comme s'il se réveillait.
  > Le village sort quand même. Une dizaine sur les seuils, pour un tocsin qui n'a pas sonné. Et c'est toi qu'ils regardent.

### `hameau-accueil-depart`
- Image : `scene_hameau_accueil_depart_b_f.png` — dédiée
- Texte :
  > On ne t'arrête pas : on est occupé. Au milieu de la rue, une charrette à moitié chargée — un coffre, deux paillasses roulées, une porte. Ils emportent leur porte.
  > Les autres regardent. Personne n'aide. Personne ne dit au revoir non plus : ils se tiennent sur leurs seuils, bras croisés, et attendent que ça finisse.
  > Un homme sangle une malle, te voit, et ne s'interrompt même pas. « Vous descendez, nous on monte. Chacun son sens. »

### `temoin-toit`
- Image : `scene_temoin_grange_toit_v2_c.png` — dédiée
- Texte :
  > Les voix s’éloignent. Le silence revient, et il est plus épais qu’avant.
  > Puis le toit travaille. Une poutre plie — pas le craquement du bois qui refroidit : le bruit d’un bois qui porte quelque chose. La poussière tombe en fil régulier entre deux planches, juste devant toi.
  > Quelque chose remonte le faîtage. Ça s’arrête au-dessus de la porte. Ça reste.
  > Dehors, les corbeaux ne bougent pas. C’est ça, le pire : ils ne s’envolent pas.

### `temoin-toit-connu`
- Image : `scene_temoin_grange_toit_v2_c.png` — dédiée
- Texte :
  > Les voix s’éloignent. Tu attends, parce que tu sais maintenant qu’il y a quelque chose à attendre.
  > La poutre plie à la même heure, au même endroit. Le poids remonte le faîtage, s’arrête au-dessus de la porte, et reste. Ce n’est plus une découverte : c’est un horaire.

### `renoncer`
- Image : `scene_renoncer_v2_c_f.png` — dédiée
- Texte :
  > Tu ne passes pas le portillon. Tu t'assieds sur la pierre du seuil, du côté du hameau.
  > Personne ne discute. Le vieux hoche la tête une fois. Le lendemain, on te donne une porte — une vraie, avec un loquet. Ce n'est pas rien, ici, une porte.
  > Puis tu cesses de compter les jours. Un matin, la croix de craie de la Femme au Seuil a disparu de son bois. Personne n'explique. Tu ne demandes pas.

### `hameau-maison-1`
- Image : `scene_hameau_maison_sans_fumee_a_b.png` — dédiée
- Texte :
  > La porte est basse, le bois gris. Sur le montant, une croix de craie qu'on a frottée aux trois quarts : quelqu'un a commencé à l'effacer et personne n'a osé finir.
  > Les volets sont cloués. Pas barrés — cloués, de l'intérieur, et les têtes de clou sont tordues. La serrure, elle, est vieille et simple : trois goupilles, du fer qui a beaucoup servi.

### `hameau-maison-2`
- Image : `scene_hameau_maison_table_a_a.png` — dédiée
- Texte :
  > La table est mise pour deux et n'a jamais été desservie. La poussière est régulière sur tout — sur les écuelles, sur le pain devenu pierre, sur les deux tabourets tirés du même côté.
  > Aux patères, deux manteaux. Personne n'est parti d'ici en emportant quoi que ce soit.

### `hameau-maison-3`
- Image : `scene_hameau_maison_aube_a_c.png` — dédiée
- Texte :
  > En te relevant, tu vois le dessous de la table. Quelqu'un s'est couché là-dessous pour écrire à la craie, à l'envers : des bâtons, par paquets de quatre. Quatre. Quatre. Quatre.
  > La dernière ligne en compte cinq. Ils ont dû croire que c'était fini.
  > Quand tu ouvres, le vieux est assis sur la marche d'en face. Il ne s'est pas levé pour te surprendre : il a attendu que tu sortes. — « C'était la maison des Rouel. Personne n'y dort. » Il ne dit pas : personne n'a le droit.

### `temoin-ruelle`
- Image : `monstre_temoin_ruelle_v5_d.png` — dédiée
- Texte :
  > Aucune porte, aucune grange. Tu dors contre un muret, côté nord — sauf que tu ne dors pas : tu sais ce qui marche sur les toits.
  > Au bout de la ruelle, quelque chose traverse. Sans bruit, et c'est ça qui te fige : trois têtes de haut.
  > Du tissu noir qui suit avec un temps de retard. Dessous, une seconde de trop, quelque chose qui n'était pas des jambes. Puis plus rien : sur les deux toits, les corbeaux te regardent, toi.

### `menace-retour-meute`
- Image : `monstre_meute_grise_c.png` — dédiée
- Texte :
  > Tu les retrouves parce qu'elles l'ont voulu. Le terrain est à découvert, sans un muret, sans un creux — c'est elles qui ont choisi l'endroit, et elles ont marché ton pas pendant que tu choisissais tout le reste.
  > Cinq silhouettes couleur de bruyère morte, déjà déployées. La route que tu n'as pas prise t'a suivi.

### `menace-retour-bete`
- Image : `monstre_bete_chemins_creux_a.png` — héritée (de `bete-chemins-creux`)
- Texte :
  > Le chemin s'enfonce entre deux talus que tu n'avais pas vus venir — et tu comprends trop tard que ce n'est pas le chemin qui s'est creusé. C'est elle qui l'a creusé, cette nuit, sur ta route.
  > Le souffle est déjà là, au-dessus, réglé sur ton pas depuis longtemps. Tu ne l'avais pas semée. On ne sème pas ce qui compte les pas.

### `troupeau-sans-berger`
- Image : `monstre_troupeau_sans_berger_a.png` — dédiée
- Texte :
  > Des bêtes broutent la bruyère morte au creux du vallon — un troupeau entier, sans personne. Elles ne s’écartent pas quand tu approches : elles lèvent la tête, te regardent une seconde, et se remettent à brouter.
  > C’est ce détail qui te dérange le plus. Elles n’ont pas appris à se méfier.

### `compter-troupeau`
- Image : `monstre_troupeau_compte_c_b.png` — dédiée (de `troupeau-sans-berger`)
- Ce que l'écran montre : Action « Lire les marques d\u2019oreille » — ce que l'écran montre quand le héros s'en approche.

### `troupeau-sans-berger-2`
- Image : `monstre_troupeau_brebis_v2_b.png` — dédiée
- Texte :
  > Une brebis s’écarte du groupe et marche droit vers le nord-est, s’arrête, revient. Puis recommence. Cinq fois pendant que tu la regardes.
  > Elle refait un trajet. Elle attend au bout de quelque chose qui n’arrive plus.
  > Dans cette direction, à un quart d’heure de marche, il y a le Champ des Fixés.

### `tour-de-guet`
- Image : `scene_tour_de_guet_a.png` — dédiée
- Ce que l'écran montre : Arrivée à la Tour de Guet effondrée, à l'intérieur du hameau. Une tour tronquée net à mi-hauteur, ses pierres empilées en tas régulier au pied.
- Texte :
  > La tour n'a plus de sommet. Elle s'arrête net à mi-hauteur, sur une bouche de pierres arrachées, et le reste s'est répandu autour du pied. Un seul endroit fait exception : quelques blocs posés les uns sur les autres, à hauteur de siège, usés par-dessus.
  > L'escalier intérieur tient encore sur trois volées. Au-delà, il monte vers rien.

### `monter-guet`
- Image : `scene_tour_escalier_vers_rien_c_a.png` — dédiée (de `tour-de-guet`)
- Ce que l'écran montre : Action « Monter jusqu'à la rupture » — ce que l'écran montre quand le héros s'en approche.

### `pierres-rangees`
- Image : `scene_tour_pierres_rangees_b_a.png` — dédiée (de `tour-de-guet`)
- Ce que l'écran montre : Action « Retourner les pierres du pied » — ce que l'écran montre quand le héros s'en approche.

### `meurtriere-sud`
- Image : `scene_tour_meurtriere_sud_b_d.png` — dédiée (de `tour-de-guet`)
- Ce que l'écran montre : Action « Fouiller la meurtrière du sud » — ce que l'écran montre quand le héros s'en approche.

### `tour-de-guet-2`
- Image : `monstre_guetteur_tour_d_a.png` — dédiée
- Ce que l'écran montre : Événement de la Tour : le Guetteur sans tour, debout de dos sur le tas de pierres, en manteau de guet, une corne au côté, il regarde le sud. CHANGE : c'est un portrait de l'homme, plus le plan large de la tour.
- Texte :
  > Il se tient sur le tas de pierres, dos à toi, et il regarde le sud par-dessus le hameau. Un vieux manteau de guet, la corne au côté. Il ne se retourne pas.
  > — « Tu as vu là-haut. » Ce n'est pas une question. « Alors tu as vu ce qu'on surveillait. »

### `fille-moulin-1`
- Image : `monstre_fille_moulin_dos_v2_c_a.png` — dédiée
- Texte :
  > La porte est entrouverte, comme toujours. Mais cette fois la bruyère du pot n’est pas seulement fraîche : elle est mouillée. Quelqu’un vient de la cueillir.
  > Près de la meule, quelqu’un est accroupi, dos à toi, en train de ranger de petites choses en ligne sur la pierre. La silhouette t’arrive à la hanche.
  > « Tu m’as vue. » Ce n’est pas une question. « Ça arrive une fois tous les dix ans. »

### `fille-moulin-2`
- Image : `monstre_la_fille_moulin_v2_c_b.png` — dédiée
- Texte :
  > Elle se retourne enfin, et le compte ne marche pas. Le village parle d’elle comme d’une histoire ancienne, d’un temps que même les vieux ont du mal à situer. Elle a huit ans.
  > « Ils m’ont pendue un mardi. » Elle dit ça comme on récite le jour du marché. « Ça n’a pas pris. Je suis restée là à me balancer, et à un moment ils sont partis manger. »
  > « Quand ils sont revenus, j’avais défait le nœud toute seule. » Elle le dit avec un tout petit peu de fierté, celle d’un enfant qui a appris à faire ses lacets. « Alors ils ont décidé de pas m’avoir vue. C’était plus simple. »

### `fille-moulin-3`
- Image : `monstre_la_fille_moulin_v2_c_b.png` — dédiée
- Texte :
  > « Mon père il a fait construire une grande potence pour la chose qui m'a fait pendre. » Elle aligne un caillou. « Il l'a attendue trois mois. Elle vient jamais quand on l'appelle — elle vient quand un village est prêt. »
  > Un temps.
  > « Après il est monté à côté. Pas parce qu'il était triste : parce que c'était le règlement. Il avait refusé de me condamner, et refuser, dans son livre, c'était une faute. » Elle hausse les épaules. « Je sais pas ce que ça veut dire, règlement. Lui il savait. »
  > « Alors non, je monte pas le voir. Il attend un procès. Moi j’ai fini d’attendre. »

### `fille-moulin-4`
- Image : `monstre_fille_moulin_ouvrage_e_b.png` — dédiée
- Texte :
  > « Tu vas redescendre et tu vas leur en parler. Ils vont te regarder gentiment, et après ils vont noter que tu parles à des gens qui existent pas. » Elle se remet à ses cailloux. « C’est comme ça que ça commence. »
  > « Alors garde-moi pour toi. Et si tu passes le sud, te retourne pas pour vérifier si je suis encore là. Je serai encore là. C’est justement le problème. »

### `veuve-cordes-sait-1`
- Image : `monstre_veuve_cordes_v2_b_d.png` — dédiée
- Texte :
  > Elle tresse sous le mur des cordes. Ses mains vont toutes seules — elle n’a pas besoin de regarder, et elle ne regarde pas.
  > « Chacune est une personne. Je les coupe après. Ça les libère pas, mais ça fait quelque chose à faire. »
  > Toutes portent une étiquette. Sauf une, à hauteur d’œil, au centre du mur : sans nom, plus neuve que les autres.

### `veuve-cordes-sait-2`
- Image : `monstre_veuve_cordes_v2_b_d.png` — dédiée
- Texte :
  > Ses mains s’arrêtent. Première fois.
  > « Celle-là, je la refais. Trente ans que je la refais. Je la tresse, je la cloue, je la coupe. Et au matin suivant, elle est défaite. Pas coupée : défaite. Nœud par nœud, proprement, comme quelqu’un qui prend son temps. »
  > Un silence.
  > « Alors je recommence. Parce que si j’arrête, faudra que je dise à quelqu’un pourquoi. »

### `veuve-cordes-sait-3`
- Image : `monstre_veuve_cordes_v2_b_d.png` — dédiée
- Texte :
  > Elle reprend son ouvrage, et le mur reprend son bruit — ce froissement continu de chanvre qu’on croirait fait par le vent.
  > « Mets pas d’étiquette dessus. Une corde sans nom, c’est une corde en attente. Une corde avec un nom, c’est un fait. »

### `bailli-dedans`
- Image : `scene_maison_bailli_dedans_b.png` — dédiée
- Texte :
  > Dedans, il fait le noir des caves alors que dehors le jour n'a jamais fini de tomber. L'odeur n'est pas celle d'un abandon : c'est celle d'un homme qui a vécu longtemps dans une pièce fermée.
  > Une seule chaise, au milieu. Tournée vers la porte. Il ne s'asseyait pas pour regarder le feu ni pour manger : il s'asseyait pour surveiller ce qui entrerait, et il l'a fait assez d'années pour creuser deux ronds dans la terre battue sous les pieds avant.
  > Et sur le mur ouest, une fenêtre. La seule qu'il n'a pas murée. Elle donne sur la lande, la crête, et la croix noire d'un moulin qui ne tourne pas.

### `bailli-fenetre`
- Image : `scene_moulin_sans_ailes_d_d.png` — dédiée (de `bailli-dedans`)
- Ce que l'écran montre : Action « S'asseoir sur la chaise » — ce que l'écran montre quand le héros s'en approche.

### `meute-grise-1`
- Image : `monstre_meute_grise_c.png` — dédiée
- Ce que l'écran montre : Cinq silhouettes couleur de bruyère morte alignées de front dans l'herbe haute, la plus grande au centre ; le cercle est derrière toi, hors champ.
- Texte :
  > Hors de vue du moindre toit, la lande est à eux. Ils se montrent d'un coup, de front, cinq silhouettes couleur de bruyère morte alignées dans l'herbe haute — et c'est mauvais signe : la Meute Grise ne se laisse voir que quand l'encerclement est déjà fini derrière toi.
  > Pas des chiens : trop patients. Pas des loups : trop organisés. La plus grande tient le centre et avance d'un pas — le signal. Le cercle que tu ne vois pas se resserre du même pas, dans ton dos.

### `meute-grise-2`
- Image : `monstre_meute_grise_c.png` — dédiée
- Ce que l'écran montre : Le cercle est rompu : la meute regroupée en croissant à distance de lame, et la meneuse avancée seule d'un pas, tête basse, qui te fixe. CHANGE : plus de cercle autour de toi — un croissant devant, une bête détachée en avant.
- Texte :
  > Le cercle est rompu, mais la meute reste — regroupée à distance de lame, en croissant, plus prudente. Ils ont compris que tu mords aussi. Ça ne les décourage pas : ça les intéresse.
  > La meneuse s'avance seule d'un pas, tête basse, et te fixe. Chez eux, c'est une question. La dernière avant la charge — ou avant autre chose. À toi d'y répondre.

### `chemin-du-sud`
- Image : `scene_chemin_du_sud_a_b.png` — dédiée
- Texte :
  > Le plateau cesse d'être un pays. Plus de murets, plus de poteaux, plus rien qui dise qu'on a vécu ici. Le vent vient du sud, régulier, et il n'a plus le goût de la bruyère.
  > Sur les derniers cent pas, des choses posées à intervalles réguliers. Un sac. Un manteau plié en quatre. Une paire de bottes rangées côte à côte, les pointes vers le sud. Rien n'a été jeté ici : tout a été posé.
  > Devant, le chemin continue jusqu'à un bord que tu ne vois pas encore. Le silence n'est pas celui de la lande : c'est celui d'après.

### `chemin-du-sud-revenu`
- Image : `scene_chemin_du_sud_a_b.png` — héritée (de `chemin-du-sud`)
- Texte :
  > Le plateau cesse d'être un pays, une seconde fois. Les choses posées le long du chemin n'ont pas bougé — sauf qu'il y en a une de plus, et celle-là est encore sèche.
  > Tu sais ce qu'il y a au bout. Ça ne rend pas les cent derniers pas plus courts.

### `veilleur-1-note`
- Image : `objet_lanterne_rouillee_guerite_b_a.png` — dédiée
- Texte :
  > Il ne sort pas de sa niche. Il t'a vu venir de loin — il a eu le temps de poser sa soupe, d'ouvrir son registre et de tremper sa plume. Il attend que tu sois à dix pas pour écrire.
  > Pas de bonjour. Pas de « tu descends ». Il écrit trois mots, souffle dessus, et seulement là il lève les yeux.
  > — « Un gamin est passé avant toi. » Un temps. « Il a couru. »

### `demo-borne-geste`
- Image : `scene_borne_gravures_a_d.png` — dédiée
- Texte :
  > La Borne te retient un pas de plus. Sur la face sud, sous la mousse, quelque chose est écrit — et la mousse s'écarte sous les doigts.

### `demo-nuit`
- Image : `scene_hameau_entree_2_v2_a.png` — dédiée
- Texte :
  > Le soir tombe d'un coup, comme une porte. Les volets se ferment sans se répondre — pas un chien, pas une voix. Il faut dormir quelque part. Reste à savoir derrière quelle porte.

### `demo-nuit-maison`
- Image : `scene_hameau_maison_muree_combles_v4_b.png` — dédiée
- Texte :
  > Avant de fermer l'œil, tu montes voir les combles. Tu redescends plus lentement que tu n'es monté : la trappe est clouée. De l'intérieur du toit. Les clous sont tordus par quelqu'un qui se dépêchait — et le rez-de-chaussée, lui, n'est pas cloué du tout.
  > Cette maison ne se protégeait pas de ce qui entre par les portes.

### `demo-nuit-grange`
- Image : `scene_landes_hameau_grange_b_d.png` — dédiée
- Texte :
  > La grange sent la paille et le suif. Le vieux te montre ton coin d'un geste, puis reste debout, la barre à la main. « La trappe des combles, chez nous, on la cloue de l'intérieur », dit-il sans que tu aies rien demandé. « Toutes les maisons. Depuis avant moi. » Il ne dit pas contre quoi.

### `demo-nuit-dehors`
- Image : `scene_temoin_grange_toit_v2_c.png` — dédiée
- Texte :
  > Le muret coupe le vent, pas le froid. Vers le milieu de la nuit, un pas — au-dessus de toi. Sur un toit. Quelque chose marche sur les toits, lentement, comme on compte. Tu ne bouges plus jusqu'au gris.

### `falaise-cordes-loin`
- Image : `scene_falaise_au_loin_a.png` — dédiée
- Texte :
  > Passé le portillon, le sentier meurt. La bruyère se raréfie, la pierre cassée prend toute la place, et le pays descend d'un seul tenant vers le sud.
  > Loin devant, quelque chose de vertical tient le ciel. Trop étroit pour une tour, trop haut pour un arbre : une nappe de fils serrés, qui descend des nuages et s'arrête au ras de la terre. Rien ne bouge dedans. Il n'y a pas d'oiseaux.

### `falaise-cordes-marche`
- Image : `scene_falaise_au_loin_a.png` — dédiée
- Texte :
  > Ce que tu prenais pour un tronc est une nappe. Des centaines de fils côte à côte, sur toute la largeur du regard, qui descendent d'un ciel où l'œil ne trouve rien à quoi les rattacher.
  > Et ils ne s'arrêtent pas à la terre. Ils continuent derrière la ligne d'horizon, là où le pays devrait remonter — et ne remonte pas.

### `falaise-cordes`
- Image : `scene_falaise_bord_c_a.png` — dédiée
- Texte :
  > Tu montes une dernière ondulation de pierre, et la lande s'ouvre.
  > Devant toi, un trou. Large comme un village, et sans fond visible. Du ciel, des cordes descendent dedans — des centaines, venues de si haut qu'on ne voit pas à quoi elles tiennent. Aucune ne bouge. Le vent passe dessus sans les prendre : elles entrent dans le noir droites et immobiles, comme plantées là depuis toujours.

### `falaise-cordes-2`
- Image : `scene_falaise_fond_d_a.png` — dédiée
- Texte :
  > Au ras de la lèvre, les pieux : une rangée qui suit tout le pourtour, un tous les trois pas. Aucune corde n'y est nouée. Elles passent au-dessus sans les toucher et remontent, toujours, vers un ciel où l'œil ne trouve rien à quoi les rattacher. Le chanvre, lui, tu le reconnais : dans les Landes on ne le gâche pas, et chaque corde qui a pendu quelqu'un sert une seconde fois.
  > Tu te penches. Elles descendent jusqu'à ce que la lumière les abandonne, et elles continuent. Des vieilles, grises, raides de sel. Des neuves, encore blondes. Et trois ou quatre qui s'arrêtent en plein vide, tranchées net — à la lame. Par en dessous.

### `falaise-cordes-3`
- Image : `scene_falaise_appele_d_d.png` — dédiée
- Texte :
  > Au bout du surplomb, quelqu'un. Il ne regarde pas les cordes : il en prend une, sans choisir, comme on prend la rampe d'un escalier qu'on connaît. Il passe le bord. Il descend. Le vent rabat un pan de son manteau — puis plus rien. La corde tremble encore un moment, toute seule.
