/**
 * Mémoire du joueur — historique persistant attaché au COMPTE, distinct de la
 * run en cours (`lib/state.ts`) et des Reliques (spec §17/§19, session 2 & 4).
 *
 * Le Notion recommande explicitement de centraliser ici tout ce qui doit
 * survivre à la mort du héros — pour éviter des flags épars dupliqués entre
 * les systèmes qui partagent la même infrastructure :
 *
 * (Le type RegistreRow vit dans state.ts avec les autres entrées de fil.)
 *   - Saisons du Geôlier (§17) : le ton dérive selon l'historique agrégé.
 *   - Persistance environnementale (§17) : une porte défoncée reste défoncée.
 *   - Prix différé / Pacte à la marge (§17/§19) : dettes narratives silencieuses.
 *   - Dette de sang entre héros (§19) : un tueur nommé peut réapparaître.
 *   - Le Grand Registre (§19) : les héros tombés du joueur s'y inscrivent.
 *
 * Rien ici n'est jamais affiché en chiffre au joueur — ce sont des seuils qui
 * modulent le ton et le décor, jamais un score exposé (piliers du projet).
 */

import type { ZoneId } from "@/lib/zones";
import { track, finDeRun } from "./analytics";
import type { RegistreRow } from "@/lib/state";
import { sacDepuis, type SacFaits } from "@/lib/faits";
import { traverseeDe, migrerSceau } from "@/lib/traversees";
import {
  forgerRelique,
  relique,
  type RelicDette,
  type RelicDon,
  type RelicLandes,
} from "@/lib/reliques";
// registre-data n'importe d'ici que des TYPES (import effacé au build) : ce
// sens-ci peut donc porter la valeur `buildLesCent` sans cycle au runtime.
import { buildLesCent } from "@/lib/registre-data";
import { rencontresDepuis, type SouvenirRencontre } from "@/lib/memoire";

/** Un tueur nommé garde une trace liée au compte, pas au héros mort (§19). */
export type BloodDebt = {
  /** Identifiant stable de l'entité (ex. "geryon", "meute-limiers"). */
  entity: string;
  /** Nom affiché de l'entité pour la ligne de reconnaissance. */
  label: string;
  /** Nom du héros tombé de sa main. */
  heroName: string;
  /** Index de run où la dette a été contractée. */
  runIndex: number;
};

/** Un héros tombé, pour Le Grand Registre (§19) et Le retour (§16). */
/**
 * LE DESTIN D'UN HÉROS. Trois façons de sortir d'une vie, et le Registre doit
 * les distinguer — un survivant classé sous « TES MORTS » contredit la
 * promesse centrale du jeu (verdict des panels, 14/08).
 *
 * ⚠️ Optionnel dans `FallenHero` à cause des sauvegardes d'avant le 14/08 :
 * `loadMemory` le DÉDUIT alors de la cause, qui est écrite par nos trois
 * enregistreurs et donc fiable. Voir `destinDepuisCause`.
 */
export type Destin = "mort" | "traversee" | "renoncement";

export type FallenHero = {
  name: string;
  days: number;
  /** LIEUX FRANCHIS — l'unité du Grand Registre depuis le 04/09. Absent des
      héros tombés avant : le Registre lit alors leurs jours (aucune
      conversion honnête n'existe, et les ordres de grandeur sont voisins). */
  franchis?: number;
  cause: string;
  destin?: Destin;
  /** Lieu de mort (id de scène) — sert à « Le retour » (recroiser le cadavre). */
  place: string;
};

/** Relique forgée à la mort (spec §10 + séquence d'écran de mort 13/07). */
export type Relic = {
  name: string;
  rarity: "commune" | "rare" | "legendaire";
  heroName: string;
  days: number;
  /** Effet de RÈGLE porté par la relique (retour test 4/08, promesse n°3 :
      « ta mort transforme la prochaine vie »). v1 : l'effet découle de la
      rareté — les reliques d'avant n'ont pas le champ, relicEffect() le
      dérive. Prochaine itération : effet par NOM de relique. */
  effect?: RelicEffect;
  /** Id de la fiche des Landes (lib/reliques.ts) — porte le DON et la DETTE.
      Absent sur les reliques d'avant le 5/08 : elles n'ont pas de dette. */
  relicId?: string;
};

export type RelicEffect = "coussin" | "passe" | "faveur";

/** L'effet d'une relique — champ posé à la forge, dérivé de la rareté pour
    les reliques antérieures au 4/08. */
export function relicEffect(r: Relic): RelicEffect {
  if (r.effect) return r.effect;
  return r.rarity === "legendaire" ? "faveur" : r.rarity === "rare" ? "passe" : "coussin";
}

/** La fonction, en mots — affichée sur la fiche de forge et dans l'Inventaire.
    Jamais un chiffre : la règle se dit, elle ne se compte pas. */
export const RELIC_FONCTION: Record<RelicEffect, string> = {
  coussin: "Le premier coup dur de la prochaine vie sera amorti. Puis elle se fendra.",
  passe: "Une fois, la prochaine vie passera un verrou que sa nature lui refuse. Le Hameau s'en souviendra.",
  faveur: "La prochaine vie lancera chaque dé avec la faveur des morts.",
};

/** La dernière relique forgée. ⚠️ Depuis la spec du 20/08 (écran Reliques),
    ce n'est plus forcément « LA relique portée » : la Descente peut en
    emporter jusqu'à trois (`reliquesPortees`). Cette fonction reste la
    RÈGLE PAR DÉFAUT d'un compte qui n'a jamais ouvert l'écran, et la fiche
    montrée à la forge. */
export function activeRelic(mem: PlayerMemory): Relic | null {
  return mem.relics.length ? mem.relics[mem.relics.length - 1] : null;
}

/** Une relique portée, avec son identité (index dans `mem.relics`). */
export type ReliquePortee = { relic: Relic; idx: number };

/**
 * LES RELIQUES DE LA DESCENTE (spec 20/08) — jusqu'à trois, effets cumulés.
 * Défaut (compte qui n'a jamais ouvert l'écran, `descente === undefined`) :
 * la dernière forgée, comme depuis le 4/08 — « Celui qui te suivra la
 * portera » reste vrai pour ces comptes-là. Un `[]` explicite porte zéro.
 */
export function reliquesPortees(mem: PlayerMemory): ReliquePortee[] {
  if (Array.isArray(mem.descente)) {
    return mem.descente
      .filter((i) => i >= 0 && i < mem.relics.length)
      .slice(0, 3)
      .map((i) => ({ relic: mem.relics[i], idx: i }));
  }
  return mem.relics.length
    ? [{ relic: mem.relics[mem.relics.length - 1], idx: mem.relics.length - 1 }]
    : [];
}

/** Les DONS portés, cumulés (deux « faveur » comptent deux fois). */
export function donsPortes(mem: PlayerMemory): RelicDon[] {
  return reliquesPortees(mem)
    .map((p) => relicDon(p.relic))
    .filter((d): d is RelicDon => d !== null);
}

/** Les DETTES portées, cumulées — une relique aide ET coûte, toujours. */
export function dettesPortees(mem: PlayerMemory): RelicDette[] {
  return reliquesPortees(mem)
    .map((p) => relicDette(p.relic))
    .filter((d): d is RelicDette => d !== null);
}

/**
 * Débloque une entrée du Codex avec sa provenance — silencieux si elle est
 * déjà débloquée (la PREMIÈRE découverte fait foi : « Découvert par Maël —
 * Jour IV » ne se réécrit jamais). Ne rend rien : le Codex est de la
 * lecture pure, un déblocage ne change rien en jeu.
 */
export function debloquerCodex(id: string, par: string, jour: number): void {
  const mem = loadMemory();
  if (mem.codex?.[id]) return;
  mutateMemory((m) => {
    m.codex = { ...(m.codex ?? {}), [id]: { par: par || "Sans-Nom", jour: Math.max(1, jour) } };
  });
}

/** Ouvre une fiche : le NOUVEAU tombe, le losange se recalcule. */
export function marquerCodexVu(id: string): void {
  const mem = loadMemory();
  const e = mem.codex?.[id];
  if (!e || e.vu) return;
  mutateMemory((m) => {
    m.codex = { ...(m.codex ?? {}), [id]: { ...e, vu: true } };
  });
}

/**
 * Le DON d'une relique (lib/reliques.ts). Les reliques d'avant le 5/08 n'ont
 * pas de fiche : leur don se dérive de l'ancien `effect` — « coussin » est
 * l'ancien nom d'« amorti ».
 */
export function relicDon(r: Relic | null): RelicDon | null {
  if (!r) return null;
  const fiche = relique(r.relicId ?? r.name);
  if (fiche) return fiche.don;
  const legacy = relicEffect(r);
  return legacy === "coussin" ? "amorti" : legacy;
}

/**
 * La DETTE d'une relique. `null` pour les reliques d'avant le 5/08 : on
 * n'ajoute pas rétroactivement un coût à un objet gagné sans.
 */
export function relicDette(r: Relic | null): RelicDette | null {
  if (!r) return null;
  return relique(r.relicId ?? r.name)?.dette ?? null;
}

/** La fiche complète (fonction, coût, murmure) si la relique en a une. */
export function relicFiche(r: Relic | null): RelicLandes | null {
  return r ? relique(r.relicId ?? r.name) : null;
}

export type PlayerMemory = {
  /** Nombre de runs commencées (incrémenté au tout premier pas d'une run neuve). */
  runsStarted: number;
  /** Nombre de morts enregistrées. */
  deaths: number;
  /** Plus grand « Jour X » atteint, toutes runs confondues. */
  bestDays: number;
  /** Meilleur score du compte en LIEUX FRANCHIS (04/09) — c'est lui que le
      Geôlier compare quand il parle de « meilleur score ». `bestDays` reste :
      il nourrit sa posture, qui mesure une carrière, pas un classement. */
  bestFranchis?: number;
  /** Somme des jours survécus (pour la moyenne, sans stocker chaque run). */
  totalDays: number;
  /** Reliques rares/légendaires obtenues (les communes ne comptent pas pour le ton). */
  relicsRare: number;
  /** Toutes les reliques forgées, dans l'ordre des morts. */
  relics: Relic[];
  /**
   * LA DESCENTE (spec 20/08, écran Reliques — Figma 2496:4745) : jusqu'à
   * TROIS reliques choisies pour la prochaine incarnation, référencées par
   * leur INDEX dans `relics` (le tableau est append-only, l'index est donc
   * une identité stable). Leurs effets — dons ET dettes — s'additionnent.
   * `undefined` = le joueur n'a jamais ouvert l'écran → comportement
   * historique (la dernière forgée est portée, voir `reliquesPortees`).
   * `[]` = choix explicite de ne rien porter — on le respecte.
   */
  descente?: number[];
  /**
   * LE CODEX (Phase E, spec 20/08) : provenance des entrées débloquées —
   * id d'entrée → { par (nom du héros qui a découvert), jour, vu }.
   * La provenance est OBLIGATOIRE sur chaque fiche (« Découvert par Maël —
   * Jour IV ») : c'est elle qui fait du Codex un registre des morts du
   * joueur et pas une encyclopédie. `vu` pilote le tag NOUVEAU et le
   * losange orange propagé vers le haut.
   */
  codex?: Record<string, { par: string; jour: number; vu?: boolean }>;
  /** Éléments d'environnement modifiés durablement : "porte-balafree-defoncee", etc. */
  envFlags: Record<string, boolean>;
  /** Rivalités personnelles qui traversent les runs (§19). */
  bloodDebts: BloodDebt[];
  /** Héros tombés du joueur, les plus récents en tête. */
  fallen: FallenHero[];
  /** Chapitres garantis déjà vécus (chantier 2 du 23/07) — la rotation évite de
      retomber sur un chapitre vu tant qu'il en reste des neufs. */
  chaptersSeen: string[];
  /** Morts par fixation subies (chantier 3) : au-delà de 2, l'accueil du hameau
      change dès l'entrée — le village se souvient de la main qui lance le dé. */
  fixations: number;
  /** L'accueil du Hameau servi à la vie PRÉCÉDENTE (6/08). Sert uniquement à
      ne jamais le retirer deux fois de suite : c'est ce qui sépare « varié »
      de « aléatoire ». Absent des mémoires d'avant le 6/08. */
  lastAccueil?: string;
  /** Passages du COMPTE par chaque lieu (radical), toutes vies confondues —
      la mémoire des PNJ entre les incarnations (arbitrage Patrick 8/08). */
  visitesLieux?: Record<string, number>;
  /** Registre de déjà-vu, portée COMPTE (lib/dejavu.ts). Le héros ne se
      souvient de rien ; c'est le monde qui tient le compte. */
  vus?: Record<string, number>;
  /** Ce que chaque rencontre retient de ce que les vies lui ont FAIT
      (lib/memoire.ts) — une clé par chose qui se souvient. */
  rencontres?: Record<string, SouvenirRencontre>;
  /**
   * L'introduction (les 4 clauses du pacte, Figma 2238:1009) a déjà été lue.
   *
   * ⚠️ Vit dans la mémoire du COMPTE, pas dans la run : le tuto énonce les
   * règles du JEU, pas celles d'une partie — le rejouer à chaque mort serait
   * une punition. Il ne se montre donc qu'au tout premier lancement, et ne
   * revient que si le joueur le redemande depuis Options (`forgetIntro`).
   *
   * Optionnel pour que les sauvegardes d'avant le 26/07 restent valides ; à
   * l'absence près, `introSeen` y est indéfini, donc l'intro se jouerait une
   * fois — c'est pourquoi `loadMemory` la marque vue quand la mémoire montre
   * une partie déjà entamée (voir la migration plus bas).
   */
  introSeen?: boolean;
  /**
   * Contexte de la DERNIÈRE mort (30/07) : ce dont le pool de citations du
   * Geôlier a besoin au retour à l'accueil — jamais affiché tel quel.
   * Optionnel : absent sur les mémoires d'avant le 30/07 (le pool retombe
   * alors sur ses génériques).
   */
  lastDeath?: {
    day: number;
    /** La mort était une fixation (sociale, aux Landes). */
    fixation: boolean;
    /** Rareté de la relique forgée par cette mort. */
    rarity: Relic["rarity"];
    /** Le héros est entré aux Cent du Registre. */
    classed: boolean;
    /** Acte le plus profond atteint par cette run. */
    acte: number;
    /** Cette run est le meilleur score du compte. */
    meilleurScore: boolean;
    /** Id (radical) de la scène de mort — la surprise « le retour » (6/08). */
    lieu?: string;
  };
  /**
   * LE RATIONNEMENT DES SURPRISES (catalogue 6/08, non négociable) : run où
   * la dernière surprise s'est JOUÉE — jamais deux runs de suite.
   */
  surprises?: { derniereRun?: number };
  /** Dernier passage en jeu (ms epoch) — pour les citations « longue absence ». */
  lastPlayedAt?: number;
  /**
   * LES CONTRADICTIONS (5/08) : versions de chaque fait déjà LUES, toutes runs
   * confondues. Deux versions du même fait = une contradiction que le héros
   * peut opposer au Registre. Optionnel (mémoires d'avant le 5/08).
   */
  faitsVus?: Record<string, string[]>;
  /**
   * LE MOTEUR DE FAITS (spec 4/08 §1) — scopes `zone_permanent` et
   * `global_permanent` : compteurs de visite, de traversées, DÉCOUVERTES. Ne
   * meurent jamais. ⚠️ Les Découvertes conditionnent l'arc du twist, jamais ce
   * que sait le héros courant (voir lib/faits.ts).
   */
  faits?: SacFaits;
  /**
   * LES RENONÇANTS (5/08) : runs terminées SANS mourir — le héros est resté au
   * Hameau. Ce n'est pas une victoire et ce n'est pas une mort : c'est une
   * place prise à quelqu'un d'autre. Change le ton du Geôlier.
   */
  renoncements?: number;
  /**
   * LA TRACE DU SURVIVANT (arbitrage Patrick 7/08) : traversées COMPLÈTES —
   * la Descente franchie vivant. Le nom entre au Registre (« a franchi la
   * Descente »), le compte s'en souvient, le Geôlier accueille la run
   * suivante en conséquence. Aucune relique : on ne forge rien d'une vie
   * qu'on n'a pas perdue. (Le Sceau, livré le 14/08, est retiré le 25/09.)
   */
  zonesCleared?: number;
  /**
   * LES PROFILS DÉJÀ DESSINÉS, dans l'ordre des vies (V2 du 06/09).
   *
   * C'est ce qui permet au Geôlier de COMPARER : « les mêmes réflexes »,
   * « tu n'es pas comme le précédent », « toujours pareil, peu importe le
   * visage ». Sans cette liste, il redécouvrirait le joueur à chaque
   * incarnation — ce qui ferait mentir sa mémoire, qui est le sujet du jeu.
   */
  profils?: { courage: number; ruse: number; instinct: number; empathie: number }[];
  /** La DERNIÈRE fin de run était une traversée réussie — consommé par
      l'accueil du Geôlier, remis à false par la mort suivante. */
  derniereFinTraversee?: boolean;
  /**
   * Le nom de la dernière incarnation sortie VIVANTE (fin de démo à la
   * Descente). Depuis le 12/09 un survivant n'entre plus au Registre — « le
   * Registre est le livre des morts, une vie s'y inscrit quand elle finit »
   * (décision Patrick) — mais la Borne doit encore pouvoir relire « celui-là
   * est revenu » : c'est ici qu'elle le trouve (`predecesseur`). Ne vaut que
   * tant que `derniereFinTraversee` est vrai ; une mort le périme.
   */
  dernierSurvivant?: string;
};

const KEY = "aldenhar-player";

function fresh(): PlayerMemory {
  return {
    runsStarted: 0,
    deaths: 0,
    bestDays: 0,
    bestFranchis: 0,
    totalDays: 0,
    relicsRare: 0,
    relics: [],
    envFlags: {},
    bloodDebts: [],
    fallen: [],
    chaptersSeen: [],
    fixations: 0,
    introSeen: false,
    faitsVus: {},
    renoncements: 0,
    zonesCleared: 0,
    profils: [],
    derniereFinTraversee: false,
    faits: {},
    rencontres: {},
  };
}

/**
 * UN FAIT LU. Enregistre la version que cette run a montrée. Deux versions
 * différentes du même fait, sur deux vies, = une contradiction opposable au
 * Registre (lib/contradictions.ts).
 */
export function noterFait(faitId: string, versionId: string): void {
  mutateMemory((m) => {
    const vus = { ...(m.faitsVus ?? {}) };
    const l = vus[faitId] ?? [];
    if (!l.includes(versionId)) vus[faitId] = [...l, versionId];
    m.faitsVus = vus;
  });
}

/**
 * LE RENONCEMENT (5/08) — une run qui s'arrête sans mort.
 *
 * Le héros reste au Hameau : il ne franchit pas la Descente, il ne meurt pas.
 * Aucune relique n'est forgée — on ne forge rien avec une vie qu'on n'a pas
 * perdue. Le nom entre au Registre quand même : c'est le prix, et c'est aussi
 * la loi du Domaine (quelqu'un a pris sa place au Hameau, quelqu'un d'autre
 * en est sorti). `deaths` n'est PAS incrémenté : la courbe d'entrée et les
 * jalons de mort ne doivent pas se croire avancés.
 */
export function recordRenoncement(args: { heroName: string; days: number; franchis: number; place: string }): void {
  track("renoncement", { jour: args.days, franchis: args.franchis, lieu: args.place, morts: loadMemory().deaths }, { instant: true });
  finDeRun(); // la partie s'arrête ici : plus aucun événement ne lui appartient.
  mutateMemory((m) => {
    m.renoncements = (m.renoncements ?? 0) + 1;
    m.totalDays += args.days;
    m.bestDays = Math.max(m.bestDays, args.days);
    m.bestFranchis = Math.max(m.bestFranchis ?? 0, args.franchis);
    m.fallen.unshift({
      name: args.heroName,
      days: args.days,
      franchis: args.franchis,
      cause: "resté au Hameau",
      place: args.place,
      destin: "renoncement",
    });
    m.derniereFinTraversee = false;
    m.lastPlayedAt = Date.now();
  });
}

/**
 * LA TRACE DU SURVIVANT (7/08) — la Descente franchie vivant. Enregistré AU
 * MOMENT du franchissement, avant le reset de la run : fermer l'app sur
 * l'écran final ne fait pas disparaître la traversée. `deaths` n'est PAS
 * incrémenté (la courbe d'entrée et les jalons de mort ne doivent pas se
 * croire avancés), et aucune relique n'est forgée.
 */
/** Le Geôlier vient de dessiner cette incarnation : il s'en souviendra. */
export function noterProfil(stats: { courage: number; ruse: number; instinct: number; empathie: number }): void {
  mutateMemory((m) => {
    m.profils = [...(m.profils ?? []), stats];
  });
}

/**
 * FRANCHIR UNE ZONE VIVANT (12/09 — remplace la moitié « zone » de l'ancien
 * `recordTraversee`). Ce que le COMPTE retient d'un franchissement, que la
 * vie continue en bas ou que la démo s'arrête là : le compte de zones, le
 * compteur de traversées de CETTE zone (`traversee:<zone>` — le Sceau qui
 * l'a précédé est retiré depuis le 25/09, voir lib/traversees.ts), le record
 * de lieux franchis.
 * ⚠️ AUCUNE ligne au Grand Registre : décision Patrick 12/09, « à la mort
 * seulement ». Et aucun `finDeRun` : la partie n'est pas finie, elle descend.
 */
export function recordZoneFranchie(args: { zone: ZoneId; heroName: string; days: number; franchis: number }): void {
  track(
    "descente_franchie",
    { zone: args.zone, jour: args.days, franchis: args.franchis, morts: loadMemory().deaths, traversees: loadMemory().zonesCleared ?? 0 },
    { instant: true },
  );
  mutateMemory((m) => {
    m.zonesCleared = (m.zonesCleared ?? 0) + 1;
    const id = traverseeDe(args.zone);
    const sac: SacFaits = { ...(m.faits ?? {}) };
    sac[id] = {
      id,
      kind: "counter",
      scope: "zone_permanent",
      value: (sac[id]?.value ?? 0) + 1,
      source: "la-descente",
    };
    m.faits = sac;
    m.bestFranchis = Math.max(m.bestFranchis ?? 0, args.franchis);
    m.lastPlayedAt = Date.now();
  });
}

/**
 * LA FIN DE DÉMO : la vie s'arrête VIVANTE parce que la zone suivante n'est
 * pas écrite (lib/zones.ts). Ce n'est ni une mort ni un renoncement — pas de
 * relique, pas de ligne au Registre — mais c'est bien la fin d'une vie : ses
 * jours entrent au total du compte, `finDeRun` clôt la partie côté
 * statistiques, et le nom reste lisible par la Borne (`dernierSurvivant`).
 * Disparaîtra avec la démo, quand toutes les zones seront écrites.
 */
export function recordSortieVivante(args: { heroName: string; days: number }): void {
  finDeRun(); // la partie s'arrête ici : plus aucun événement ne lui appartient.
  mutateMemory((m) => {
    m.totalDays += args.days;
    m.bestDays = Math.max(m.bestDays, args.days);
    m.dernierSurvivant = args.heroName;
    m.derniereFinTraversee = true;
    m.lastPlayedAt = Date.now();
  });
}

/**
 * L'INCARNATION D'AVANT, telle que la Borne la relit (« qui a gravé côté
 * sud ? »). Morte : la dernière ligne du Registre. Sortie vivante à la fin de
 * la démo : le survivant, avec la cause que `ligneBorneSud` reconnaît — le
 * texte « celui-là est revenu » dépend de cette distinction, et le Registre
 * ne la porte plus depuis le 12/09.
 */
export function predecesseur(m: PlayerMemory): { name: string; cause: string } | undefined {
  if (m.derniereFinTraversee && m.dernierSurvivant) {
    return { name: m.dernierSurvivant, cause: "a franchi la Descente" };
  }
  return m.fallen[0];
}

/** L'intro doit-elle se jouer ? (tout premier lancement, ou redemandée.) */
export function shouldShowIntro(): boolean {
  return !loadMemory().introSeen;
}

/** Marque l'intro comme lue — appelé à la sortie du dernier écran. */
export function markIntroSeen(): void {
  mutateMemory((m) => {
    m.introSeen = true;
  });
}

/**
 * Redonne l'intro au prochain lancement, SANS rien détruire.
 *
 * C'est la vraie réponse au besoin « je veux retester l'intro » : effacer toute
 * la progression marcherait aussi, mais coûterait les reliques et le Registre.
 */
export function forgetIntro(): void {
  mutateMemory((m) => {
    m.introSeen = false;
  });
}

/**
 * Le destin d'une entrée d'avant le 14/08, déduit de sa CAUSE.
 *
 * Ce n'est pas une devinette : les trois enregistreurs écrivent une cause
 * fixe pour la traversée et le renoncement, et tout le reste est une mort.
 * Une sauvegarde ancienne se relit donc sans perte.
 */
export function destinDepuisCause(cause: string): Destin {
  if (/franchi la Descente/i.test(cause)) return "traversee";
  if (/resté au Hameau/i.test(cause)) return "renoncement";
  return "mort";
}

export function loadMemory(): PlayerMemory {
  if (typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) {
        const p = JSON.parse(raw) as Partial<PlayerMemory>;
        return {
          runsStarted: typeof p.runsStarted === "number" ? p.runsStarted : 0,
          deaths: typeof p.deaths === "number" ? p.deaths : 0,
          bestDays: typeof p.bestDays === "number" ? p.bestDays : 0,
          bestFranchis: typeof p.bestFranchis === "number" ? p.bestFranchis : 0,
          totalDays: typeof p.totalDays === "number" ? p.totalDays : 0,
          relicsRare: typeof p.relicsRare === "number" ? p.relicsRare : 0,
          relics: Array.isArray(p.relics) ? p.relics : [],
          // La Descente (20/08) — même geste que l'ajout du champ. `undefined`
          // et `[]` ne veulent PAS dire la même chose (défaut vs choix vide).
          descente: Array.isArray(p.descente)
            ? p.descente.filter((n): n is number => typeof n === "number")
            : undefined,
          codex: p.codex && typeof p.codex === "object" ? p.codex : undefined,
          envFlags: p.envFlags && typeof p.envFlags === "object" ? p.envFlags : {},
          bloodDebts: Array.isArray(p.bloodDebts) ? p.bloodDebts : [],
          // ⚠️ Même geste que l'ajout du champ (règle du 5/08) : une entrée
          // d'avant le 14/08 n'a pas de `destin`, on le déduit de sa cause.
          fallen: Array.isArray(p.fallen)
            ? p.fallen.map((f) => ({ ...f, destin: f.destin ?? destinDepuisCause(f.cause ?? "") }))
            : [],
          chaptersSeen: Array.isArray(p.chaptersSeen) ? p.chaptersSeen : [],
          fixations: typeof p.fixations === "number" ? p.fixations : 0,
          // Migration : une mémoire d'avant le 26/07 n'a pas le drapeau, or son
          // porteur a déjà joué — lui infliger le tuto serait absurde. On ne le
          // considère « à voir » que si le compte n'a jamais lancé de run.
          introSeen:
            typeof p.introSeen === "boolean"
              ? p.introSeen
              : (typeof p.runsStarted === "number" ? p.runsStarted : 0) > 0,
          lastDeath: p.lastDeath && typeof p.lastDeath === "object" ? p.lastDeath : undefined,
          // (Règle du 6/08, une fois de plus : tout champ nouveau DOIT entrer
          // ici dans le même geste, sinon il est perdu au rechargement.)
          surprises: p.surprises && typeof p.surprises === "object" ? p.surprises : undefined,
          lastPlayedAt: typeof p.lastPlayedAt === "number" ? p.lastPlayedAt : undefined,
          // ⚠️ Comme loadRun, cette reconstruction est CHAMP PAR CHAMP : tout
          // champ absent ici est silencieusement perdu au rechargement.
          // (Repris une fois de plus le 6/08 avec `lastAccueil` : l'accueil de
          // la vie précédente n'était jamais relu, donc jamais évité.)
          lastAccueil: typeof p.lastAccueil === "string" ? p.lastAccueil : undefined,
          visitesLieux: p.visitesLieux && typeof p.visitesLieux === "object" ? p.visitesLieux : {},
          vus: p.vus && typeof p.vus === "object" ? p.vus : {},
          faitsVus: p.faitsVus && typeof p.faitsVus === "object" ? p.faitsVus : {},
          renoncements: typeof p.renoncements === "number" ? p.renoncements : 0,
          zonesCleared: typeof p.zonesCleared === "number" ? p.zonesCleared : 0,
          profils: Array.isArray(p.profils) ? p.profils : [],
          derniereFinTraversee: Boolean(p.derniereFinTraversee),
          dernierSurvivant: typeof p.dernierSurvivant === "string" ? p.dernierSurvivant : undefined,
          faits: migrerSceau(sacDepuis(p.faits)),
          rencontres: rencontresDepuis(p.rencontres),
        };
      }
    } catch {
      // stockage indisponible/corrompu → mémoire neuve, jamais bloquant
    }
  }
  return fresh();
}

export function saveMemory(mem: PlayerMemory): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(mem));
  } catch {
    // quota plein / navigation privée : on continue en mémoire
  }
}

/** Applique une mutation puis persiste — le pont commode côté composant. */
export function mutateMemory(mutate: (mem: PlayerMemory) => void): PlayerMemory {
  const mem = loadMemory();
  mutate(mem);
  saveMemory(mem);
  return mem;
}

/**
 * Les saisons du Geôlier (§17) : trois postures discrètes, jamais un score.
 * Plus le joueur meurt vite et souvent, plus le Geôlier est blasé/moqueur ;
 * plus il survit longtemps / accumule des reliques rares, plus il devient
 * intrigué puis respectueux. Se ressent uniquement au choix des répliques.
 */
export type JailerPosture = "amuse" | "interesse" | "respectueux";

export function jailerPosture(mem: PlayerMemory): JailerPosture {
  const avg = mem.runsStarted > 0 ? mem.totalDays / mem.runsStarted : 0;
  if (mem.relicsRare >= 3 || mem.bestDays >= 21 || avg >= 12) return "respectueux";
  if (mem.bestDays >= 10 || avg >= 6 || mem.runsStarted >= 5) return "interesse";
  return "amuse";
}

/** Une dette de sang correspondant à cette entité existe-t-elle ? (§19) */
export function bloodDebtFor(mem: PlayerMemory, entity: string): BloodDebt | undefined {
  return mem.bloodDebts.find((d) => d.entity === entity);
}

/**
 * Courbe d'entrée invisible (spec 21/07, « à appliquer DÈS MAINTENANT ») :
 * les seuils sont légèrement adoucis durant les 2-3 premières morts du joueur,
 * puis l'aide s'estompe. Renvoie de combien ABAISSER le seuil d'un jet (0 =
 * plus d'aide). AUCUN affichage : le joueur sent juste que le jeu lui a laissé
 * le temps d'apprendre. Se lit sur `mem.deaths` (compteur central).
 */
export function entrySoftening(mem: PlayerMemory): number {
  const d = mem.deaths;
  if (d >= 3) return 0; // le joueur a appris — plus aucun coup de pouce
  return [2, 1, 1][d] ?? 0; // 1re run : −2 · après 1re mort : −1 · après 2e : −1
}

/**
 * Forge d'une Relique à la mort (spec §10) : commune / rare / légendaire.
 * Le nom vient d'un petit pool par rareté — contenu de proto, à enrichir.
 */
/**
 * Forge d'une Relique à la mort. Depuis le 5/08, le pool ET la rareté sortent
 * de `lib/reliques.ts` : c'est la CAUSE de la mort qui choisit la relique — une
 * corde ne forge pas la même chose qu'une noyade. `floorRare` = jalon de
 * première mort (spec 21/07) : la toute première perte donne un « fragment
 * fort », jamais une commune.
 */
export function forgeRelic(heroName: string, days: number, floorRare = false, cause = ""): Relic {
  const fiche = forgerRelique(cause, floorRare);
  // L'ancien `effect` reste posé pour les lectures qui ne connaissent que les
  // trois effets d'origine (fiches de menu, sauvegardes relues par du code
  // antérieur) — le DON de la fiche fait autorité côté moteur.
  const effect: RelicEffect =
    fiche.don === "faveur" ? "faveur" : fiche.don === "passe" ? "passe" : "coussin";
  return {
    name: fiche.nom,
    relicId: fiche.id,
    rarity: fiche.rarete,
    heroName,
    days,
    effect,
  };
}

/**
 * Enregistrement complet d'une mort (séquence 13/07) : héros au Registre,
 * relique forgée, dette de sang si un adversaire nommé a porté le coup.
 * Appelé AU MOMENT de la mort (pas à l'acceptation) : fermer l'app pendant
 * l'écran de mort ne doit jamais ressusciter la run (§9 inversé — la mort
 * fictionnelle, elle, est définitive).
 */
export function recordDeath(args: {
  heroName: string;
  days: number;
  /** Lieux franchis — le score du Registre (04/09). */
  franchis: number;
  cause: string;
  place: string;
  killer?: { entity: string; label: string };
  /** Mort par fixation (sociale, aux Landes) — nourrit le pool de citations. */
  fixation?: boolean;
  /** Acte le plus profond atteint par cette run (1 tant que seul l'Acte I existe). */
  acte?: number;
  /** Id de la scène de mort (radical) — nourrit la surprise « le retour ». */
  lieu?: string;
}): Relic {
  // Première mort du compte (jalon 21/07) : relique garantie rare+ (« fragment
  // fort »). Lu AVANT l'incrément de `deaths` ci-dessous — comme `bestBefore`,
  // qui sert au « meilleur score » du contexte de citations (30/07).
  const memBefore = loadMemory();
  const firstDeath = memBefore.deaths === 0;
  const bestBefore = memBefore.bestFranchis ?? 0;
  const relic = forgeRelic(args.heroName, args.days, firstDeath, args.cause);
  // STATISTIQUES (10/09) : la mort est l'événement central de la démo. Posée
  // ICI, au point de passage obligé, jamais dans un écran — l'aperçu des
  // Options ne passe pas par cette fonction, donc il ne compte jamais.
  track(
    "mort",
    { cause: args.cause, lieu: args.lieu ?? args.place, jour: args.days, franchis: args.franchis, mort_numero: memBefore.deaths + 1, fixation: args.fixation ?? false, rarete: relic.rarity },
    { instant: true }
  );
  finDeRun(); // la partie s'arrête ici : plus aucun événement ne lui appartient.
  mutateMemory((m) => {
    m.deaths += 1;
    m.totalDays += args.days;
    m.bestDays = Math.max(m.bestDays, args.days);
    m.bestFranchis = Math.max(m.bestFranchis ?? 0, args.franchis);
    m.fallen.unshift({ name: args.heroName, days: args.days, franchis: args.franchis, cause: args.cause, place: args.place, destin: "mort" });
    m.relics.push(relic);
    if (relic.rarity !== "commune") m.relicsRare += 1;
    if (args.killer && !m.bloodDebts.some((d) => d.entity === args.killer!.entity)) {
      m.bloodDebts.push({
        entity: args.killer.entity,
        label: args.killer.label,
        heroName: args.heroName,
        runIndex: m.runsStarted,
      });
    }
    // Contexte de la dernière mort (30/07) — ce que le pool de citations du
    // Geôlier lira au retour à l'accueil. `classed` se calcule sur la mémoire
    // DÉJÀ mise à jour (le héros vient d'entrer dans `fallen`).
    const classed = buildLesCent(m, args.heroName, args.franchis).some(
      (r) => r.isPlayer && !r.running && r.name === args.heroName && r.franchis === args.franchis
    );
    m.lastDeath = {
      day: args.days,
      fixation: args.fixation ?? false,
      rarity: relic.rarity,
      classed,
      acte: args.acte ?? 1,
      meilleurScore: args.franchis > bestBefore,
      lieu: args.lieu,
    };
    // La dernière fin de run est une MORT — l'accueil du Geôlier ne doit plus
    // parler de la traversée d'avant.
    m.derniereFinTraversee = false;
    m.lastPlayedAt = Date.now();
  });
  return relic;
}

/**
 * Le Grand Registre (§19) : classement des héros par LIEUX FRANCHIS. En
 * attendant l'endpoint agrégé réel (même besoin d'infra que « le fantôme de
 * passage »), on compose un classement local — quelques héros de fond figés +
 * les héros tombés DU JOUEUR (mémoire) + sa ligne de run en cours, insérée et
 * marquée. Trié par lieux franchis décroissants, rangs attribués ensuite.
 */
/** Le fond de l'écran de Registre joué EN SCÈNE. Même unité et même échelle
    que les Cent (rebasé le 04/09) : des lieux franchis, pas des jours. */
const REGISTRE_BASE: { name: string; franchis: number; cause: string }[] = [
  { name: "Anselme le Patient", franchis: 14, cause: "n'est pas mort — a disparu" },
  { name: "Brigga aux Deux Lames", franchis: 12, cause: "le pont d'os, au retour" },
  { name: "Sévrin", franchis: 10, cause: "a compté un crâne de trop" },
  { name: "La Veuve Koll", franchis: 9, cause: "n'a pas rendu ce qu'elle avait pris" },
  { name: "Otho", franchis: 8, cause: "la porte blanche, de l'intérieur" },
  { name: "Maerith", franchis: 7, cause: "l'écho a gardé son nom" },
  { name: "Dorn le Sourd", franchis: 6, cause: "n'a pas entendu la meute" },
  { name: "Ysolde", franchis: 4, cause: "un 1, au pire moment" },
  { name: "Corvin", franchis: 3, cause: "la main morte s'est refermée" },
  { name: "Vael", franchis: 2, cause: "l'anneau était un appât" },
];

export function buildRegistre(
  mem: PlayerMemory,
  playerName: string,
  playerFranchis: number,
  /** La cause de la ligne du joueur — « en cours » par défaut ; à la
      Descente, la traversée qu'on est en train d'inscrire. */
  playerCause = "— en cours —"
): RegistreRow[] {
  const rows: { name: string; franchis: number; cause: string; isPlayer?: boolean; destin?: Destin }[] = [
    ...REGISTRE_BASE.map((r) => ({ ...r })),
    ...mem.fallen.map((f) => ({
      name: f.name, franchis: f.franchis ?? f.days, cause: f.cause, isPlayer: true,
      destin: f.destin ?? destinDepuisCause(f.cause),
    })),
    {
      name: playerName, franchis: playerFranchis, cause: playerCause, isPlayer: true,
      destin: playerCause === "— en cours —" ? undefined : destinDepuisCause(playerCause),
    },
  ];
  rows.sort((a, b) => b.franchis - a.franchis);
  return rows.map((r, i) => ({ rank: i + 1, ...r }));
}

/** Compte un passage du COMPTE par un lieu (radical) — nourrit la mémoire
    des PNJ entre les vies (arbitrage Patrick 8/08 : « amplifier leur
    mémoire »). Appelé à l'arrivée d'une orientation. */
export function noterVisiteLieu(lieu: string): void {
  mutateMemory((m) => {
    m.visitesLieux = { ...(m.visitesLieux ?? {}), [lieu]: ((m.visitesLieux ?? {})[lieu] ?? 0) + 1 };
  });
}
