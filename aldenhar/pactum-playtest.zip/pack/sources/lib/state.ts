/**
 * Sauvegarde locale de la run — principe de sécurité (spec §9) :
 * fermer l'app / perdre la connexion ne compte jamais comme une mort.
 * L'état est persisté à chaque évènement et repris exactement où on l'a laissé.
 */

import { normalizeItem, startingBesace, type BesaceItem, type BesaceRarity } from "@/lib/besace";
import { traverseeGuidee } from "@/lib/demo";
import { ENTRY_SCENE, sceneAt, type MenaceId, type RouteFermeeCause } from "@/lib/scene-data";
import { type ZoneDef, type ZoneId } from "@/lib/zones";
import { cibleTotale, entrerLieu, ouvrirEtage, premierLieu, type EtageState } from "@/lib/etages";
import { profilDepuis, profilNeuf, type ProfilRun } from "@/lib/profil";
import type { Temoin } from "@/lib/temoins";
import { sacDepuis, type SacFaits } from "@/lib/faits";
import { rencontresDepuis, type Instantane } from "@/lib/memoire";

export type RollRecord = {
  step: number;
  choiceId: string;
  result: number;
  at: number;
  /** Le jet a-t-il TENU (palier non-échec) ? Sert au bilan de mort (26/07),
      seul endroit du jeu où des chiffres bruts sont autorisés. */
  ok?: boolean;
};

/** État narratif temporaire (spec §2) : modifie les jets, se dissipe. */
export type NarrativeEffect = {
  id: "aguerri" | "entaille" | "ebranle";
  label: string;
  delta: number;
  scenesLeft: number;
};

/**
 * Entrée du fil scrollable (spec §16) — le flux contient tout l'historique
 * de la run, jamais rien ne se décharge. Persisté intégralement pour que la
 * reprise de run restaure le scrollback exact, pas seulement la position.
 */
/** Une ligne du Grand Registre (§19) : un héros classé par LIEUX FRANCHIS
    (04/09 — le classement ne se fait plus sur les jours). */
export type RegistreRow = {
  rank: number;
  name: string;
  /** LIEUX FRANCHIS — l'unité du classement depuis le 04/09 (voir
      `lieuxEngages`). Le Jour reste dans la fiction, il ne classe plus. */
  franchis: number;
  cause: string;
  /** La ligne du joueur (run en cours ou héros tombé), visuellement distincte. */
  isPlayer?: boolean;
  /** Mort, traversée ou renoncement — un survivant ne se lit pas comme un mort. */
  destin?: "mort" | "traversee" | "renoncement";
};

export type FeedEntry =
  | { id: string; kind: "illustration"; src: string }
  | { id: string; kind: "day"; day: number }
  | { id: string; kind: "narration"; text: string }
  | { id: string; kind: "chosen"; label: string }
  | { id: string; kind: "jailer"; text: string }
  | { id: string; kind: "registre"; rows: RegistreRow[] }
  /** Bannière de rencontre : annonce clairement un combat (spec §6, lisibilité). */
  | { id: string; kind: "combat"; foe: string }
  /** Objet mineur obtenu (13/07) : bandeau tramé « Obtenu — … », pas de popup. */
  /** `usage` (10/08) : ce que l'objet FAIT, en mots. Les objets étaient
      muets — on ramassait une lame sans savoir qu'elle pesait sur les jets. */
  /**
   * OBTENU — la carte d'objet (maquette Figma 2531:825, 25/08). `rarity` est
   * le LIBELLÉ affiché (« Commun ») ; `rarete` est la CLÉ, dont dépendent les
   * trois traitements du tag (contour / plein blanc / plein orange). `icone`
   * est le chemin de l'asset réel de l'objet — une sauvegarde d'avant le
   * 25/08 n'en a pas, la carte retombe alors sur l'icône générique.
   */
  | {
      id: string;
      kind: "obtenu";
      name: string;
      rarity: string;
      flavor: string;
      usage?: string;
      rarete?: BesaceRarity;
      icone?: string;
    }
  /** États narratifs temporaires actifs, rappelés en tête d'écran après un
      jet (retour Patrick 19/07) — jamais un chiffre, seulement le nom. */
  | { id: string; kind: "etat"; effects: { effectId: string; label: string; positive: boolean }[] };

/**
 * Prix différé (spec §17) : un choix « gratuit » contracte une dette
 * silencieuse qui se règle plus tard dans la MÊME run (pas au niveau compte).
 * Le règlement doit rester rétrospectivement lisible (le joueur remonte le
 * transcript et comprend d'où ça vient), jamais totalement arbitraire.
 */
export type PendingDebt = {
  id: string;
  /** Pas de progression auquel la dette se déclenche. */
  settleAtStep: number;
  /** Texte narratif du règlement, inséré dans le fil au déclenchement. */
  text: string;
};

/**
 * Stats de personnalité de la run (Courage/Ruse/Instinct/Empathie, sur 1..5).
 *
 * ⚠️ ELLES N'EXISTENT PAS AU DÉPART (V2 du prologue, 06/09) : `RunState.stats`
 * vaut `undefined` tant que le Geôlier n'a pas assez vu pour les dessiner.
 * Ce n'est pas la même chose que « quatre valeurs neutres » — `statDe()` rend
 * 3 pour une stat absente, donc le modificateur de dé vaut 0 et les verrous à
 * seuil restent fermés, sans qu'aucun appelant ait à connaître cet état.
 * Elles apparaissent à la RÉVÉLATION, puis continuent de suivre en silence ce
 * que le héros fait (voir `lib/profil.ts`). Jamais un chiffre affiché : le
 * radar de l'écran Essence est leur seule forme visible.
 */
export type RunStats = {
  courage: number;
  ruse: number;
  instinct: number;
  empathie: number;
};

/**
 * Traversée (spec 21/07, chantier n°1) : la run ne parcourt plus les scènes en
 * ligne — elle traverse la zone par LIAISONS (marche + choix d'orientation) et
 * ne visite que 3-4 lieux avant la Descente (fin sèche). Persisté pour reprendre
 * la traversée exactement où elle en était (§9).
 */
export type TraversalState = {
  /** Écran courant : un lieu/rencontre ("scene") ou une liaison ("liaison"). */
  phase: "scene" | "liaison";
  /** Id de la scène courante (quand phase = "scene"). */
  current: string;
  /** Lieux/rencontres déjà visités cette traversée (dédup, chaîne = 1). */
  visited: string[];
  /** Nombre de lieux à visiter avant la Descente (3 ou 4, fixé au départ). */
  target: number;
  /** Les 2 destinations offertes à la liaison courante (quand phase = "liaison"). */
  liaisonOpts: [string, string] | null;
  /** Cette Croisée-ci n'offre qu'une direction (échec dur au coup d'avant).
      Porté par `trav` — donc reconstruit à l'identique à la reprise. */
  routeFermee?: boolean;
  /** Pourquoi (03/09) — la Croisée fermée nomme l'acte qui l'a fermée, à la
      reprise aussi. */
  routeFermeeCause?: RouteFermeeCause;
  /** La liaison courante est la SORTIE du village (24/08) : couture
      FRANCHIT_SORTIE en tête + Croisée de lande. Porté par `trav` pour que la
      reprise rebâtisse le MÊME écran (texte de sortie, image de lande) — sans
      lui, `sceneFromTrav` rendrait une marche de ruelle. NB : `trav` est
      rechargé en bloc par `loadRun` (pas champ par champ), un optionnel neuf
      survit sans migration. */
  sortieHameau?: boolean;
  /** LE SILLAGE DU VER (Salines, 16/09) : la liaison courante porte la
      tranchée fraîche à la place de son ambiance, avec son image. Porté par
      `trav` pour que la reprise rebâtisse le MÊME écran ; remis à faux à
      chaque nouvel écran, comme `sortieHameau`. */
  verSillage?: boolean;
  /** LE DÉPART DE LA LANDE (vague 3, 25/09) : la liaison courante est la
      toute première marche de la vie — on tourne le dos à la Borne et la
      colonne de cordes se voit au sud. Porté par `trav` pour que la reprise
      rebâtisse le MÊME écran ; remis à faux à chaque nouvel écran. */
  landeDepart?: boolean;
  /** LE VER SOUS LES PIEDS (les Bassins, 16/09) : `verAppele` est posé par
      un choix qui appelle le Ver (le grincement de la Noria, le raccourci
      de la Guérite) ; la Croisée suivante le consomme et pose `verDessous`,
      qui habille CETTE liaison — la croûte qui bombe — et se rebâtit à la
      reprise comme `verSillage`. Jamais les deux à la fois. */
  verAppele?: boolean;
  verDessous?: boolean;
  /** LE BESTIAIRE DU CHANTIER (19/09) : nombre de lieux visités au moment
      du dernier déroutage d'une Croisée des Salines — au plus UNE rencontre
      entre deux lieux, sinon la Croisée qui suit la rencontre en tirerait
      une autre. Comparé à `visited.length`, jamais persisté ailleurs. */
  derouteA?: number;
  /** Radicaux de lieu déjà crédités dans `lieuxEngages` cette traversée.
      Empêche un lieu à rencontre optionnelle de compter trois fois — voir
      le docblock de `RunState.lieuxEngages`. */
  credites?: string[];
  /** Graine de la liaison courante — garde ambiance/options stables à la reprise. */
  seed: number;
  /** Descente atteinte : la traversée est finie (nœud terminal). */
  done: boolean;
  /**
   * TRAVERSÉE À ÉTAGES (12/09, lib/etages.ts) : où l'on en est dans la suite
   * des environnements d'une zone qui en déclare. Absent pour les Landes
   * (pool plat). Porté par `trav`, donc rechargé en bloc à la reprise — la
   * Croisée d'étape se rebâtit à l'identique.
   */
  etage?: EtageState;
};

export function freshTraversal(current = ENTRY_SCENE): TraversalState {
  return {
    phase: "scene",
    current,
    visited: [current],
    // 7 ou 8 lieux avant la Descente. Le ×3 du 24/07 (9-11) rendait la
    // traversée interminable en jeu réel (partie de découverte 8/08 : 86
    // écrans, Jour 3, toujours pas au bout) — et le durcissement du dernier
    // tiers tombe maintenant assez tôt pour se sentir.
    // ⚠️ PREMIÈRE RUN (la traversée guidée, 2/09) : cible FIXE à 8. La route
    // scriptée compte 6 lieux + la Borne = 7 ; à 7 la Halte se déclenchait
    // avant la sortie du village et faisait dormir DEUX fois (la nuit
    // scriptée, puis la grange) — un tirage sur deux, en silence. À 8, le
    // village se quitte par le portillon, la Meute et la Falaise suivent.
    target: traverseeGuidee() ? 8 : 7 + Math.floor(Math.random() * 2), // 7 ou 8 lieux
    liaisonOpts: null,
    seed: 0,
    done: false,
  };
}

export type RunState = {
  /** Nom du héros de cette run (dette de sang, Grand Registre — spec §19). */
  heroName: string;
  /** Progression dans le parcours infini (0 = première scène). */
  step: number;
  /** Jour courant — n'avance qu'aux campements (spec §7). */
  day: number;
  /** Santé 0..1 — jamais affichée : elle se lit dans l'érosion de l'UI (spec §5). */
  health: number;
  effects: NarrativeEffect[];
  rolls: RollRecord[];
  lastChoiceId: string | null;
  feed: FeedEntry[];
  /** Écrans RESTANTS de la séquence de micro-beats (doctrine 4/08) — la
      reprise rejoue l'écran courant puis la suite, jamais la pile entière.
      Optionnel : les sauvegardes d'avant n'ont pas le champ. */
  feedSuite?: FeedEntry[][];
  /** ⚠️ HÉRITÉ (avant la Descente du 20/08) : l'unique relique portée avait
      dépensé son geste. Les nouvelles écritures passent par `reliquesUsees` ;
      un `true` ici (run en cours au moment de la migration) est lu comme
      « tous les gestes dépensés » — conservateur, une seule vie concernée. */
  relicUsed?: boolean;
  /** LA DESCENTE (20/08) : index (dans `mem.relics`) des reliques portées
      dont le geste — amorti, passe, silence — a été consommé CETTE vie.
      Chaque relique portée a son geste : trois amortis = trois chocs pris. */
  reliquesUsees?: number[];
  /** Ambiances de liaison déjà SERVIES cette run — un événement de voyage ne
      revient jamais verbatim dans une même vie (retour test 4/08). Complétée
      en QUITTANT la liaison, pour que sa reprise reste déterministe. */
  liaisonVues?: string[];
  /** Lignes intruses de HANTÉ déjà servies cette run — jamais deux fois la
      même phrase « qui n'appartient pas là » dans une vie (playtest 7/08). */
  intrusesVues?: string[];
  /** Réactions du monde (états) déjà servies cette run — même règle que les
      intruses : jamais deux fois mot pour mot dans la même vie (8/08). */
  reactionsVues?: string[];
  /** Échos d'objets-promesse déjà servis (« scène|objet ») — un objet ne
      pèse qu'une fois par endroit (8/08). */
  echosObjet?: string[];
  /** Noms des soins génériques déjà trouvés cette run — un objet « trouvé »
      ne retombe jamais sous le même nom dans la même vie (playtest 7/08). */
  /** Registre de déjà-vu, portée RUN (lib/dejavu.ts) — un compteur par clé,
      jamais un booléen : le texte peut dire « la deuxième fois ». */
  vus?: Record<string, number>;
  /** La PHOTO de la mémoire des rencontres, prise à la première entrée de
      chaque clé dans cette vie (lib/memoire.ts). Toute la vie lit la photo :
      la scène ne change pas sous les yeux, et la reprise sert le même texte. */
  memoireVue?: Instantane;
  /**
   * A-T-ON ENGAGÉ QUELQUE CHOSE DANS CE LIEU ? (panel 10/08)
   *
   * Mesuré par le panel : traverser la zone en ne lançant presque jamais le dé
   * est la stratégie gagnante — 0 mort sur 16 vies, contre 8 sur 16 en le
   * lançant. Le pilier central du jeu était devenu facultatif.
   *
   * ⚠️ LE LEVIER D'ABORD RETENU — « le refus coûte un JOUR » — A ÉTÉ ANNULÉ
   * PAR PATRICK LE 10/08, et ce paragraphe ne subsiste que pour empêcher de
   * le réinventer : le Jour est le SCORE du Registre, donc facturer un Jour
   * au joueur passif le faisait MONTER au classement. Voir `lieuxEngages`
   * ci-dessous pour la règle réellement en vigueur (le Jour se gagne).
   *
   * Ce qui reste vrai ici : **l'observation est gratuite** (arbitrage du
   * 8/08), et ce drapeau est posé au LANCER — pas à la réussite.
   *
   * Posé à la résolution d'un jet, remis à faux en arrivant dans un lieu neuf.
   */
  engageIci?: boolean;
  /** L'engagement du lieu qu'on vient de QUITTER, gardé au moment où
      `engageIci` est remis à zéro en entrant dans la liaison (03/09). */
  engageAvantReset?: boolean;
  /**
   * LIEUX RÉELLEMENT VÉCUS — le compteur qui fait avancer le Jour.
   *
   * ⚠️ CORRECTION IMPORTANTE (retour Patrick, 10/08). J'avais fait PAYER un
   * Jour au joueur qui quitte un lieu sans avoir rien risqué. C'était à
   * l'envers : ce compteur EST le score du Grand Registre, donc ma
   * « punition » donnait des points au joueur le plus passif. Une punition
   * qui améliore le classement n'est pas une punition.
   *
   * ⚠️ 04/09 : le Registre classe désormais sur CE compteur tel quel (les
   * lieux franchis), plus sur le Jour qui en dérive. Le Jour reste le repère
   * de fiction ; il ne classe plus.
   *
   * Le sens est donc inversé : **le Jour ne se perd pas, il se GAGNE**. Il
   * avance tous les trois lieux où le héros a réellement tenté quelque
   * chose. Traverser les Landes sans rien risquer reste possible — mais ce
   * temps-là ne se dépose sur personne, et le Registre ne le compte pas.
   *
   * ⚠️ UN LIEU NE COMPTE QU'UNE FOIS PAR TRAVERSÉE (`trav.credites`, corrigé
   * le 10/08). Le crédit se prend au changement de RADICAL d'id, or un lieu
   * qui ouvre une rencontre en franchit trois (verger-noir → epoux →
   * verger-noir-2 → liaison) : prendre la rencontre optionnelle valait donc
   * trois lieux au lieu d'un, soit un Jour entier offert pour un détour.
   * Cinq lieux ont une rencontre de ce type.
   *
   * RÈGLE GÉNÉRALE À TENIR : aucune mécanique ne doit jamais ajouter un Jour
   * à titre de sanction. Le Jour est un score et une pression (les Besoins
   * se comptent en jours) ; il se mérite, il ne se facture pas.
   */
  /**
   * ⚠️ C'EST LE SCORE DU GRAND REGISTRE depuis le 04/09, tel quel — plus
   * divisé par trois ni rebaptisé « Jour ». Un lieu compte UNE fois, quand le
   * héros y a engagé quelque chose et en est ressorti vivant (mourir sur
   * place termine la run avant le crédit, donc la condition est structurelle).
   *
   * Pourquoi le changement : le Jour n'a aucune fiction dans un pays où le
   * crépuscule ne tombe jamais. On avait donc inventé « un jour tous les trois
   * lieux engagés » — une règle que personne ne pouvait deviner (0 testeur sur
   * 5 l'a comprise, 2 l'ont comprise à l'envers), et qui écrasait l'amplitude
   * de quinze à cinq. Le classement lit maintenant le compteur directement :
   * « 8 lieux franchis » se comprend sans explication.
   */
  lieuxEngages?: number;
  /**
   * L'HORLOGE DU CORPS — ce sur quoi les Besoins se comptent.
   *
   * ⚠️ Effet de bord trouvé par la relecture du 10/08. Les Besoins (soigner
   * 2 j · dormir 3 j · manger 3 j) se comptaient sur `day`. En recentrant le
   * Jour sur l'ENGAGEMENT, je les ai déplacés sans le décider : le joueur
   * passif ne gagnait plus de Jour, donc **il n'avait plus jamais faim** — le
   * dernier vecteur de pression qui l'atteignait, coupé par le commit dont le
   * titre est « rendre le dé décisif » ; et symétriquement le joueur engagé se
   * retrouvait affamé plus tôt, puni de s'être engagé.
   *
   * Les deux horloges sont donc séparées, et chacune mesure ce qu'elle doit :
   *  - `day` = le SCORE (Registre) — il se gagne en vivant, cf. `lieuxEngages` ;
   *  - `horloge` = le TEMPS DU CORPS — il avance tous les trois lieux
   *    traversés, quoi qu'on y fasse, et à chaque nuit. Marcher creuse
   *    l'estomac qu'on ait risqué sa peau ou non.
   *
   * Jamais affichée, jamais comparée au Jour par le joueur : il ne voit que
   * l'état qui finit par tomber. Le garde-fou n°2 de `lib/besoins.ts` — « le
   * besoin punit la lenteur » — redevient vrai avec elle.
   */
  horloge?: number;
  /**
   * Points d'intérêt examinés DANS LE LIEU COURANT (panel 10/08).
   *
   * Chacun ouvre l'Anneau d'un cran, au plus deux. C'est la réponse au
   * constat le plus dur du panel : « l'anneau bouge, mais avec ce que je
   * porte, jamais avec ce que je tente. » Regarder avant d'agir devient la
   * seule chose qui améliore vraiment un jet — le curieux est payé là où le
   * jeu fait mal, le pressé garde les chances brutes. Aucun chiffre :
   * l'Anneau montre simplement plus d'encoches pleines.
   *
   * Remis à zéro en arrivant dans un lieu neuf.
   */
  poiIci?: number;
  /**
   * UN ÉCHEC DUR DOIT DÉPENSER QUELQUE CHOSE DU MONDE (panel 9/08).
   * Sur un écran de séjour, il consomme une option (voir `choixFaits`). Hors
   * séjour, il n'y a pas d'option à retirer — on arme donc ce drapeau, et la
   * prochaine Croisée n'offre plus qu'UNE direction. Le coût est diégétique
   * (le monde se referme), jamais un prélèvement de santé de plus : le panel
   * a explicitement écarté le re-durcissement du barème.
   */
  routeFermeeEnAttente?: boolean;
  /** La cause qui accompagne le drapeau ci-dessus (03/09). */
  routeFermeeCause?: RouteFermeeCause;
  /**
   * LA MENACE LAISSÉE ACTIVE (compte rendu 17/08, §2 : « une menace évitée
   * peut rester dans le monde »). Contourner la Meute à la Croisée ou se
   * dérober à la Bête ne les EFFACE plus : la menace suit, laisse des traces
   * en liaison (la causalité doit être lisible AVANT le retour), puis revient
   * une fois — et la préparation transforme ce retour (clochette, découverte).
   * ⚠️ AU PLUS UNE menace active par vie (garde-fou du même document : « ne
   * pas transformer la run en liste invisible de dettes ») — la première
   * posée tient le seul créneau, les suivantes ne s'enregistrent pas.
   * `poseeA` = taille de `trav.visited` au moment de la pose (le retour ne
   * peut tomber qu'à ≥ 2 lieux de là) ; `traces` = combien de traces déjà
   * servies (au moins une AVANT tout retour, par construction).
   */
  menace?: { id: MenaceId; poseeA: number; traces: number } | null;
  /**
   * LE KARMA DU PRUDENT (retour Patrick 11/09 : « le joueur prudent qui évite
   * toujours de choisir le dé doit être plus confronté à des monstres »).
   *
   * Ce n'est PAS une jauge cachée de prudence (refusée le 17/08) : c'est la
   * comptabilité que les Landes tiennent déjà. Le compteur suit les lieux
   * QUITTÉS SANS RIEN Y ENGAGER, d'affilée — le miroir exact de
   * `lieuxEngages`, qui compte ceux où l'on a tenté quelque chose. Engager
   * n'importe où le remet à zéro : on n'accumule pas une dette, on laisse une
   * ligne ouverte, et elle se solde dès qu'on paie.
   *
   * À trois lignes ouvertes, le créneau `menace` s'arme sur le Recousu — donc
   * traces en liaison AVANT tout retour, et jamais plus d'une menace à la
   * fois : le garde-fou du 17/08 vaut aussi pour celle-ci.
   *
   * ⚠️ LE COMPTE NE SE TIENT QU'EN PLEINE LANDE, et c'est voulu : les traces
   * du Recousu (comme son retour) sont gardées « lande », donc un compte
   * ouvert pendant qu'on est dans le Hameau ne se lit ni ne se solde là-bas.
   * Dans le village, c'est le village qui tient les comptes — le Soupçon.
   */
  lignesOuvertes?: number;
  /**
   * LES TÉMOINS (5/08) : le Soupçon cesse d'être un compteur, il devient des
   * gens. Chaque acte qui fait monter le Soupçon inscrit QUI a vu QUOI, dans
   * l'ordre. Au procès, ce sont ces dépositions qui sont lues.
   */
  temoins?: Temoin[];
  /** Témoins déjà cités DANS LA RUE (rumeur, 8/08) — le procès commence
      avant la salle, mais chaque témoin ne parle qu'une fois dehors. */
  temoinsCites?: string[];
  /**
   * LE PROCÈS CONCLUT (panel 10/08).
   *
   * Une relaxe faisait retomber le Soupçon de 6 à 4, mais laissait les
   * dépositions en place : six écrans plus loin, le hameau rejugeait le héros
   * sur EXACTEMENT les mêmes griefs, avec les mêmes témoins et les mêmes
   * phrases. Un testeur y est mort sans jamais comprendre ce qu'il aurait pu
   * faire autrement. Le jugement rendu épuise donc les dépositions qu'il a
   * jugées (on ne juge pas deux fois les mêmes actes) : un second procès
   * exige de NOUVEAUX actes. Ce compteur sert à le dire dans la salle.
   */
  procesGagnes?: number;
  /**
   * TÉMOINS DÉJÀ JUGÉS (relecture par agents, 10/08).
   *
   * La relaxe VIDAIT `temoins` pour que le second procès porte sur de
   * nouveaux actes. Effet non vu : `defensesDisponibles` lit la même liste —
   * « discréditer » exige un témoin nommé, « émouvoir » un témoin du hameau.
   * Sans témoins, le second procès n'offrait plus que « Tout reconnaître »,
   * seuil 13 et highStakes. **Gagner son procès rendait le suivant mortel** :
   * une récompense qui dégrade, exactement ce que le brief d'économie
   * interdit.
   *
   * Les dépositions restent donc en place, marquées jugées : elles sortent de
   * l'ACTE D'ACCUSATION (on ne juge pas deux fois les mêmes actes) mais
   * continuent d'ouvrir les défenses — on peut toujours discréditer les mêmes
   * gens.
   */
  temoinsJuges?: string[];
  /**
   * LA LOI DU DOMAINE (5/08) : index des manifestations déjà servies cette run.
   * La loi se constate, elle ne se martèle pas — au plus une par vie.
   */
  loiVues?: number[];
  /**
   * LE GEÔLIER : gabarits de citations déjà servis dans cette vie (retour
   * Patrick 8/08 : « il répète souvent les mêmes phrases dans une même run »).
   * On mémorise le GABARIT (avant substitution de {n}) : sinon un 4 et un 11
   * feraient passer deux fois la même phrase pour neuve. Quand un pool est
   * épuisé, le tirage reprend dedans — mieux vaut une reprise tardive qu'un
   * Geôlier muet.
   */
  jailerVues?: string[];
  /**
   * ARRIVÉE : phrases de « manière d'arriver » déjà servies dans cette vie.
   * Variation narrative pure (décision Patrick 5/08) — aucune conséquence
   * mécanique ; seule l'anti-répétition la concerne.
   */
  arriveeVues?: string[];
  /**
   * LE MOTEUR DE FAITS (spec 4/08 §1) — scopes `run` et `zone_run` : états,
   * savoirs, soupçon. Meurent avec le héros. Les scopes permanents vivent dans
   * `PlayerMemory.faits`. Optionnel : les sauvegardes d'avant n'ont rien.
   */
  faits?: SacFaits;
  /**
   * BESOINS (spec §3) : id de besoin → dernier JOUR où on y a répondu. En
   * jours, jamais en scènes — garde-fou n°2. Aucun compteur n'est jamais
   * montré : le besoin ne se manifeste que par l'état qu'il finit par poser.
   */
  besoins?: Record<string, number>;
  /** Croisées jouées depuis la dernière route forcée par le directeur. */
  croiseesDepuisRoute?: number;
  /** Rencontres programmées par un effet (recouvrement de dette…). */
  /** ⚠️ DÉCLARÉ, PERSISTÉ, JAMAIS LU (relecture par agents, 10/08). Il voyage
      dans chaque sauvegarde sans rien faire. Conservé parce que le champ est
      inoffensif et que le système de rencontres différées reste au programme —
      mais tant qu'aucun code ne le lit, ne pas le croire actif. */
  rencontresDues?: { scene: string; auPas: number }[];
  /**
   * L'ÉLÉMENT-SURPRISE de cette run (catalogue 6/08) — AU PLUS UN, armé au
   * premier pas, joué quand son contexte arrive (ou jamais : perdu, tant pis).
   * `jouee` verrouille le plafond ; le Geôlier métaleptique, hors armement,
   * écrit directement ici pour respecter le même plafond.
   */
  surprise?: { id: string; jouee?: boolean };
  /**
   * LE JOURNAL DES CHOIX CITABLES (socle commun des surprises 6/08) : les
   * libellés réels des choix tagués `citable`, avec leur pas. Nourrit « le
   * PNJ qui te cite » et la récitation du Grand Témoin. Plafonné à 20.
   */
  journalChoix?: { t: string; step: number }[];
  /** La prophétie datée (surprise #4) : le jour parié par le Geôlier. */
  prophetie?: number;
  /** Le vol nocturne (surprise #8) : NOM de l'objet volé — retenu pour un
      paiement futur (le reconnaître au cou de quelqu'un). */
  volNocturne?: string;
  /** États déjà ANNONCÉS par le bandeau (retour 6/08 soir : le bandeau ne se
      répète plus à chaque écran — il n'annonce que ce qu'on vient d'attraper). */
  etatsAffiches?: string[];
  /** Carte d'état en cours (maquette 2440:13429, 7/08) : elle reste affichée
      LE TEMPS DE LA SCÈNE où l'état a été attrapé (tous ses beats), puis
      quitte l'interface — et le popup « c'est dans le menu » peut se montrer. */
  etatBanniere?: { effects: { effectId: string; label: string; positive: boolean }[]; lieu: string };
  /** Dettes narratives en attente de règlement dans cette run (spec §17). */
  debts: PendingDebt[];
  /** Besace (13/07) : objets mundane, vidée à la mort. */
  besace: BesaceItem[];
  /** Objets réels des Landes déjà ramassés dans cette run (chantier 1 du 23/07) —
      un lieu ne redonne jamais deux fois son objet. */
  looted: string[];
  /** Rencontres (scènes de combat) traversées vivant — pour l'écran de mort. */
  encounters: number;
  /** Stats de la run (affichage Essence seulement pour l'instant). */
  /**
   * LE PROFIL DE CETTE VIE — **undefined tant que le Geôlier n'a pas dessiné**
   * (V2 du 06/09). Ce n'est pas un détail de typage : c'est la différence
   * entre « personne ne sait encore qui est cette incarnation » et « voici
   * ton build de départ ». `statDe()` rend 3 pour une stat absente, donc un
   * héros indéterminé n'a ni bonus de dé, ni verrou à seuil ouvert, ni
   * variante de dominante — sans qu'aucun appelant ait à le savoir.
   */
  stats?: RunStats;
  /** Ce que ses décisions ont appris de lui, et s'il a déjà été dessiné. */
  profil: ProfilRun;
  /** L'ouverture de cette vie (pacte à la 1re, retour aux suivantes) est jouée. */
  ouverture: boolean;
  /** Traversée de la zone (spec 21/07) : liaisons + choix d'orientation. */
  trav: TraversalState;
  /**
   * LA VIE MULTI-ZONES (décision Patrick 12/09) — voir lib/zones.ts.
   * `zone` est la zone que `trav` traverse ; `zonesFranchies` les zones déjà
   * laissées derrière soi dans cette vie, dans l'ordre. Une vie s'ouvre aux
   * Landes et descend ; la Besace, la santé, le Jour et les états la suivent
   * d'une zone à l'autre (`franchirZone`). Absents d'une sauvegarde d'avant
   * le 12/09 → « landes », rien de franchi : exactement ce qu'elle vivait.
   */
  zone?: ZoneId;
  zonesFranchies?: ZoneId[];
  /**
   * L'ENCROÛTÉ (les Salines, 13/09) — « bouger attire le Ver, s'arrêter
   * attire le sel ». Palier 0..3, monté à chaque action qui reste sur place
   * dans la zone, redescendu d'un cran à chaque lieu atteint. Il ne modifie
   * AUCUN jet : il se lit sur les CTA (le sel gagne les bordures, puis les
   * lettres), et au palier III le Geôlier le constate. Jamais un chiffre.
   */
  encroute?: number;
  /** Les scènes dont la tempête de sel a déjà été balayée cette vie. */
  tempetesJouees?: string[];
  /**
   * LA SOIF (les Bassins, 16/09) — le Besoin de zone de la bible : « monte
   * par scène, jamais en temps réel. Haute : un mot sur trois dans les choix
   * est remplacé par un bloc de pixels blancs. » Palier 0..3, monté d'un cran
   * tous les DEUX lieux atteints à partir des Bassins (`soifPas` compte les
   * lieux entre deux crans ; la Gourde double, quand elle existera, doublera
   * la cadence). Elle ne modifie AUCUN jet et ne tue jamais : elle se LIT sur
   * les CTA (les mots qui blanchissent), elle se dit une fois par palier, et
   * au palier III le corps paie un peu à chaque lieu. Se soulage en buvant
   * (`Choice.soif` négatif). Remise à zéro en entrant dans une zone.
   */
  soif?: number;
  soifPas?: number;
  /**
   * LA FIXATION DES DÉCLARÉS (le Bassin des Déclarés, 16/09) — l'exception
   * NOMMÉE à la doctrine « jamais un bonus de jet » : toucher la silhouette
   * qui fait le geste de ta dominante fixe le héros dans ce geste jusqu'à la
   * fin de la zone. Les jets sur la stat forte sont plus faciles d'un cran,
   * ceux sur la stat faible plus durs d'un cran. C'est la Fixation elle-même
   * (celle que le village des Landes pratique à la corde), pas une
   * récompense — et c'est pourquoi c'est le seul lieu du jeu qui touche un
   * seuil. Remise à null en entrant dans une zone.
   */
  fixationDeclaree?: { forte: string; faible: string } | null;
  /**
   * Chapitre garanti de la traversée (chantier 2 du 23/07) : id d'un chapitre
   * de `LANDES_CHAPTERS` + stade (0 = pas amorcé, 1 = amorcé, 2 = développé,
   * 3 = résolu). Tiré au début d'une run neuve (Scene, avec la mémoire du
   * compte pour la rotation) ; null tant que rien n'est tiré.
   */
  chapter: { id: string; stage: 0 | 1 | 2 | 3 } | null;
  /**
   * Le Soupçon (chantier 3 du 23/07) : 0..6, JAMAIS affiché — il ne se lit que
   * dans le monde (paliers). 6 = procès du héros. Remis à 0 à chaque run.
   */
  soupcon: number;
  /** Dernier palier du Soupçon déjà MANIFESTÉ dans le monde (évite de rejouer
      la même manifestation ; redescend avec le Soupçon après un procès). */
  soupconSeen: number;
  /** Points d'intérêt déjà examinés dans le LIEU COURANT (spec 24/07 suite) —
      vidé en quittant le lieu. Un point exploré ne se re-propose pas. */
  poiSeen: string[];
  /** Choix déjà RÉSOLUS sur une scène `sejour` (`"<scène>:<choix>"`). Un lieu
      qui retient le héros doit se souvenir de ce qu'il y a déjà fait, sinon on
      rejoue indéfiniment la même question. Vidé en quittant le lieu, comme
      `poiSeen` — c'est le même geste, côté choix. */
  choixFaits: string[];
  /**
   * Le Hameau (spec 24/07 suite §3) : on ne le « visite » pas, on y fait
   * HALTE. Deux séquences garanties hors tirage encadrent la traversée —
   * l'Entrée (première arrivée) et la Halte (nuit, avant la sortie de zone).
   * `serment` conditionne la Halte : juré → la grange ; refusé → nuit dehors.
   */
  hameau: {
    entree: boolean;
    serment: "jure" | "faux" | "refuse" | null;
    /**
     * UNE CLAUSE DU SERMENT A ÉTÉ ROMPUE (correctif 14/08). Posé par tout
     * choix `rompLeSerment` — parler à un pendu, y toucher, regarder le sud.
     *
     * C'est ce qui permet à `apportsProces` de savoir si le Serment a été
     * TENU sans passer par le Soupçon, qui est au maximum au moment du
     * procès et rendait donc la défense inatteignable.
     */
    sermentRompu?: boolean;
    halte: boolean;
    /**
     * SORTI DU VILLAGE (chantier fluidité 12/08, §3). Le Hameau devient une
     * ENCLAVE : tant qu'on y est, la Croisée n'offre que des lieux du village ;
     * en sortir est une décision, elle est racontée, et une fois dehors le
     * village n'est plus tirable de la vie.
     *
     * ⚠️ Le défaut corrigé n'était PAS « on entre deux fois ». Cinq des dix-sept
     * destinations tirables sont à l'intérieur du village : une fois entré, le
     * générateur ne retirait que la PORTE, donc la Chapelle ou le Tribunal
     * revenaient comme destinations ordinaires au milieu des lieux de lande.
     * On ressortait et on rentrait plusieurs fois par vie sans qu'aucune
     * entrée ne soit racontée. C'était une absence de frontière.
     */
    sorti?: boolean;
    /** L'ACCUEIL du jour (6/08) : id de la scène tirée pour le 3e beat de
        l'entrée. Rangé ici dès le tirage — la reprise ne re-tire jamais, sinon
        fermer l'app changerait la façon dont le village t'a reçu. */
    accueil?: string;
  };
  /**
   * Le SAVOIR (journal Notion 25/07 — « rendre l'exploration payante »).
   *
   * Flags d'information APPRISE en examinant un point d'intérêt. Un Savoir
   * n'ajoute jamais de puissance : il ouvre une **option qui n'existait pas**
   * dans une scène ultérieure (`Choice.requiresSavoir`). Aucun chiffre, aucune
   * stat, aucun marqueur « débloqué » tapageur — le choix apparaît comme les
   * autres.
   *
   * ⚠️ Portée = LA RUN. Le héros apprend, il meurt, le suivant repart neuf :
   * vidé à la mort exactement comme la Besace. Seules les Reliques traversent
   * la mort (pilier inchangé).
   *
   * Un Savoir n'est pas toujours une bonne carte : certaines options ouvertes
   * sont des aveux ou des paris (cf. le poteau gravé à ton nom).
   */
  savoirs: string[];
  /**
   * Fragments de chapitre déjà lus dans cette run (4e monnaie du dosage des
   * points d'intérêt). Index dans `Chapter.fragments` du chapitre courant :
   * un point d'intérêt qui « rend un fragment » sert le premier non encore lu.
   */
  fragmentsLus: number[];
};

/** Clé de la run en cours. Exportée pour l'APERÇU DU PROLOGUE (Options), qui
    doit sauvegarder puis restaurer la run telle quelle, octet pour octet —
    une seconde copie de ce littéral ailleurs finirait par diverger. */
export const RUN_KEY = "aldenhar-run";
const KEY = RUN_KEY;

const HERO_NAMES = [
  "Corvin", "Vael", "Ysolde", "Brannoc", "Maerith", "Dorn", "Sélène",
  "Karth", "Ombrelin", "Thessaly", "Rœric", "Nyx", "Aldric", "Vesper",
];

/** Nom de héros aléatoire (dette de sang / Registre — spec §19). */
export function randomHeroName(): string {
  return HERO_NAMES[Math.floor(Math.random() * HERO_NAMES.length)];
}

/**
 * Anciennes sauvegardes : stats sur 10 → ramenées à l'échelle 1..5.
 * ⚠️ On n'INVENTE plus de profil au repli (le tirage aléatoire d'avant le
 * 06/09 est retiré) : une sauvegarde dont l'objet est malformé retombe sur le
 * neutre, qui est ce que `statDe` rend déjà pour une stat absente. Inventer
 * une identité à quelqu'un qui en avait une serait pire que ne rien dire.
 */
function migrateStats(p: Partial<RunStats> | undefined): RunStats {
  if (!p || typeof p.courage !== "number") return { courage: 3, ruse: 3, instinct: 3, empathie: 3 };
  const fix = (v: number) => Math.max(1, Math.min(5, v > 5 ? Math.round(v / 2) : v));
  return {
    courage: fix(p.courage),
    ruse: fix(p.ruse ?? 3),
    instinct: fix(p.instinct ?? 3),
    empathie: fix(p.empathie ?? 3),
  };
}

function fresh(): RunState {
  return {
    heroName: randomHeroName(),
    step: 0,
    day: 1,
    horloge: 1,
    health: 1,
    effects: [],
    rolls: [],
    lastChoiceId: null,
    feed: [],
    debts: [],
    besace: startingBesace(),
    looted: [],
    encounters: 0,
    // ⚠️ AUCUNE STAT AU DÉPART, et aucun souvenir tiré : le questionnaire du
    // Seuil est retiré du chemin (V2 du 06/09). Le héros n'est encore
    // personne ; ce sont ses décisions qui le dessineront.
    profil: profilNeuf(),
    ouverture: false,
    trav: freshTraversal(),
    zone: "landes",
    zonesFranchies: [],
    encroute: 0,
    tempetesJouees: [],
    soif: 0,
    soifPas: 0,
    fixationDeclaree: null,
    chapter: null,
    soupcon: 0,
    soupconSeen: 0,
    poiSeen: [],
    choixFaits: [],
    hameau: { entree: false, serment: null, halte: false },
    savoirs: [],
    fragmentsLus: [],
    temoins: [],
    temoinsCites: [],
    procesGagnes: 0,
    temoinsJuges: [],
    loiVues: [],
    jailerVues: [],
    arriveeVues: [],
    faits: {},
    besoins: {},
    croiseesDepuisRoute: 0,
    rencontresDues: [],
    memoireVue: {},
  };
}

/** Réinitialisation explicite (mort acceptée) : nouvelle run, nouveau héros. */
export function resetRun(): RunState {
  const run = fresh();
  saveRun(run);
  return run;
}

export function loadRun(): RunState {
  if (typeof window !== "undefined") {
    try {
      const raw = window.localStorage.getItem(KEY);
      if (raw) {
        const p = JSON.parse(raw) as Partial<RunState>;
        if (typeof p.step === "number") {
          return {
            heroName: typeof p.heroName === "string" ? p.heroName : randomHeroName(),
            step: p.step,
            day: typeof p.day === "number" ? p.day : 1,
            health: typeof p.health === "number" ? p.health : 1,
            effects: Array.isArray(p.effects) ? p.effects : [],
            rolls: Array.isArray(p.rolls) ? p.rolls : [],
            lastChoiceId: p.lastChoiceId ?? null,
            feed: Array.isArray(p.feed) ? p.feed : [],
            debts: Array.isArray(p.debts) ? p.debts : [],
            // Normalise les items d'avant le point 4 (ajoute slot/effets).
            besace: Array.isArray(p.besace) ? p.besace.map(normalizeItem) : startingBesace(),
            looted: Array.isArray(p.looted) ? p.looted : [],
            encounters: typeof p.encounters === "number" ? p.encounters : 0,
            // ⚠️ Une sauvegarde d'AVANT le 06/09 a des stats rendues par le
            // Seuil : on les garde telles quelles et son profil est déjà
            // « révélé » — on ne va pas redessiner un héros en cours de vie.
            stats: p.stats ? migrateStats(p.stats) : undefined,
            profil: p.profil
              ? profilDepuis(p.profil)
              : { ...profilNeuf(), revele: Boolean(p.stats) },
            // `prologue.done` d'avant portait « le Seuil est passé » : c'est
            // exactement ce que dit `ouverture` aujourd'hui.
            ouverture:
              typeof p.ouverture === "boolean"
                ? p.ouverture
                : Boolean((p as { prologue?: { done?: boolean } }).prologue?.done),
            // Traversée : reprise si présente ; sinon, run d'avant le 21/07 →
            // on amorce une traversée à partir de sa scène linéaire courante.
            trav:
              p.trav && typeof p.trav.current === "string" && Array.isArray(p.trav.visited)
                ? p.trav
                : freshTraversal(sceneAt(typeof p.step === "number" ? p.step : 0).id),
            // Zone (12/09) : une sauvegarde d'avant n'en a pas — elle vivait
            // aux Landes, et n'avait rien franchi (une vie = une zone alors).
            zone: p.zone === "salines" || p.zone === "landes" ? p.zone : "landes",
            zonesFranchies: Array.isArray(p.zonesFranchies) ? p.zonesFranchies : [],
            encroute: typeof p.encroute === "number" ? p.encroute : 0,
            tempetesJouees: Array.isArray(p.tempetesJouees) ? p.tempetesJouees : [],
            // La Soif et la Fixation des Déclarés (16/09) : une sauvegarde
            // d'avant n'en a pas — ajoutés DANS LE MÊME GESTE que le type
            // (la règle de la reconstruction champ par champ).
            soif: typeof p.soif === "number" ? p.soif : 0,
            soifPas: typeof p.soifPas === "number" ? p.soifPas : 0,
            fixationDeclaree:
              p.fixationDeclaree && typeof p.fixationDeclaree === "object" &&
              typeof p.fixationDeclaree.forte === "string" && typeof p.fixationDeclaree.faible === "string"
                ? { forte: p.fixationDeclaree.forte, faible: p.fixationDeclaree.faible }
                : null,
            // Chapitre : null pour les runs d'avant le 24/07 — Scene en tire un
            // à la volée (l'amorce jouera à la prochaine liaison).
            chapter: p.chapter && typeof p.chapter.id === "string" ? p.chapter : null,
            soupcon: typeof p.soupcon === "number" ? p.soupcon : 0,
            soupconSeen: typeof p.soupconSeen === "number" ? p.soupconSeen : 0,
            poiSeen: Array.isArray(p.poiSeen) ? p.poiSeen : [],
            choixFaits: Array.isArray(p.choixFaits) ? p.choixFaits : [],
            hameau: p.hameau && typeof p.hameau.entree === "boolean"
              ? p.hameau
              : { entree: false, serment: null, halte: false },
            // Runs d'avant le Savoir (25/07) : elles reprennent sans rien
            // savoir. Les options débloquées n'apparaîtront que si le joueur
            // ré-examine les points concernés — pas de rattrapage rétroactif,
            // le Savoir se gagne en explorant.
            savoirs: Array.isArray(p.savoirs) ? p.savoirs : [],
            fragmentsLus: Array.isArray(p.fragmentsLus) ? p.fragmentsLus : [],
            // ⚠️ loadRun reconstruit la run CHAMP PAR CHAMP : tout champ absent
            // ici est SILENCIEUSEMENT PERDU au rechargement. Piège vérifié le
            // 4/08 (l'anti-répétition des liaisons ne filtrait rien).
            feedSuite: Array.isArray(p.feedSuite) ? p.feedSuite : [],
            relicUsed: Boolean(p.relicUsed),
            reliquesUsees: Array.isArray(p.reliquesUsees)
              ? p.reliquesUsees.filter((n): n is number => typeof n === "number")
              : [],
            liaisonVues: Array.isArray(p.liaisonVues) ? p.liaisonVues : [],
            intrusesVues: Array.isArray(p.intrusesVues) ? p.intrusesVues : [],
            reactionsVues: Array.isArray(p.reactionsVues) ? p.reactionsVues : [],
            echosObjet: Array.isArray(p.echosObjet) ? p.echosObjet : [],
            vus: p.vus && typeof p.vus === "object" ? p.vus : {},
            memoireVue: rencontresDepuis(p.memoireVue),
            routeFermeeEnAttente: p.routeFermeeEnAttente === true,
            // ⚠️ Liste ALIGNÉE sur `RouteFermeeCause` (19/09) : « recousu »
            // n'y était pas — sa cause se perdait au rechargement et la
            // Croisée servait la ligne de l'échec dur à la place.
            routeFermeeCause:
              p.routeFermeeCause === "meute" || p.routeFermeeCause === "bete" ||
              p.routeFermeeCause === "recousu" || p.routeFermeeCause === "ensacheur"
                ? p.routeFermeeCause
                : p.routeFermeeCause === "echec" ? "echec" : undefined,
            menace: p.menace && typeof p.menace === "object" ? p.menace : null,
      lignesOuvertes: Number(p.lignesOuvertes) || 0,
            engageIci: p.engageIci === true,
            engageAvantReset: p.engageAvantReset === true,
            lieuxEngages: typeof p.lieuxEngages === "number" ? p.lieuxEngages : 0,
            horloge: typeof p.horloge === "number" ? p.horloge : (typeof p.day === "number" ? p.day : 1),
            poiIci: typeof p.poiIci === "number" ? p.poiIci : 0,
            temoins: Array.isArray(p.temoins) ? p.temoins : [],
            temoinsCites: Array.isArray(p.temoinsCites) ? p.temoinsCites : [],
            procesGagnes: typeof p.procesGagnes === "number" ? p.procesGagnes : 0,
            temoinsJuges: Array.isArray(p.temoinsJuges) ? p.temoinsJuges : [],
            loiVues: Array.isArray(p.loiVues) ? p.loiVues : [],
            jailerVues: Array.isArray(p.jailerVues) ? p.jailerVues : [],
            arriveeVues: Array.isArray(p.arriveeVues) ? p.arriveeVues : [],
            faits: sacDepuis(p.faits),
            besoins: p.besoins && typeof p.besoins === "object" ? p.besoins : {},
            croiseesDepuisRoute: typeof p.croiseesDepuisRoute === "number" ? p.croiseesDepuisRoute : 0,
            rencontresDues: Array.isArray(p.rencontresDues) ? p.rencontresDues : [],
            surprise: p.surprise && typeof p.surprise === "object" ? p.surprise : undefined,
            journalChoix: Array.isArray(p.journalChoix) ? p.journalChoix : [],
            prophetie: typeof p.prophetie === "number" ? p.prophetie : undefined,
            volNocturne: typeof p.volNocturne === "string" ? p.volNocturne : undefined,
            etatsAffiches: Array.isArray(p.etatsAffiches) ? p.etatsAffiches : [],
            etatBanniere: p.etatBanniere && Array.isArray(p.etatBanniere.effects) ? p.etatBanniere : undefined,
          };
        }
      }
    } catch {
      // stockage indisponible ou corrompu → on repart proprement, jamais de mort narrative
    }
  }
  return fresh();
}

/**
 * Une run est « en cours » si son fil a déjà du contenu — critère de l'écran
 * d'accueil (14/07) pour choisir entre « Bienvenue en enfer » et « Bon
 * retour... ». La simple existence de la clé ne suffit pas : une run tout
 * juste réinitialisée (mort acceptée) n'a rien à reprendre.
 */
export function hasSavedRun(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return false;
    const p = JSON.parse(raw) as Partial<RunState>;
    return (Array.isArray(p.feed) && p.feed.length > 0) || (typeof p.step === "number" && p.step > 0);
  } catch {
    return false;
  }
}

/**
 * L'ouverture de cette vie est jouée — on n'y revient plus.
 *
 * Posé à l'ENTRÉE EN JEU, par les deux chemins (carton d'acte à la première
 * vie, écran de retour aux suivantes) : fermer l'app juste après ne doit ni
 * refaire signer, ni rejouer le carton.
 */
export function marquerOuverture(): void {
  const r = loadRun();
  if (r.ouverture) return;
  r.ouverture = true;
  saveRun(r);
}

export function saveRun(state: RunState): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    // quota plein / navigation privée : on continue en mémoire
  }
}

/**
 * UNE NUIT — ce que fait un campement, et rien d'autre (spec §7, précisée
 * 13/07 ; barème du 11/09). Sorti de `Scene.tsx` le 12/09 parce que le
 * FRANCHISSEMENT D'UNE ZONE soigne exactement comme une nuit (décision
 * Patrick : « le passage soigne comme un campement ») — une seule
 * définition, sinon les deux divergent au premier réglage du barème.
 *   • le Jour et l'horloge avancent d'un cran ;
 *   • +0,15 de santé, jamais au-dessus de 1 ni sous le plancher (une nuit
 *     ne remet plus à neuf : elle efface la moitié d'un échec ordinaire) ;
 *   • le besoin de dormir est daté de CETTE heure (pas +1 : l'horloge vient
 *     d'être incrémentée — relecture du 10/08) ;
 *   • les états négatifs passagers tombent, les blessures durables (≥ 900
 *     scènes) sont ATTÉNUÉES à −1, jamais purgées : seul un soin les referme.
 */
export function appliquerRepos(run: RunState): void {
  run.day += 1;
  run.horloge = (run.horloge ?? run.day) + 1;
  run.health = Math.max(0.08, Math.min(1, run.health + 0.15));
  run.besoins = { ...(run.besoins ?? {}), dormir: run.horloge ?? run.day };
  run.effects = run.effects
    .filter((e) => e.delta > 0 || e.scenesLeft >= 900)
    .map((e) => (e.scenesLeft >= 900 && e.delta < -1 ? { ...e, delta: -1 } : e));
}

/**
 * FRANCHIR UNE ZONE (décision Patrick 12/09 : une seule vie sur les trois
 * actes). La vie CONTINUE — rien de ce qui la définit n'est touché : le nom,
 * la Besace, la santé (soignée d'une nuit, pas remise à neuf), le Jour, les
 * états, le profil, les Savoirs, les faits. Ce qui se remet à zéro, c'est ce
 * qui appartenait à la ZONE qu'on quitte :
 *   • la traversée (`trav`) repart de l'entrée de la zone suivante ;
 *   • les comptes que le monde d'avant tenait sur nous — le Soupçon (c'est
 *     le village des Landes qui juge, pas le suivant), la menace en cours et
 *     l'ardoise du prudent (« le compte ne se tient qu'en pleine lande »,
 *     11/09), la séquence du Hameau, les points vus et les choix faits ICI.
 * ⚠️ Refuse une zone sans scène d'entrée : passer `ecrite: true` sans écrire
 * l'entrée serait une promesse sans consommateur.
 */
export function franchirZone(run: RunState, vers: ZoneDef): void {
  run.zonesFranchies = [...(run.zonesFranchies ?? []), run.zone ?? "landes"];
  demarrerZone(run, vers);
  appliquerRepos(run);
  run.soupcon = 0;
  run.soupconSeen = 0;
  run.hameau = { entree: false, serment: null, halte: false };
  run.menace = null;
  run.lignesOuvertes = 0;
  run.poiSeen = [];
  run.choixFaits = [];
  run.croiseesDepuisRoute = 0;
  run.rencontresDues = [];
}

/**
 * ENTRER DANS UNE ZONE sans en franchir une autre (13/09) : la traversée
 * repart de son entrée, et ce qui appartient à la zone d'AVANT ne bouge pas.
 * C'est le socle de `franchirZone`, et la porte de `?zone=salines` (un
 * testeur commence une vie neuve directement dans la Croûte). Le chapitre
 * du Bailli et le compte du sel appartiennent chacun à leur zone : remis à
 * zéro ici, quel que soit le chemin d'entrée.
 */
export function demarrerZone(run: RunState, vers: ZoneDef): void {
  const envs = vers.environnements;
  if (!vers.ecrite || (!vers.entry && !envs?.length)) {
    throw new Error(`franchirZone : la zone « ${vers.id} » n'est pas écrite (ni entrée ni environnements).`);
  }
  run.zone = vers.id;
  run.chapter = null;
  run.encroute = 0;
  run.tempetesJouees = [];
  run.soif = 0;
  run.soifPas = 0;
  run.fixationDeclaree = null;
  // Graine de la zone : déterministe par vie (la reprise rejoue le même
  // tirage d'étape), différente d'une vie à l'autre.
  const graine = (run.step + 1) * 7919 + run.day * 31;
  if (envs?.length) {
    // TRAVERSÉE À ÉTAGES : on entre par le premier environnement, et le
    // compte d'étape démarre sur ce lieu-là. `target` = le maximum de lieux
    // qu'une traversée peut compter — ce que lisent la courbe de tension et
    // les statistiques, jamais ce qui décide de la fin (c'est `prochainPas`).
    const entree = premierLieu(envs, graine);
    run.trav = freshTraversal(entree);
    run.trav.target = cibleTotale(envs);
    run.trav.etage = entrerLieu(envs, ouvrirEtage(envs, 0, graine), entree);
  } else {
    run.trav = freshTraversal(vers.entry);
  }
}
